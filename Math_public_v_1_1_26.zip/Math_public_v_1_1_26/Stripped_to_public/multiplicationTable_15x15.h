
// ===========================
// |	multiplication table |
// |	9-3-2-2023           |
// |	by Spartakusz        |
// ===========================

#ifndef _MPT15X15_
#define _MPT15X15_

#include <iostream>
#include <iomanip>
using namespace std;


void multiplicationTable15x15Fn(){
	cout<<"\n\n"<<endl;
	cout<<"                 \33[4;1;33m*\33[1;37m*\33[1;33m* N U M B E R  M A T R I X 15x15 *\33[1;37m*\33[1;33m* \33[0m\n"
		<<endl;
		
	cout<<"\33[0m";
	fflush(stdout);
	
	int x, y = 0;
	for(x = 1;y<=15;++y)
		{
			if(y==0)
			{cout<<" \33[1;37m";
			cout<<setw(2)<<" "<<y<<"\33[0m";}
			if(y==1)
			{cout<<" \33[1;37m";
			cout<<setw(4)<<" "<<y<<"\33[0m";}
			if(y>1 && y<10)
			{cout<<" \33[1;37m";
			cout<<setw(2)<<" "<<y<<"\33[0m";}
			if(y>9 && y<15)
			{cout<<"\33[1;37m";
				cout<<setw(2)<<""<<y;}
			if(y==15)
			{cout<<"\33[1;37m";
			cout<<setw(2)<<" "<<y<<"\33[0m";}
		}
	
	cout<<"\n   -----------------------------------------------------------------"
			<<endl;
			
	for(x = 1;x<=15;++x)
				{
					if(x==15)cout<<" \33[1;37m"<<setw(3)<<x<<"  \33[0m|";
					if(x<10)cout<<"   \33[1;37m"<<x<<"  \33[0m|";
					if(x>9 && x<15)cout<<" \33[1;37m"<<setw(3)<<x<<"  \33[0m|";
					for(y = 1; y <= 15; ++y)
					{
						if(y==1)cout<<"\33[;30;43m "<<setw(2)<<x * y;
						if(y>1 && y<15)cout<<"\33[;30;43m "<<setw(3)<<x * y;
						if(y==15)cout<<"\33[;30;43m "<<setw(3)
									<<x * y<<"  ";
					}
					
					cout<<endl<<"\33[0m";
					}
			
			
		
	
	
	cout<<"\n\n"<<endl;
	
}

#endif
