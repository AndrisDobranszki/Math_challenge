In order to run the program:

Compile the "Project_10_V_mainFile_public_version.cpp" file

Then run it in linux terminal.

Have fun! :)
