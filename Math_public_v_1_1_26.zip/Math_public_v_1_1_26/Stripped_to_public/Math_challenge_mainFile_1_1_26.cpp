//Project_10 version 1.1

//Game works fine, all variables update well
//Milestone messages are built in ... (see milestones in milestones text file)
//Create, Delete, Modify Users synced with save and load
//Saving into 1 save file, 1 line/object data
//Save to user their unlocked achivements and current lifes if lifes are
// more then 3 when user exiting game...
// Make achivements Display page too, where user can see unlocked achivements.
//Colour themes finished and functioning.
//Game manual provided

//enCode and deCode save file to be "harder" to temper with single player and Multiplayer too

/*Asking for multiplayer names is in separate class. Records are not
cerried forward by the Player.
* Multiplayer Players are a different CLASS with "different" achivements
* Single player achivements are saved to players so you can look up un achived achivements menu
* per Player(if unlocked thatAchivement->shows in display)
* Statistic also saved into statistic
file for all time best 15 multiplayer score.../x rounds
*/ // multiplayer player is out/skip round if hits ZERO life, but the game goes eighter
//    everyone hits 0 lifes or target rounds are complated, or only 1 player left in game.

//NOTE: Loggin is protected via your Special id PIN (MAX 4 digit, only Number)

//------------------------------------------------------------------------------------
//Missing: is Audio on/of and install into key points deferent sound effects or music
//			Also no "timer mode" available in this version
			
//**************************************************************************************
//Structure map () -> Note: Options menu has been moved to both sP and mP menu separate
//==================================================================
	//Select menu:
	//		MAIN MENU:
	//		- Single player mode
	//			-Login
	//				- Play the Game! -> (Once logged in)
	//				- Statistics
	//					- Include achived milestones to 0/18 -> show achived milestones option -> press (...)
	//				- Number Matrix -15x-
	//				- Change Name/Pin, delete yourselfe -> 
	//				- Back (Save before exit)
	//				
	//			-Back
	//		- Multiplayer mode
	//			- Play the Game! (set how many rounds you wanna play), ask for timer Yes/No, play
	//				- Choose how many players play, choose players, play the game, exit end of game
	//					No data will be saved into file but to statistic until current program runs
	//			- Leader Board (1st 10 best score) 
	//			-Back ( Score counts towards personal statistics so SAVE before exit)
	//		- Options menu
	//				- Color themes
	//					- 1, 2, 3 set
	//				- Difficulty Levels
	//					- 1, 2, 3 set
	//				(- Sound On/OFF) -> ONLY IN FURTHER VERSIONS, now not possible
	//		- Number Matrix -15x- (back to "this" MAIN menu when you finished)
	//		- Exit Program
	//==================================================================================
//**************************************************************************************

//================================ I N C L U D E S =====================================

#include "colour.h"
#include "milestonesDotH_forProject_10.h"
#include "multiplicationTable_15x15.h"
#include <limits>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <math.h>
#include <fstream>
#include <ostream>
#include <time.h>	//for todayFn
#include <algorithm> //for sorting purposes
#include <iomanip>
#include <random> //for more randomizers

//=====================================================================================
//							*** PRIMARY VARIABLES ***

int sPpersonOnList = 0; //counter incremented each time the constructor is invoked for new objec
int mPpersonOnList = 0;
unsigned int leaderList_V5_size = 20;
bool allAchivementsAreUnlocked_V5 = false; // if all unlocked, a counter will activate this -> which displays
//int achivementsCounter = 0; // the final message, + GAME COMPLATED....
int colorSchemeNumberIn_main = 0; // default
//Dificulty level switches (By default is Normal)
bool easySwitch = false; // modify scores to half/round valuation (range 0-10)
bool expertSwitch = false; // modify scores to double/per round valuation (range 0-1000)
string difficulty_message = "\33[1;32mNormal\33[0m";
bool termsConsBool = false; // if true can proceed...
time_t now_v5 = time(0);
//=====================================================================================
//								*** CLASS ***
class SplayerClass {
	
	public:
	
		//for time management
		time_t old_timeTo_saveAnd_load_V5 = now_v5; // for more then 7 days not played message
		
		time_t time_when_started_equation_V5 = time(0); // for how long you take per equation statistic
		double sP_time_spent_onGood_answer_perRound = 0; //difftime(currentTime, startTime);
		// or current time - start time (it is in seconds)
		float sP_averageTime_spent_per_Goodanswer = 0.00; // sec/goodAnswer -> Where sec is from equation load till good answer given mesured, convertid into seconds
		
		SplayerClass(string& name, int& id): //CONSTRUCTOR Default
			sPname(name), sPid(id)			// If var needs saving to/from file loading mark with 'S'
			{								//(mainly all-time data and unlocked milestones to save)
			sPpersonOnList++;
			sPlayerOnList_V5 = sPpersonOnList;
			// initialize some vars at construction
			old_timeTo_saveAnd_load_V5 = now_v5;
			sP_totalRoundsPlayed_lastSession_V5 = 0;
			sP_totalScoreInThisSession_V5 = 0;
			sP_goodAnswerStreek_V5 = 0;
			sP_longestGoodAnswerStreak_V5 = 0;	//in this session data
			sP_lifes_V5 = 3;		// S (if more then 3)
			alltimeScore_V5 = 0;	// S
			alltimeRounds_V5 = 0;	// S
			anyGoodAnswerGiven_lastSession_V5 = 0;
			anyGoodAnswerGiven_Alltimes_V5 = 0;		// S
			attempts_counterForStatistic_singleSession_V5 = 0;
			attempts_counterForStatistic_allTime_V5 = 0;	// S
			lostLifes_counter_lastSessin_V5 = 0;
			lostLifes_counter_Alltimes_V5 = 0; // update from saved variable !!!	// S
			new_highestScore_inOneSession_V5 = 0;	// S (this is all-time data)
			previousHighScore_inOneSession_V5 = 0;	// S (this is all-time data)
			longest_goodAnswerStreakEver_V5 = 0;	// S
			allTime_previousLongestStreak_V5 = 0;	// S
			sP_milestonesUnlocked_counter_V5 = 0;	// S
			longestPlayEver_V5 = 0;		// S
			previousLongestPlay_V5 = 0;		// S
			sP_sessionCounter_inClass = 0;	// S
			sRoundedAnswer = " You didn't score in last round...";
			sP_chosen_colorScheme_V5 = 0; // default (1,2,3,4) other options	// S
			sP_chosen_level_V5 = 2; // normal (easy = 1, advanced = 3, master = 4)
			sP_totalSecsPassed_toGiveAnsver_V5 = 0;  //S
			sP_averageSecPerGoodAnswer = "n/a";
			sP_secsPassedPerGa_singleSessionData = 0; // single session data (total of 1 session) S
			sP_avgSecsPassed_perGoodAnswer_SingleSessionData = "n/a"; //(secsPassed in 1 session with thinking on answer / round) S
			sP_last_session_play_time_V5 = 0;
			sP_string_last_session_play_time_V5 = "n/a";
			sP_allTime_session_play_time_V5 = 0;
			sP_string_allTime_session_play_time_V5 = "n/a";
			sP_shortest_time_goodAnswerGiven_lastSession_V5 = 0;
			sP_longest_time_goodAnswerGiven_lastSession_V5 = 0;
			sp_shortest_time_goodAnswerGiven_allTime_V5 = 0;
			sp_longest_time_goodAnswerGiven_allTime_V5 = 0;
			sP_string_shortest_time_goodAnswerGiven_lastSession_V5 = "n/a";
			sP_string_longest_time_goodAnswerGiven_lastSession_V5 = "n/a";
			sp_string_shortest_time_goodAnswerGiven_allTime_V5 = "n/a";
			sp_string_longest_time_goodAnswerGiven_allTime_V5 = "n/a";
			sP_allTime_easy_score_V5 = 0;
			sP_allTime_normal_score_V5 = 0;
			sP_allTime_expert_score_V5 = 0;
			sP_allTime_master_score_V5 = 0;
			sP_allTime_rounds_easy_V5 = 0;
			sP_allTime_rounds_normal_V5 = 0;
			sP_allTime_rounds_expert_V5 = 0;
			sP_allTime_rounds_master_V5 = 0;
			avgScorePerRound_allTime_V5 = 0.00;
			sRoundedAnswer = "N/A";
			sRoundedAnswerAllT = "N/A";
			sP_masterlevel_unlocked = false;
		
			sp_milestone_1_V5 = false;
			sp_milestone_2_V5 = false;
			sp_milestone_3_V5 = false;
			sp_milestone_4_V5 = false;
			sp_milestone_5_V5 = false;
			sp_milestone_6_V5 = false;
			sp_milestone_7_V5 = false;
			sp_milestone_8_V5 = false;
			sp_milestone_9_V5 = false;
			sp_milestone_10_V5 = false;
			sp_milestone_11_V5 = false;
			sp_milestone_12_V5 = false;
			sp_milestone_13_V5 = false;
			sp_milestone_14_V5 = false;
			sp_milestone_15_V5 = false;
			sp_milestone_16_V5 = false;
			sp_milestone_17_V5 = false;
			sp_milestone_17andHalf_V5 = false;
			sp_milestone_18_V5 = false;
			milestone_5sec_easy_V5 = false;
			milestone_3sec_easy_V5 = false;
			milestone_1sec_easy_V5 = false;
			milestone_5sec_normal_V5 = false;
			milestone_3sec_normal_V5 = false;
			milestone_1sec_normal_V5 = false;
			milestone_5sec_expert_V5 = false;
			milestone_3sec_expert_V5 = false;
			milestone_1sec_expert_V5 = false;
			milestone_5sec_master_V5 = false;
			milestone_3sec_master_V5 = false;
			milestone_1sec_master_V5 = false;
			}
			// Plus Vars need saving:
			// name
			// id	----> number of vars for saving so far: |-19-|
		//--------------------------------------------------------------
		//Loading Constructor: (string& name, int& id) :sPname(name), sPid(id){ (initialazion values ect....) } //CONSTRUCTOR Default
		// Constructor_name (type& spaceHolder_varName, type& spaceHolder_varname) :
		//						inClassVarName(spaceHolder_varName), inClassVarName(spaceHolder_varName){}	
		SplayerClass(
						
						string& sPname_b,
						int& sPid_b,
						int& sP_lifes_V5_b,
						int& alltimeScore_V5_b,
						int& alltimeRounds_V5_b,
						int& anyGoodAnswerGiven_Alltimes_V5_b,
						int& attempts_counterForStatistic_allTime_V5_b,
						int& lostLifes_counter_Alltimes_V5_b,
						int& new_highestScore_inOneSession_V5_b,
						int& previousHighScore_inOneSession_V5_b,
						int& longest_goodAnswerStreakEver_V5_b,
						int& allTime_previousLongestStreak_V5_b,
						int& sP_milestonesUnlocked_counter_V5_b,
						int& longestPlayEver_V5_b,
						int& previousLongestPlay_V5_b,
						int& sP_sessionCounter_inClass_b,
						int& sP_chosen_colorScheme_V5_b,
						int& sP_chosen_level_V5_b,
						double sP_totalSecsPassed_toGiveAnsver_V5_b,
						double& sP_allTime_session_play_time_V5_b, 
						double& sP_shortest_time_goodAnswerGiven_lastSession_V5_b,
						double& sP_longest_time_goodAnswerGiven_lastSession_V5_b,
						double& sp_shortest_time_goodAnswerGiven_allTime_V5_b,
						double& sp_longest_time_goodAnswerGiven_allTime_V5_b,
						int& sP_allTime_easy_score_V5_b,
						int& sP_allTime_normal_score_V5_b,
						int& sP_allTime_expert_score_V5_b,
						int& sP_allTime_master_score_V5_b,
						int& sP_allTime_rounds_easy_V5_b,
						int& sP_allTime_rounds_normal_V5_b,
						int& sP_allTime_rounds_expert_V5_b,
						int& sP_allTime_rounds_master_V5_b,
						bool sP_masterlevel_unlocked_b,
		
						bool sp_milestone_1_V5_b,
						bool sp_milestone_2_V5_b,
						bool sp_milestone_3_V5_b,
						bool sp_milestone_4_V5_b,
						bool sp_milestone_5_V5_b,
						bool sp_milestone_6_V5_b,
						bool sp_milestone_7_V5_b,
						bool sp_milestone_8_V5_b,
						bool sp_milestone_9_V5_b,
						bool sp_milestone_10_V5_b,
						bool sp_milestone_11_V5_b,
						bool sp_milestone_12_V5_b,
						bool sp_milestone_13_V5_b,
						bool sp_milestone_14_V5_b,
						bool sp_milestone_15_V5_b,
						bool sp_milestone_16_V5_b,
						bool sp_milestone_17_V5_b,
						bool sp_milestone_17andHalf_V5_b,
						bool sp_milestone_18_V5_b,
						bool milestone_5sec_easy_V5_b,
						bool milestone_3sec_easy_V5_b,
						bool milestone_1sec_easy_V5_b,
						bool milestone_5sec_normal_V5_b,
						bool milestone_3sec_normal_V5_b,
						bool milestone_1sec_normal_V5_b,
						bool milestone_5sec_expert_V5_b,
						bool milestone_3sec_expert_V5_b,
						bool milestone_1sec_expert_V5_b,
						bool milestone_5sec_master_V5_b,
						bool milestone_3sec_master_V5_b,
						bool milestone_1sec_master_V5_b,
						double old_timeTo_saveAnd_load_V5_b
						):
						sPname(sPname_b),
						sPid(sPid_b),
						sP_lifes_V5(sP_lifes_V5_b),
						alltimeScore_V5(alltimeScore_V5_b),
						alltimeRounds_V5(alltimeRounds_V5_b),
						anyGoodAnswerGiven_Alltimes_V5(anyGoodAnswerGiven_Alltimes_V5_b),
						attempts_counterForStatistic_allTime_V5(attempts_counterForStatistic_allTime_V5_b),
						lostLifes_counter_Alltimes_V5(lostLifes_counter_Alltimes_V5_b),
						new_highestScore_inOneSession_V5(new_highestScore_inOneSession_V5_b),
						previousHighScore_inOneSession_V5(previousHighScore_inOneSession_V5_b),
						longest_goodAnswerStreakEver_V5(longest_goodAnswerStreakEver_V5_b),
						allTime_previousLongestStreak_V5(allTime_previousLongestStreak_V5_b),
						sP_milestonesUnlocked_counter_V5(sP_milestonesUnlocked_counter_V5_b),
						longestPlayEver_V5(longestPlayEver_V5_b),
						previousLongestPlay_V5(previousLongestPlay_V5_b),
						sP_sessionCounter_inClass(sP_sessionCounter_inClass_b),
						sP_chosen_colorScheme_V5(sP_chosen_colorScheme_V5_b),
						sP_chosen_level_V5(sP_chosen_level_V5_b),
						sP_totalSecsPassed_toGiveAnsver_V5(sP_totalSecsPassed_toGiveAnsver_V5_b),
						sP_allTime_session_play_time_V5(sP_allTime_session_play_time_V5_b),
						sP_shortest_time_goodAnswerGiven_lastSession_V5(sP_shortest_time_goodAnswerGiven_lastSession_V5_b),
						sP_longest_time_goodAnswerGiven_lastSession_V5(sP_longest_time_goodAnswerGiven_lastSession_V5_b),
						sp_shortest_time_goodAnswerGiven_allTime_V5(sp_shortest_time_goodAnswerGiven_allTime_V5_b),
						sp_longest_time_goodAnswerGiven_allTime_V5(sp_longest_time_goodAnswerGiven_allTime_V5_b),
						sP_allTime_easy_score_V5(sP_allTime_easy_score_V5_b),
						sP_allTime_normal_score_V5(sP_allTime_normal_score_V5_b),
						sP_allTime_expert_score_V5(sP_allTime_expert_score_V5_b),
						sP_allTime_master_score_V5(sP_allTime_master_score_V5_b),
						sP_allTime_rounds_easy_V5(sP_allTime_rounds_easy_V5_b),
						sP_allTime_rounds_normal_V5(sP_allTime_rounds_normal_V5_b),
						sP_allTime_rounds_expert_V5(sP_allTime_rounds_expert_V5_b),
						sP_allTime_rounds_master_V5(sP_allTime_rounds_master_V5_b),
						sP_masterlevel_unlocked(sP_masterlevel_unlocked_b),
						sp_milestone_1_V5(sp_milestone_1_V5_b),
						sp_milestone_2_V5(sp_milestone_2_V5_b),
						sp_milestone_3_V5(sp_milestone_3_V5_b),
						sp_milestone_4_V5(sp_milestone_4_V5_b),
						sp_milestone_5_V5(sp_milestone_5_V5_b),
						sp_milestone_6_V5(sp_milestone_6_V5_b),
						sp_milestone_7_V5(sp_milestone_7_V5_b),
						sp_milestone_8_V5(sp_milestone_8_V5_b),
						sp_milestone_9_V5(sp_milestone_9_V5_b),
						sp_milestone_10_V5(sp_milestone_10_V5_b),
						sp_milestone_11_V5(sp_milestone_11_V5_b),
						sp_milestone_12_V5(sp_milestone_12_V5_b),
						sp_milestone_13_V5(sp_milestone_13_V5_b),
						sp_milestone_14_V5(sp_milestone_14_V5_b),
						sp_milestone_15_V5(sp_milestone_15_V5_b),
						sp_milestone_16_V5(sp_milestone_16_V5_b),
						sp_milestone_17_V5(sp_milestone_17_V5_b),
						sp_milestone_17andHalf_V5(sp_milestone_17andHalf_V5_b),
						sp_milestone_18_V5(sp_milestone_18_V5_b),
						milestone_5sec_easy_V5(milestone_5sec_easy_V5_b),
						milestone_3sec_easy_V5(milestone_3sec_easy_V5_b),
						milestone_1sec_easy_V5(milestone_1sec_easy_V5_b),
						milestone_5sec_normal_V5(milestone_5sec_normal_V5_b),
						milestone_3sec_normal_V5(milestone_3sec_normal_V5_b),
						milestone_1sec_normal_V5(milestone_1sec_normal_V5_b),
						milestone_5sec_expert_V5(milestone_5sec_expert_V5_b),
						milestone_3sec_expert_V5(milestone_3sec_expert_V5_b),
						milestone_1sec_expert_V5(milestone_1sec_expert_V5_b),
						milestone_5sec_master_V5(milestone_5sec_master_V5_b),
						milestone_3sec_master_V5(milestone_3sec_master_V5_b),
						milestone_1sec_master_V5(milestone_1sec_master_V5_b),
						old_timeTo_saveAnd_load_V5(old_timeTo_saveAnd_load_V5_b)
							{ 
							sRoundedAnswer = " no data yet...";
							sPpersonOnList++;
							sPlayerOnList_V5 = sPpersonOnList;
							sP_totalRoundsPlayed_lastSession_V5 = 0;
							sP_totalScoreInThisSession_V5 = 0;
							sP_goodAnswerStreek_V5 = 0;
							sP_longestGoodAnswerStreak_V5 = 0;
							anyGoodAnswerGiven_lastSession_V5 = 0;
							attempts_counterForStatistic_singleSession_V5 = 0;
							lostLifes_counter_lastSessin_V5 = 0;
							sP_secsPassedPerGa_singleSessionData = 0;
							sP_last_session_play_time_V5 = 0;
							}
						//----------------------------------------------------------
			
			
		//Serialize (Person object as a single line) It is a Function
		//-----------------------------
		//Random junk loop:
		//seed	
		void seedrnd_junk(void)
			{
				srand((unsigned)time(NULL));
			}
		//random junk num (4 digit)
		int rnd_junkFn(int range)
			{
				int r;
				r=rand()%range;return(r);
			}
		//------------------------------	
		//serializer:
		//TimePoint only
		string sP_timePointOnly_serialFn_V5(){
			
			return to_string(old_timeTo_saveAnd_load_V5);} // update this at last time played... then next time load
			//value from save into it, then evaluate if it is > or < then 7 days....
		
		//------------------------------------------------------------------------------------------
		
		//random generated text Fn
		string rnd_genTextFn_V5(){
			
			static const string characters ="abcdeefghiijklmnoopqrstuuvwxyz"
											"ABCDEFGHIJKLMNOOPQRSTUUWVXZY"
											"112345667890";
		
				//randomizer
			std::mt19937 rnd_char((rand()%19)+1); //mersenne twister algorithm
			
			
			//generate lengh between 4-10 charsw
			//uniform_int_distribution<> length_dist(4,10);
		
			rnd_char();
	
			int length = 
			rand()%10;
			if(length < 4){while(length < 4){length = rand()%10;}} // no length < 4 allowed
			string generated_text;
			generated_text.reserve(length);
			
			for(int i = 0; i < length; ++i){
				rnd_char();
				//rnd char index
				uniform_int_distribution<> char_dist((rand()%9)+1,characters.size()-1);
				generated_text += characters[char_dist(rnd_char)];
			}
			
			return generated_text;
		}
		//------------------------------------------------------------------------------------------
		
		
		//Write all vars together into a long string var....
		string sP_serializeFn_V5() {
			
			string sce = " "; // white space is a separator between variables in the line of string.
			// 1st convert non string vars to string...
			// 2nd insert junk between vars as noise/encryption
			//write object properties into one line
			string nameJunk = rnd_genTextFn_V5();

			int junk_range = 9999;
			//---------------------------
			int junkNum_1 = rnd_junkFn(junk_range)+1;
			int junkNum_2 = rnd_junkFn(junk_range)+1;
			//int junkNum_3 = rnd_junkFn(junk_range)+1;
			//int junkNum_4 = rnd_junkFn(junk_range)+1;
			//int junkNum_5 = rnd_junkFn(junk_range)+1;
			int junkNum_6 = rnd_junkFn(junk_range)+1;
			int junkNum_7 = rnd_junkFn(junk_range)+1;
			int junkNum_8 = rnd_junkFn(junk_range)+1;
			int junkNum_9 = rnd_junkFn(junk_range)+1;
			//int junkNum_10 = rnd_junkFn(junk_range)+1;
			int junkNum_11 = rnd_junkFn(junk_range)+1;
			//int junkNum_12 = rnd_junkFn(junk_range)+1;
			int junkNum_13 = rnd_junkFn(junk_range)+1;
			//int junkNum_14 = rnd_junkFn(junk_range)+1;
			int junkNum_15 = rnd_junkFn(junk_range)+1;
			int junkNum_16 = rnd_junkFn(junk_range)+1;
			int junkNum_17 = rnd_junkFn(junk_range)+1;
			int junkNum_18 = rnd_junkFn(junk_range)+1;
			int junkNum_19 = rnd_junkFn(junk_range)+1;
			int junkNum_20 = rnd_junkFn(junk_range)+1;
			int junkNum_21 = rnd_junkFn(junk_range)+1;
			int junkNum_22 = rnd_junkFn(junk_range)+1;
			int junkNum_23 = rnd_junkFn(junk_range)+1;
			string junkNum_24 = rnd_genTextFn_V5();
			string junk_random = rnd_genTextFn_V5();
			string j3 = rnd_genTextFn_V5();
			string j4 = rnd_genTextFn_V5();
			string j5 = rnd_genTextFn_V5();
			string j6 = rnd_genTextFn_V5(); 
			//---------------------------
			return nameJunk // 1 j
			 + sce + junk_random // 2 j
			 + sce + to_string(junkNum_1) //3 j 
			 + sce + j3 // 4 j
			 + sce + to_string(junkNum_2) // 5 j
			 + sce + to_string(sP_lifes_V5)  //6 v
			 + sce + to_string(junkNum_7)  //7
			 + sce + to_string(alltimeScore_V5)  //8
			 + sce + to_string(junkNum_8)  //9
			 + sce + to_string(alltimeRounds_V5)  //10
			 + sce + to_string(junkNum_9) //11
			 + sce + to_string(anyGoodAnswerGiven_Alltimes_V5)  //12
			 + sce + to_string(junkNum_11)  //13
			 + sce + to_string(attempts_counterForStatistic_allTime_V5)  //14
			 + sce + to_string(junkNum_13)  //15
			 + sce + to_string(lostLifes_counter_Alltimes_V5)  //16
			 + sce + to_string(junkNum_15)  //17
			 + sce + to_string(new_highestScore_inOneSession_V5)  //18
			 + sce + to_string(junkNum_16)  //19
			 + sce + to_string(previousHighScore_inOneSession_V5)  //20
			 + sce + to_string(junkNum_17)  //21
			 + sce + j5 // 22
			 + sce + j6 // 23
			 + sce + sPname //24
			 + sce + j4 // 25
			 + sce + to_string(longest_goodAnswerStreakEver_V5) //26
			 + sce + to_string(junkNum_18)  //27
			 + sce + to_string(allTime_previousLongestStreak_V5)  //28
			 + sce + to_string(junkNum_19)  //29
			 + sce + to_string(sP_milestonesUnlocked_counter_V5)  //30
			 + sce + to_string(junkNum_20)  //31
			 + sce + to_string(longestPlayEver_V5)  //32
			 + sce + to_string(junkNum_21)  //33
			 + sce + to_string(previousLongestPlay_V5)  //34
			 + sce + to_string(junkNum_22)  //35
			 + sce + to_string(sP_sessionCounter_inClass)  //36
			 + sce + to_string(junkNum_23)  //37
			 + sce + to_string(sP_chosen_colorScheme_V5)  //38
			 + sce + to_string(sP_chosen_level_V5)  //39
			 //+ sce + to_string(sP_inClass_expertSwitch_V5)
			 //+ sce + to_string(sP_inClass_easySwitch_V5)
			 + sce + to_string(sP_totalSecsPassed_toGiveAnsver_V5)  //40
			 + sce + to_string(sP_allTime_session_play_time_V5)  //41
			 + sce + to_string(sP_shortest_time_goodAnswerGiven_lastSession_V5)  //42
			 + sce + to_string(sP_longest_time_goodAnswerGiven_lastSession_V5)  //43
			 + sce + to_string(sp_shortest_time_goodAnswerGiven_allTime_V5)  //44
			 + sce + to_string(sp_longest_time_goodAnswerGiven_allTime_V5)  //45
			 + sce + to_string(junkNum_6)  //46
			 + sce + junkNum_24 //47
			 + sce + to_string(sPid)  //48
			 + sce + to_string(sP_allTime_easy_score_V5)  //49
			 + sce + to_string(sP_allTime_normal_score_V5)  //50
			 + sce + to_string(sP_allTime_expert_score_V5)  //51
			 + sce + to_string(sP_allTime_master_score_V5)  //52
			 + sce + to_string(sP_allTime_rounds_easy_V5)  //53
			 + sce + to_string(sP_allTime_rounds_normal_V5)  //54
			 + sce + to_string(sP_allTime_rounds_expert_V5)  //55
			 + sce + to_string(sP_allTime_rounds_master_V5)  //56
			 + sce + to_string(sP_masterlevel_unlocked)  //57
			 + sce + to_string(sp_milestone_1_V5)  //58
			 + sce + to_string(sp_milestone_2_V5)  //59
			 + sce + to_string(sp_milestone_3_V5)  //60
			 + sce + to_string(sp_milestone_4_V5)  //61
			 + sce + to_string(sp_milestone_5_V5)  //62
			 + sce + to_string(sp_milestone_6_V5)  //63
			 + sce + to_string(sp_milestone_7_V5)  //64
			 + sce + to_string(sp_milestone_8_V5)  //65
			 + sce + to_string(sp_milestone_9_V5)  //66
			 + sce + to_string(sp_milestone_10_V5)  //67
			 + sce + to_string(sp_milestone_11_V5)  //68
			 + sce + to_string(sp_milestone_12_V5)  //69
			 + sce + to_string(sp_milestone_13_V5)  //70
			 + sce + to_string(sp_milestone_14_V5)  //71
			 + sce + to_string(sp_milestone_15_V5)  //72
			 + sce + to_string(sp_milestone_16_V5)  //73
			 + sce + to_string(sp_milestone_17_V5)  //74
			 + sce + to_string(sp_milestone_17andHalf_V5)  //75
			 + sce + to_string(sp_milestone_18_V5)  //76
			 + sce + to_string(milestone_5sec_easy_V5)
			 + sce + to_string(milestone_3sec_easy_V5)
			 + sce + to_string(milestone_1sec_easy_V5)
			 + sce + to_string(milestone_5sec_normal_V5)
			 + sce + to_string(milestone_3sec_normal_V5)
			 + sce + to_string(milestone_1sec_normal_V5)
			 + sce + to_string(milestone_5sec_expert_V5)
			 + sce + to_string(milestone_3sec_expert_V5)
			 + sce + to_string(milestone_1sec_expert_V5)
			 + sce + to_string(milestone_5sec_master_V5)
			 + sce + to_string(milestone_3sec_master_V5)
			 + sce + to_string(milestone_1sec_master_V5)
			 + sce + to_string(old_timeTo_saveAnd_load_V5)
			 ;}
		//--------------------------------------------------------------	
		bool oBallAchivementsAreUnlocked; // if all unlocked, a counter will activate this -> which displays
		//int oBachivementsCounter; // the final message, + GAME COMPLATED....
		//int sP_objColorTheme_V5; //public access for color theme setter
		//NOTE:
		//milestone 'bools' must be under  Player class to be able to save and load milestone progress to
		//individual Players!!! (Transfer when finished all Milestone functions)
		// Then Personialize the messages to Player's name in message!!!
		//----------------------------------------------------------------------------
		bool sP_milestone_extraLifeFor_3inRow = true;
		bool sP_milestone_reaching_100_ScoreInSingleSession = true;
		bool sP_milestone_extraLifeFor_5inRow = true;
		bool sP_milestone_extraLifeFor_10inRow = true;
		bool sP_milestone_reaching5_lifes = true;
		bool sP_milestone_reaching10_lifes = true;
		bool sP_milestone_reaching1000_ScoreInSingleSession = true;
		bool sP_milestone_reaching5000_ScoreInSingleSession = true;
		bool sP_milestone_reaching_10RoundsInSession = true;
		bool sP_milestone_reaching_100RoundsInSession = true;
		bool sP_milestone_reaching_50RoundsInSession = true;
		bool sP_milestone_reaching_1000Score_in100Rounds = true;
		bool sP_milestone_extraLifeFor_50inRow = true;
		bool sP_milestone_reaching10_sessions = true;
		bool sP_milestone_reaching50_sessions = true;
		bool sP_milestone_reaching100_sessions = true;
		bool sP_milestone_reaching10000_ScoreInSingleSession = true;
		bool sP_milestone_reaching1000000_AllTimeScore = true;
		bool sP_allMilestonesUnlocked = false; // unlocked/ true if "allMilestonesProgress" hits 19 (unlocked all Milestones)
		
		//loaded user data into it.
		bool sp_milestone_1_V5;
		bool sp_milestone_2_V5;
		bool sp_milestone_3_V5;
		bool sp_milestone_4_V5;
		bool sp_milestone_5_V5;
		bool sp_milestone_6_V5;
		bool sp_milestone_7_V5;
		bool sp_milestone_8_V5;
		bool sp_milestone_9_V5;
		bool sp_milestone_10_V5;
		bool sp_milestone_11_V5;
		bool sp_milestone_12_V5;
		bool sp_milestone_13_V5;
		bool sp_milestone_14_V5;
		bool sp_milestone_15_V5;
		bool sp_milestone_16_V5;
		bool sp_milestone_17_V5;
		bool sp_milestone_17andHalf_V5;
		bool sp_milestone_18_V5;
		//unlock msterlevel 
		bool sP_masterlevel_unlocked;
		
		bool milestone_5sec_easy_V5;
		bool milestone_3sec_easy_V5;
		bool milestone_1sec_easy_V5;
		bool milestone_5sec_normal_V5;
		bool milestone_3sec_normal_V5;
		bool milestone_1sec_normal_V5;
		bool milestone_5sec_expert_V5;
		bool milestone_3sec_expert_V5;
		bool milestone_1sec_expert_V5;
		bool milestone_5sec_master_V5;
		bool milestone_3sec_master_V5;
		bool milestone_1sec_master_V5;
		//--------------------------------------------------------------
		
	void name_setterFn_V5(string a){
			sPname = a;}
			
		string name_displayFn_V5(){ return sPname;}
		
		void idNum_setterFn_V5(int i){
			sPid = i;}
		
		int idNum_displayFn_V5(){ return sPid;}
		
		int objectsOn_SpList_displayFn_V5(){ return sPlayerOnList_V5;}
		//--------------------------------------------------------------
		// for statistic and display purposes:
		void totalScoreInThisSession_setterFn_V5(int i){
			sP_totalScoreInThisSession_V5 = sP_totalScoreInThisSession_V5 + i;}
		
		int totalScoreInThisSession_displayFn_V5(){ return sP_totalScoreInThisSession_V5;}
		
		void goodAnswerStreek_setterFn_V5(){ // this setts the longest too...
			sP_goodAnswerStreek_V5 = sP_goodAnswerStreek_V5 + 1;
			if(sP_goodAnswerStreek_V5 > sP_longestGoodAnswerStreak_V5){
			sP_longestGoodAnswerStreak_V5 = sP_goodAnswerStreek_V5;}
			//sP_longestGoodAnswerStreakEver_setterFn_V5(sP_longestGoodAnswerStreak_V5);
			else {} 
			}
		int longestGoodAnswerStreak_displayFn_V5(){ return sP_longestGoodAnswerStreak_V5;}
			
		int goodAnswerStreek_dispalyFn_V5(){ return sP_goodAnswerStreek_V5;}
		//setter
		void totalRoundsPlayed_InThisSession_setterFn_V5(int i){
			sP_totalRoundsPlayed_lastSession_V5 = sP_totalRoundsPlayed_lastSession_V5 + i;}
						
		//display
		int totalRoundsPlayed_displayFn_V5(){ return sP_totalRoundsPlayed_lastSession_V5;}
		//-----------------------------------------------------------------------
			
		void lifes_setterFn_V5(int i){
			sP_lifes_V5 = sP_lifes_V5 + i;}
		
		int lifes_displayFn_V5(){ return sP_lifes_V5;}
		
		//reset functions:
		void totalRoundsPlayed_initialiserFn_V5(int n){
			sP_totalRoundsPlayed_lastSession_V5 = n;}
		void totalScoreInThisSession_initialiserFn_V5(int i){
			sP_totalScoreInThisSession_V5 = i;}
		void goodAnswerStreek_initialiserFn_V5(int i){
			sP_goodAnswerStreek_V5 = i;}
		void longestGoodAnswerStreak_initialiserFn_V5(int i){
			sP_longestGoodAnswerStreak_V5 = i;}
		void sP_lifes_V5_initialiserFn(int i){
			sP_lifes_V5 = i;}
		//--------------------------------------------------------------	
		// EXTRA statistick setters, display FNs:
		void sP_sessionGoodAnswerCounter_V5_initializerFn(){ // initialize (invoke) at program start to ZERO
			anyGoodAnswerGiven_lastSession_V5 = 0;}
		void sP_sessionGoodAnswerCounter_setterFn_V5(){ 
			anyGoodAnswerGiven_lastSession_V5 = anyGoodAnswerGiven_lastSession_V5 + 1;} // invoke when good answer...
		int sP_sessionGoodAnswerCounter_V5_displayFn(){
			return anyGoodAnswerGiven_lastSession_V5;}
			
		void sP_lifesLost_inLastSession_initializerFn_V5(){ // initialize (invoke) at program start to ZERO
			lostLifes_counter_lastSessin_V5 = 0;}
		void sP_lifesLost_inLastSession_setterFn_V5(){ // each time it's invoked adds 1 more to total
			lostLifes_counter_lastSessin_V5 = lostLifes_counter_lastSessin_V5 + 1;} // updated allTime record too
		int sP_lifesLost_inLastSession_displayFn_V5(){
			return lostLifes_counter_lastSessin_V5;}
			 
		void sP_lifesLost_allTime_setterFn_V5(int ll){ // ll = lost life in session
			lostLifes_counter_Alltimes_V5 = lostLifes_counter_Alltimes_V5 + ll;} // invoke end of each session
		
		int sP_lifesLost_allTime_displayFn_V5(){return lostLifes_counter_Alltimes_V5;}
		
		void sP_avgScorePerRound_lastSession_setterFn_V5(){ //invoke after total score and rounds set...
			 avgScorePerRound_lastSession_V5 = (float)sP_totalScoreInThisSession_V5 / (float)sP_totalRoundsPlayed_lastSession_V5;}
		float sP_avgScorePerRound_lastSession_displayFn_V5(){
			pAvgScorePerRound_lastSession_V5 = &avgScorePerRound_lastSession_V5;
			return *pAvgScorePerRound_lastSession_V5;}
		void sP_avgLifesPerGoodAnswer_lastSession_setterFn_V5(){
			averageLifeSpentPerGoodAnswer_lastSession_V5 = (float)lostLifes_counter_lastSessin_V5 / (float)anyGoodAnswerGiven_lastSession_V5;}
		float sP_avgLifesPerGoodAnswer_lastSession_displayFn_V5(){
			pAverageLifeSpentPerGoodAnswer_lastSession_V5 = &averageLifeSpentPerGoodAnswer_lastSession_V5;
			return *pAverageLifeSpentPerGoodAnswer_lastSession_V5;}
		
		void sP_attemptCounter_singleSession_initializerFn_V5(){
			attempts_counterForStatistic_singleSession_V5 = 0;} // invoke at start of game loop fn
		void sP_attemptCounter_allTime_initizlizerFn_V5(){
			attempts_counterForStatistic_allTime_V5 = 0;} // invoke at start of game or load data from save file!!!
		
		void sP_attemptCounter_singleSession_setterFn_V5(int i){ 
			attempts_counterForStatistic_singleSession_V5 = attempts_counterForStatistic_singleSession_V5 + i;} // updates aLLTime too
		
		int sP_attemptCounter_singleSession_displayFn_V5(){
			return attempts_counterForStatistic_singleSession_V5;}
		
		void sP_attemptCounter_AllTime_setterFn_V5(int i){ // invoke end of session !!! // attempts_counterForStatistic_singleSession_V5
			attempts_counterForStatistic_allTime_V5 = attempts_counterForStatistic_allTime_V5 + i;}
		int sP_attemptCounter_allTime_displayFn_V5(){
			return attempts_counterForStatistic_allTime_V5;}
		
		void sP_anyGoodAnswerGiven_allTimeFn_setter_V5(int i){ // i = anyGoodAnswerGiven_lastSession_V5
			anyGoodAnswerGiven_Alltimes_V5 = anyGoodAnswerGiven_Alltimes_V5 + i;}
		int sP_anyGoodAnswerGiven_allTimeFn_display_V5(){
			return anyGoodAnswerGiven_Alltimes_V5;}
		
		void sP_allTime_totalRoundsPlayed_setterFn_V5(int sessionTotalRounds){ // invoke at exit game loop
			alltimeRounds_V5 = alltimeRounds_V5 + sessionTotalRounds;} // i = the total rounds in the last session
		int sP_display_allTime_totalRoundsPlayed_V5 (){ // value MUST be UPDATED before display invoked!!!
			pAlltimeRounds_V5 = &alltimeRounds_V5;
			return *pAlltimeRounds_V5;}
		//update to level allTime rounds
		void sP_allTime_rounds_easy_updateFn_V5(int easySessionTotal_round){
			sP_allTime_rounds_easy_V5 = sP_allTime_rounds_easy_V5 + easySessionTotal_round;
		}
		int sP_allTime_rounds_easy_displayFn_V5(){
			return sP_allTime_rounds_easy_V5;
		}
		void sP_allTime_rounds_normal_updateFn_V5(int normalSessionTotal_round){
			sP_allTime_rounds_normal_V5 = sP_allTime_rounds_normal_V5 + normalSessionTotal_round;
		}
		int sP_allTime_rounds_normal_displayFn_V5(){
			return sP_allTime_rounds_normal_V5;
		}
		void sP_allTime_rounds_expert_updateFn_V5(int expertSessionTotal_round){
			sP_allTime_rounds_expert_V5 = sP_allTime_rounds_expert_V5 + expertSessionTotal_round;
		}
		int sP_allTime_rounds_expert_displayFn_V5(){
			return sP_allTime_rounds_expert_V5;
		}
		void sP_allTime_rounds_master_updateFn_V5(int masterSessionTotal_round){
			sP_allTime_rounds_master_V5 = sP_allTime_rounds_master_V5 + masterSessionTotal_round;
		}
		int sP_allTime_rounds_master_displayFn_V5(){
			return sP_allTime_rounds_master_V5;
		}
		//----------------------------------------------------------------------------
		void sP_allTimeScore_initailazerFn_V5(int loadedScore){
			alltimeScore_V5 = loadedScore;}
		void sP_allTimeScore_setterFn_V5(int i){ // invoke at exit session aT + session total
			alltimeScore_V5 = alltimeScore_V5 + i;} 
		int sP_allTimeScore_displayFn_V5(){
			pAlltimeScore_V5 = &alltimeScore_V5;
			return *pAlltimeScore_V5;}
		//update to level sore totals....
				//Invoke at exit.... write session into the appropriate level score as well as for allTotal
		//int sP_allTime_easy_score_V5;
		void sP_allTime_easy_score_updateFn_V5(int easyScore){
			sP_allTime_easy_score_V5 = sP_allTime_easy_score_V5 + easyScore;
		}
		int sP_allTime_easy_score_displayFn_V5(){
			return sP_allTime_easy_score_V5;
		}
		//int sP_allTime_normal_score_V5;
		void sP_allTime_normal_score_updateFn_V5(int normalScore){
			sP_allTime_normal_score_V5 = sP_allTime_normal_score_V5 + normalScore;
		}
		int sP_allTime_normal_score_displayFn_V5(){
			return sP_allTime_normal_score_V5;
		}
		//int sP_allTime_expert_score_V5;
		void sP_allTime_expert_score_updateFn_V5(int expertScore){
			sP_allTime_expert_score_V5 = sP_allTime_expert_score_V5 + expertScore;
		}
		int sP_allTime_expert_score_displayFn_V5(){
			return sP_allTime_expert_score_V5;
		}
		//int sP_allTime_master_score_V5;
		void sP_allTime_master_score_updateFn_V5(int masterScore){
			sP_allTime_master_score_V5 = sP_allTime_master_score_V5 + masterScore;
		}
		int sP_allTime_master_score_displayFn_V5(){
			return sP_allTime_master_score_V5;
		}
		
		//------------------------------------
		
		int sP_previousHighScore_displayFn_V5(){ // setter in New high score Fn
			pPreviousHighScore_inOneSession_V5 = &previousHighScore_inOneSession_V5;
			return *pPreviousHighScore_inOneSession_V5;}
		void sP_newHighScoreInOneSession_setterFn_V5(int i){ // where i = sessions total
			if(i > new_highestScore_inOneSession_V5){
				previousHighScore_inOneSession_V5 = new_highestScore_inOneSession_V5; // sets previous high
				new_highestScore_inOneSession_V5 = i;}}
		int sP_newHighScoreInOneSession_displayFn_V5(){
			pNew_HighestScore_inOneSession_V5 = &new_highestScore_inOneSession_V5;
			return *pNew_HighestScore_inOneSession_V5;}
			
		void sP_avgScorePerRound_allTime_setterFn(){ //invoke after total score and rounds set...
			 avgScorePerRound_allTime_V5 = (float)alltimeScore_V5 / (float)alltimeRounds_V5;}
		float sP_avgScorePerRound_allTime_displayFn(){
			pAvgScorePerRound_allTime_V5 = &avgScorePerRound_allTime_V5;
			return *pAvgScorePerRound_allTime_V5;}
		void sP_avgLifesPerGoodAnswer_allTime_setterFn_V5(){
			allTimeAverageLifeSpentPerGoodAnswer_V5 = (float)lostLifes_counter_Alltimes_V5 / (float)anyGoodAnswerGiven_Alltimes_V5;}
		float sP_avgLifesPerGoodAnswer_allTime_displayFn_V5(){
			pAllTimeAverageLifeSpentPerGoodAnswer_V5 = &allTimeAverageLifeSpentPerGoodAnswer_V5;
			return *pAllTimeAverageLifeSpentPerGoodAnswer_V5;}
		//----------------------------------------------------------------------------------	
		void sP_longestPlayEver_initializerFn_V5(int mostRound_dataLoad){
				longestPlayEver_V5 = mostRound_dataLoad;} // per Single Session All time
					
		void sP_longestPlayEver_setterFn_V5(int i){ // i = total rounds in session
			if(i > longestPlayEver_V5){
				previousLongestPlay_V5 = longestPlayEver_V5;
				longestPlayEver_V5 = i;}
			else{}}
		int sP_longestPlayEver_displayFn_V5(){
			pLongestPlayEver_V5 = &longestPlayEver_V5;
			return *pLongestPlayEver_V5;}
		int sP_previousLongestPlayEver_displayFn_V5(){
			return previousLongestPlay_V5;}
		// longestGoodAnswerStreek and Ever is NOT the same!!!
		// longestGoodAnswerStreek is measured in the Last session ONLY.
		// longestGoodAnswerStreekEver is measured ALL-TIME.
		
		void sP_longestGoodAnswerStreakEver_setterFn_V5(int i){ // i = sP_goodAnswerStreek_V5
			if(i > longest_goodAnswerStreakEver_V5){
			allTime_previousLongestStreak_V5 = longest_goodAnswerStreakEver_V5; // sets previous high
			longest_goodAnswerStreakEver_V5 = i;}} // new record register
		
		int sP_longestGoodAnswerStreakEver_displayFn_V5(){
			return longest_goodAnswerStreakEver_V5;}
		int sP_previousLongestGoodAnswerStreak_everAllT_displayFn_V5(){
			return allTime_previousLongestStreak_V5;}
		
		//invoke it before displayFn
		void sP_milestonesUnlocked_counter_setterFn_V5(int mS_counter){ // milestone unlocked couner from DotH file is feeded into it
			sP_milestonesUnlocked_counter_V5 = mS_counter;}
		int sP_milestonesUnlocked_counter_displayFn_V5(){return sP_milestonesUnlocked_counter_V5;}
		//-------------------------------------------------------------------------------
		//Session counter is an all time record keep prev data and add new to it.
		void sP_sessionCounter_setterFn_V5(int addOne){ // add 1 more each time you start a new game/ session/ play
			sP_sessionCounter_inClass = sP_sessionCounter_inClass + addOne;
			}
		int sP_sessionCounter_displayFn_V5(){
			return sP_sessionCounter_inClass;}
		void sP_sessionCounter_InitalizatorFn_V5(int loadValue){ // invoke it to load value in it from save...
			sP_sessionCounter_inClass = loadValue;}
			
		//color theme
		void sP_chosen_colorScheme_initializerFn_V5(int yourChoice){ //when you choose one, default = 0;
			sP_chosen_colorScheme_V5 = yourChoice;}
			
		int sP_choosen_colorScheme_displayFn_V5(){
			return sP_chosen_colorScheme_V5;}
		//--------------------------------------------------------------
		//leveles
		void sP_chosen_level_initializerFn_V5(int yourLevel){
			sP_chosen_level_V5 = yourLevel;
		}
		int sP_chosen_level_displayFn_V5(){
			return sP_chosen_level_V5;
		}
		//---------------------------------------------------------------------------------------------------	
		//average sec per good answer string -> invoke in display statistic Fn to make the valu up. (allTime)
			void sP_averageTime_spent_per_Goodanswer_allTimeFn_V5(){
				//Rounding to 2 decimals
						float raw_avgSecPerAns;
						raw_avgSecPerAns = sP_totalSecsPassed_toGiveAnsver_V5 / sP_anyGoodAnswerGiven_allTimeFn_display_V5();
						string string_avgSecPerAns;
						float rounded_avgSecPerAns;
						rounded_avgSecPerAns = roundf(raw_avgSecPerAns * 100)/100; // rounding to 2 dec
						if(static_cast<int>(rounded_avgSecPerAns) == rounded_avgSecPerAns){
							string_avgSecPerAns = to_string(static_cast<int>(rounded_avgSecPerAns));}
						else{ 
							string_avgSecPerAns = to_string(rounded_avgSecPerAns);
							//tayloring tailing zeros
							while(!string_avgSecPerAns.empty() && 
									isdigit(string_avgSecPerAns.back()) && string_avgSecPerAns.back()
									== '0') {string_avgSecPerAns.pop_back();}
							}
					//update mP var
					sP_averageSecPerGoodAnswer = string_avgSecPerAns;			
			}
		//--------------------------------------------------------------
		//average sec per good answer string -> invoke in display statistic Fn to make the valu up. (single session)
			void sP_averageTime_spent_per_Goodanswer_SingleSessionFn_V5(){
				//Rounding to 2 decimals
						float raw_avgSecPerAns;
						raw_avgSecPerAns = sP_secsPassedPerGa_singleSessionData / sP_sessionGoodAnswerCounter_V5_displayFn();
						string string_avgSecPerAns;
						float rounded_avgSecPerAns;
						rounded_avgSecPerAns = roundf(raw_avgSecPerAns * 100)/100; // rounding to 2 dec
						if(static_cast<int>(rounded_avgSecPerAns) == rounded_avgSecPerAns){
							string_avgSecPerAns = to_string(static_cast<int>(rounded_avgSecPerAns));}
						else{ 
							string_avgSecPerAns = to_string(rounded_avgSecPerAns);
							//tayloring tailing zeros
							while(!string_avgSecPerAns.empty() && 
									isdigit(string_avgSecPerAns.back()) && string_avgSecPerAns.back()
									== '0') {string_avgSecPerAns.pop_back();}
							}
					//update mP var
					sP_avgSecsPassed_perGoodAnswer_SingleSessionData = string_avgSecPerAns;			
			}
			//--------------------------------------------------------------------------------------
			void sp_updatePassedTimeVarsFn_V5(double passedTimeSecs){
				//update single session data (this will be zeroed out before each session)
				sP_secsPassedPerGa_singleSessionData = sP_secsPassedPerGa_singleSessionData + passedTimeSecs;
				//update Alltime record (this will be saved & loaded)
				sP_totalSecsPassed_toGiveAnsver_V5 = sP_totalSecsPassed_toGiveAnsver_V5 + passedTimeSecs;
			}
			void sP_secsPassedPerGa_singleSessionData_resetFn_V5(){ //invoke at the beggining of loop
				sP_secsPassedPerGa_singleSessionData = 0;
			}
		//--------------------------------------------------------------
		//new
		//session_play_timeFn
		void sP_last_session_play_timeFn_V5(double playTimeSecs){
			sP_last_session_play_time_V5 = playTimeSecs;
		}
		//to display data in string
		string sP_last_session_play_time_string_displayFnV5(){
				//Rounding to 2 decimals
						float raw_passed_Secs;
						string string_passed_Secs;
						float rounded_passed_Secs;
						
						
						//display time in minutes
						if(sP_last_session_play_time_V5 > 60 && sP_last_session_play_time_V5 < 3600){
							raw_passed_Secs = sP_last_session_play_time_V5/60;
							
								rounded_passed_Secs = roundf(raw_passed_Secs * 100)/100; // rounding to 2 dec
							if(static_cast<int>(rounded_passed_Secs) == rounded_passed_Secs){
								string_passed_Secs = to_string(static_cast<int>(rounded_passed_Secs));}
							else{ 
								string_passed_Secs = to_string(rounded_passed_Secs);
								//tayloring tailing zeros
								while(!string_passed_Secs.empty() && 
										isdigit(string_passed_Secs.back()) && string_passed_Secs.back()
										== '0') {string_passed_Secs.pop_back();}
								}
								//update string var to display min, hours, days
								sP_string_last_session_play_time_V5 = string_passed_Secs + " min";
								return sP_string_last_session_play_time_V5;			
						}
						//display time in hours
						if(sP_last_session_play_time_V5 > 3600 && sP_last_session_play_time_V5 < 86400){
							raw_passed_Secs = sP_last_session_play_time_V5/3600;
							
							rounded_passed_Secs = roundf(raw_passed_Secs * 100)/100; // rounding to 2 dec
						if(static_cast<int>(rounded_passed_Secs) == rounded_passed_Secs){
							string_passed_Secs = to_string(static_cast<int>(rounded_passed_Secs));}
						else{ 
							string_passed_Secs = to_string(rounded_passed_Secs);
							//tayloring tailing zeros
							while(!string_passed_Secs.empty() && 
									isdigit(string_passed_Secs.back()) && string_passed_Secs.back()
									== '0') {string_passed_Secs.pop_back();}
							}
							//update string var to display min, hours, days
							sP_string_last_session_play_time_V5 = string_passed_Secs + " hour";
							return sP_string_last_session_play_time_V5;
						}
						//dispaly time in days
						//...not needed to session time
						
					// if passed time less then a minute
						else if(sP_last_session_play_time_V5 < 60){
							sP_string_last_session_play_time_V5 = to_string(int(sP_last_session_play_time_V5)) + " sec";
							return sP_string_last_session_play_time_V5;}	
			}
		//------------------------------------------------------------------------------------------	
		//allTime Session_play_timeFn
		void sP_allTime_session_play_timeFn_V5(){
			sP_allTime_session_play_time_V5 = sP_allTime_session_play_time_V5 + sP_last_session_play_time_V5;
		}
		// string display allTime playTime
		string sP_allTime_session_play_time_string_displayFnV5(){
				//Rounding to 2 decimals
						float raw_passed_Secs;
						string string_passed_Secs;
						float rounded_passed_Secs;
						
						//display time in minutes
						if(sP_allTime_session_play_time_V5 > 60 && sP_allTime_session_play_time_V5 < 3600){
							
							raw_passed_Secs = sP_allTime_session_play_time_V5/60;
							rounded_passed_Secs = roundf(raw_passed_Secs * 100)/100; // rounding to 2 dec
						
							if(static_cast<int>(rounded_passed_Secs) == rounded_passed_Secs){
								string_passed_Secs = to_string(static_cast<int>(rounded_passed_Secs));}
							
							else{ 
								string_passed_Secs = to_string(rounded_passed_Secs);
								//tayloring tailing zeros
								while(!string_passed_Secs.empty() && 
										isdigit(string_passed_Secs.back()) && string_passed_Secs.back()
										== '0') {string_passed_Secs.pop_back();}
								}
								
							//update string var to display min, hours, days
							sP_string_allTime_session_play_time_V5 = string_passed_Secs + " min";
							return sP_string_allTime_session_play_time_V5;			
						}
						
						//display time in hours
						if(sP_allTime_session_play_time_V5 > 3600 && sP_allTime_session_play_time_V5 < 86400){
							raw_passed_Secs = sP_allTime_session_play_time_V5/3600;
							
							rounded_passed_Secs = roundf(raw_passed_Secs * 100)/100; // rounding to 2 dec
						if(static_cast<int>(rounded_passed_Secs) == rounded_passed_Secs){
							string_passed_Secs = to_string(static_cast<int>(rounded_passed_Secs));}
						else{ 
							string_passed_Secs = to_string(rounded_passed_Secs);
							//tayloring tailing zeros
							while(!string_passed_Secs.empty() && 
									isdigit(string_passed_Secs.back()) && string_passed_Secs.back()
									== '0') {string_passed_Secs.pop_back();}
							}
							//update string var to display min, hours, days
							sP_string_allTime_session_play_time_V5 = string_passed_Secs + " hour";
							return sP_string_allTime_session_play_time_V5;
						}
						//dispaly time in days
						if(sP_allTime_session_play_time_V5 > 86400){
							raw_passed_Secs = sP_allTime_session_play_time_V5/86400;
							
							rounded_passed_Secs = roundf(raw_passed_Secs * 100)/100; // rounding to 2 dec
						if(static_cast<int>(rounded_passed_Secs) == rounded_passed_Secs){
							string_passed_Secs = to_string(static_cast<int>(rounded_passed_Secs));}
						else{ 
							string_passed_Secs = to_string(rounded_passed_Secs);
							//tayloring tailing zeros
							while(!string_passed_Secs.empty() && 
									isdigit(string_passed_Secs.back()) && string_passed_Secs.back()
									== '0') {string_passed_Secs.pop_back();}
							}
							//update string var to display min, hours, days
							sP_string_allTime_session_play_time_V5 = string_passed_Secs + " day";
							return sP_string_allTime_session_play_time_V5;
						}
						
						// if passed time less then a minute
						else if(sP_allTime_session_play_time_V5 < 60){
							sP_string_allTime_session_play_time_V5 = to_string(int(sP_allTime_session_play_time_V5)) + " sec";
							return sP_string_allTime_session_play_time_V5;}
						
			}
			
			
		//------------------------------------------------------------------------------------------
		//check for shortest and longest time spent to give Good answer method
		void check_time_spent_to_give_goodAnswer_quickestAndSlowestFn_V5(double timePassedTo_give_gA){
			//if there is no data yet to compare
			if(sP_shortest_time_goodAnswerGiven_lastSession_V5 == 0){
				sP_shortest_time_goodAnswerGiven_lastSession_V5 = timePassedTo_give_gA;
				//update allTime data (1st time use, or no save file)
				if(sp_shortest_time_goodAnswerGiven_allTime_V5 == 0){
				sp_shortest_time_goodAnswerGiven_allTime_V5 = sP_shortest_time_goodAnswerGiven_lastSession_V5;
				}
				//if 1st attemt is the new all time record
				if(timePassedTo_give_gA < sp_shortest_time_goodAnswerGiven_allTime_V5){
					sp_shortest_time_goodAnswerGiven_allTime_V5 = timePassedTo_give_gA;
				}
			}
			
			//if there is data to compare
			if(sP_shortest_time_goodAnswerGiven_lastSession_V5 > timePassedTo_give_gA){
				sP_shortest_time_goodAnswerGiven_lastSession_V5 = timePassedTo_give_gA;
				//update allTime data
				if(sp_shortest_time_goodAnswerGiven_allTime_V5 > sP_shortest_time_goodAnswerGiven_lastSession_V5){
					sp_shortest_time_goodAnswerGiven_allTime_V5 = sP_shortest_time_goodAnswerGiven_lastSession_V5;
				}
			}
			
			if(sP_longest_time_goodAnswerGiven_lastSession_V5 < timePassedTo_give_gA){
				sP_longest_time_goodAnswerGiven_lastSession_V5 = timePassedTo_give_gA;
				//update allTime record
					if(sp_longest_time_goodAnswerGiven_allTime_V5 < sP_longest_time_goodAnswerGiven_lastSession_V5){
						sp_longest_time_goodAnswerGiven_allTime_V5 = sP_longest_time_goodAnswerGiven_lastSession_V5;
					}
			}
			
			else{}
			
		}
		//reset shortest, longest (session vars) answer to zero before each session
		void sP_shortest_time_goodAnswerGiven_lastSession_V5_initializerFN(int zero){
			sP_shortest_time_goodAnswerGiven_lastSession_V5 = zero;
		};
		void sP_longest_time_goodAnswerGiven_lastSession_V5_initializerFN(int zero){
			sP_longest_time_goodAnswerGiven_lastSession_V5 = zero;
		};
		//---------------
		//Tylor time data and turn to string for statistic display
		void sP_shortest_time_goodAnswerGiven_lastSession_displayFnV5(){
				//Rounding to 2 decimals
						float raw_shortest_SecPerAns;
						raw_shortest_SecPerAns = sP_shortest_time_goodAnswerGiven_lastSession_V5;
						string string_shortest_SecPerAns;
						float rounded_shortest_SecPerAns;
						rounded_shortest_SecPerAns = roundf(raw_shortest_SecPerAns * 100)/100; // rounding to 2 dec
						if(static_cast<int>(rounded_shortest_SecPerAns) == rounded_shortest_SecPerAns){
							string_shortest_SecPerAns = to_string(static_cast<int>(rounded_shortest_SecPerAns));}
						else{ 
							string_shortest_SecPerAns = to_string(rounded_shortest_SecPerAns);
							//tayloring tailing zeros
							while(!string_shortest_SecPerAns.empty() && 
									isdigit(string_shortest_SecPerAns.back()) && string_shortest_SecPerAns.back()
									== '0') {string_shortest_SecPerAns.pop_back();}
							}
					//update string var
					sP_string_shortest_time_goodAnswerGiven_lastSession_V5 = string_shortest_SecPerAns + " sec";			
			}
		//----------------------------------------
		void sP_longest_time_goodAnswerGiven_lastSession_displayFnV5(){
				//Rounding to 2 decimals
						float raw_longest_SecPerAns;
						raw_longest_SecPerAns = sP_longest_time_goodAnswerGiven_lastSession_V5;
						string string_longest_SecPerAns;
						float rounded_longest_SecPerAns;
						rounded_longest_SecPerAns = roundf(raw_longest_SecPerAns * 100)/100; // rounding to 2 dec
						if(static_cast<int>(rounded_longest_SecPerAns) == rounded_longest_SecPerAns){
							string_longest_SecPerAns = to_string(static_cast<int>(rounded_longest_SecPerAns));}
						else{ 
							string_longest_SecPerAns = to_string(rounded_longest_SecPerAns);
							//tayloring tailing zeros
							while(!string_longest_SecPerAns.empty() && 
									isdigit(string_longest_SecPerAns.back()) && string_longest_SecPerAns.back()
									== '0') {string_longest_SecPerAns.pop_back();}
							}
					//update string var
					sP_string_longest_time_goodAnswerGiven_lastSession_V5 = string_longest_SecPerAns + " sec";			
			}
			//------------------------------------------
			void sp_shortest_time_goodAnswerGiven_allTime_V5_displayFnV5(){
				//Rounding to 2 decimals
						float raw_shortest_SecPerAns;
						raw_shortest_SecPerAns = sp_shortest_time_goodAnswerGiven_allTime_V5;
						string string_shortest_SecPerAns;
						float rounded_shortest_SecPerAns;
						rounded_shortest_SecPerAns = roundf(raw_shortest_SecPerAns * 100)/100; // rounding to 2 dec
						if(static_cast<int>(rounded_shortest_SecPerAns) == rounded_shortest_SecPerAns){
							string_shortest_SecPerAns = to_string(static_cast<int>(rounded_shortest_SecPerAns));}
						else{ 
							string_shortest_SecPerAns = to_string(rounded_shortest_SecPerAns);
							//tayloring tailing zeros
							while(!string_shortest_SecPerAns.empty() && 
									isdigit(string_shortest_SecPerAns.back()) && string_shortest_SecPerAns.back()
									== '0') {string_shortest_SecPerAns.pop_back();}
							}
					//update string var
					sp_string_shortest_time_goodAnswerGiven_allTime_V5 = string_shortest_SecPerAns + " sec";			
			}
			//-------------------------------
			void sp_longest_time_goodAnswerGiven_allTime_V5_displayFnV5(){
				//Rounding to 2 decimals
						float raw_longest_SecPerAns;
						raw_longest_SecPerAns = sp_longest_time_goodAnswerGiven_allTime_V5;
						string string_longest_SecPerAns;
						float rounded_longest_SecPerAns;
						rounded_longest_SecPerAns = roundf(raw_longest_SecPerAns * 100)/100; // rounding to 2 dec
						if(static_cast<int>(rounded_longest_SecPerAns) == rounded_longest_SecPerAns){
							string_longest_SecPerAns = to_string(static_cast<int>(rounded_longest_SecPerAns));}
						else{ 
							string_longest_SecPerAns = to_string(rounded_longest_SecPerAns);
							//tayloring tailing zeros
							while(!string_longest_SecPerAns.empty() && 
									isdigit(string_longest_SecPerAns.back()) && string_longest_SecPerAns.back()
									== '0') {string_longest_SecPerAns.pop_back();}
							}
					//update string var
					sp_string_longest_time_goodAnswerGiven_allTime_V5 = string_longest_SecPerAns + " sec";			
			}
		//------------------------------------------------------------------------------------------
		
		//------------------------------------------------------------------------------------------	
		void sP_update_statistic_varsFn_V5(){
			
			//sP_lifesLost_allTime_setterFn_V5(lostLifes_counter_lastSessin_V5);
			sP_longestGoodAnswerStreakEver_setterFn_V5(sP_longestGoodAnswerStreak_V5);
			sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress_inDotH);
			sP_newHighScoreInOneSession_setterFn_V5(sP_totalScoreInThisSession_V5);
			sP_longestPlayEver_setterFn_V5(sP_totalRoundsPlayed_lastSession_V5);
			sP_avgLifesPerGoodAnswer_lastSession_setterFn_V5();
			sP_avgLifesPerGoodAnswer_allTime_setterFn_V5();
			sP_averageTime_spent_per_Goodanswer_allTimeFn_V5();
			sP_averageTime_spent_per_Goodanswer_SingleSessionFn_V5();
			//sP_last_session_play_time_displayFnV5();
			//sP_allTime_session_play_time_displayFnV5();
			sP_shortest_time_goodAnswerGiven_lastSession_displayFnV5();
			sP_longest_time_goodAnswerGiven_lastSession_displayFnV5();
			sp_shortest_time_goodAnswerGiven_allTime_V5_displayFnV5();
			sp_longest_time_goodAnswerGiven_allTime_V5_displayFnV5();
		};
		//Statistics display fn:
		void sP_statisticsDisplayFn_V5(){
				
			sP_update_statistic_varsFn_V5();
			//-----------------------------------------------
			fflush(stdout);
			system("clear");
			
			cout<<endl;
			cout<<"                         \33[1m*** STATISTICS ***\33[0m\n"
				<<"---------------------------------------------------------------------------"<<endl;
			
			cout<<BBLACK<<"Player's name:       "<<BRIGHT<<sPname<<RSTA<<endl;
			//cout<<"Player's ID:         "<<BRIGHT<<sPid<<RSTA<<endl;
			cout<<endl;
			//cout<<"----------------------- LAST SESSION DATA ---------------------------------\n"<<endl;
			cout<<"\33[1mRECORDS from the LAST SESSION:\33[0m"
				<<"\n"<<endl;
			//new
			cout<<"Last session's play time: "<<BRIGHT<<sP_last_session_play_time_string_displayFnV5()<<RSTA<<"\n";
			//---
			cout<<BBLACK<<"Total rounds played in last session:    "<<BRIGHT<<sP_totalRoundsPlayed_lastSession_V5<<RSTA<<"\n"
				<<"Total score made during last session:    "<<BRIGHT<<sP_totalScoreInThisSession_V5<<RSTA<<"\n";
			cout<<BBLACK<<"Average score per round:      ";
			if(sP_totalScoreInThisSession_V5 == 0){cout<<BRIGHT<<sRoundedAnswer<<RSTA<<endl;}
			else{		
						avgScorePerRound_lastSession_V5 = (float)sP_totalScoreInThisSession_V5 / (float)sP_totalRoundsPlayed_lastSession_V5;
						//Rounding to 2 decimals
						double roundedAnswerFloat;
						roundedAnswerFloat = roundf(avgScorePerRound_lastSession_V5 * 100)/100;
						if(static_cast<int>(roundedAnswerFloat) == roundedAnswerFloat){
							sRoundedAnswer = to_string(static_cast<int>(roundedAnswerFloat));}
						else{ 
							sRoundedAnswer = to_string(roundedAnswerFloat);
							while(!sRoundedAnswer.empty() && 
									isdigit(sRoundedAnswer.back()) && sRoundedAnswer.back()
									== '0') {sRoundedAnswer.pop_back();}
							}//convert to string
						cout<<BRIGHT<<sRoundedAnswer<<RSTA<<endl;
						}	
			cout<<"Amount of attempts made in last session: "<<BRIGHT<<attempts_counterForStatistic_singleSession_V5<<RSTA"\n"
				<<BBLACK<<"Good answer given: "<<BRIGHT<<sP_sessionGoodAnswerCounter_V5_displayFn()<<RSTA"\n";	
			cout<<"Attempt per good answer ratio: ";
			//<<(float)attempts_counterForStatistic_singleSession_V5 / (float)anyGoodAnswerGiven_lastSession_V5<<"\n"
			if(attempts_counterForStatistic_singleSession_V5 == 0){
				cout<<BRIGHT<<"There is nothing to count..."<<RSTA<<endl;}
			else{		
						sP_attemptPerGoodAnwerRatio_singleSession_V5 = (float)attempts_counterForStatistic_singleSession_V5 / (float)anyGoodAnswerGiven_lastSession_V5;
						//Rounding to 2 decimals
						double roundedAnswerFloat;
						string sroundAnswer;
						roundedAnswerFloat = roundf(sP_attemptPerGoodAnwerRatio_singleSession_V5 * 100)/100;
						if(static_cast<int>(roundedAnswerFloat) == roundedAnswerFloat){
							sroundAnswer = to_string(static_cast<int>(roundedAnswerFloat));}
						else{ 
							sroundAnswer = to_string(roundedAnswerFloat);
							while(!sroundAnswer.empty() && 
									isdigit(sroundAnswer.back()) && sroundAnswer.back()
									== '0') {sroundAnswer.pop_back();}
							}//convert to string
						cout<<BRIGHT<<sroundAnswer<<RSTA<<endl;
						}	
			cout<<BBLACK<<"Longest good answer streak you've had:  "<<BRIGHT<<sP_longestGoodAnswerStreak_V5<<RSTA<<"\n"
				<<"Lifes lost in last session: "<<BRIGHT<<lostLifes_counter_lastSessin_V5<<RSTA<<"\n"
				<<BBLACK<<"Life lost per good answer last session: "<<BRIGHT<<sP_avgLifesPerGoodAnswer_lastSession_displayFn_V5()<<RSTA<<"\n";
				
			cout<<"Average time spent by giving good answer last session: ";
			cout<<BRIGHT<<sP_avgSecsPassed_perGoodAnswer_SingleSessionData<<"sec"<<RSTA<<"\n";
			cout<<BBLACK<<"Shortest time spent to give good answer in last session: "<<BRIGHT;
				if(sP_totalScoreInThisSession_V5 == 0){ cout<<"N/A"<<RSTA<<"\n";}
				else{cout<<sP_string_shortest_time_goodAnswerGiven_lastSession_V5<<RSTA<<"\n";}
			cout<<"Longest time spent to give good answer in last session: "<<BRIGHT;
				if(sP_totalScoreInThisSession_V5 == 0){ cout<<"N/A"<<RSTA<<"\n";}
				else{cout<<sP_string_longest_time_goodAnswerGiven_lastSession_V5<<RSTA<<"\n";}
				cout<<endl;
			cout<<"Press \33[1mENTER\33[0m to Continue..."<<endl;
			fflush(stdin);
			cin.get();
			cin.get();	
			//cout<<"-------------------------------- ALL-TIME DATA ----------------------------\n"<<endl;
			cout<<"---------------------------------------------------------------------------"<<RSTA<<"\n";
			cout<<BRIGHT<<"ALL-TIME RECORDS:"<<RSTA
				<<"\n"<<RSTA<<endl;
			cout<<"All-time play time: "<<BRIGHT<<sP_allTime_session_play_time_string_displayFnV5()<<RSTA<<"\n";
			cout<<BBLACK<<"All-time rounds you've played: "<<BRIGHT<<sP_display_allTime_totalRoundsPlayed_V5()<<RSTA<<"\n"
				<<"Total rounds played on EASY : "<<BRIGHT<<sP_allTime_rounds_easy_displayFn_V5()<<RSTA<<" | "
				<<"NORMAL: "<<BRIGHT<<sP_allTime_rounds_normal_displayFn_V5()<<RSTA<<" | "
				<<"EXPERT: "<<BRIGHT<<sP_allTime_rounds_expert_displayFn_V5()<<RSTA;
				if(sP_allTime_rounds_master_displayFn_V5() == 0){cout<<"\n";}
				if(sP_allTime_rounds_master_displayFn_V5() > 0){cout<<" | MASTER: "<<BRIGHT<<sP_allTime_rounds_master_displayFn_V5()<<RSTA<<"\n";}
				cout<<BBLACK<<"All-time score you've scored:  "<<BRIGHT<<sP_allTimeScore_displayFn_V5()<<RSTA<<"\n"
				<<"Total score on EASY: "<<BRIGHT<<sP_allTime_easy_score_displayFn_V5()<<RSTA<<" | "
				<<"NORMAL: "<<BRIGHT<<sP_allTime_normal_score_displayFn_V5()<<RSTA<<" | "
				<<"EXPERT: "<<BRIGHT<<sP_allTime_expert_score_displayFn_V5()<<RSTA;
				if(sP_allTime_master_score_displayFn_V5() == 0){cout<<"\n";}
				if(sP_allTime_master_score_displayFn_V5() > 0){cout<<" | MASTER: "<<BRIGHT<<sP_allTime_master_score_displayFn_V5()<<RSTA<<"\n";}
				cout<<BBLACK<<"Most round played in a single session: "<<BRIGHT<<sP_longestPlayEver_displayFn_V5()<<RSTA<<"\n" // if new record -> message at game over... (show previous Highs too)
				<<"Previous most round played in a single session: "<<BRIGHT<<sP_previousLongestPlayEver_displayFn_V5()<<RSTA<<"\n"
				<<BBLACK<<"Highest score in a single session: "<<BRIGHT<<new_highestScore_inOneSession_V5<<RSTA<<"\n" //from file stored
				<<"Previous highest score in a single session: "<<BRIGHT<<previousHighScore_inOneSession_V5<<RSTA<<"\n"; //for achivement comparation
			//screan break...
			cout<<endl;
			cout<<"Press \33[1mENTER\33[0m to continue...\n"<<endl;
			cin.get();
			
			cout<<BBLACK<<"All-time average score per round: ";
				if(alltimeScore_V5 == 0){cout<<BRIGHT<<"N/A"<<RSTA<<endl;}
				else{
						avgScorePerRound_allTime_V5 = (float)sP_allTimeScore_displayFn_V5() / (float)sP_display_allTime_totalRoundsPlayed_V5();
						//Rounding to 2 decimals
						double roundedAnswerFloat_allt;
						string s_av_scPer_round_string;
						roundedAnswerFloat_allt = roundf(avgScorePerRound_allTime_V5 * 100)/100;
						if(static_cast<int>(roundedAnswerFloat_allt) == roundedAnswerFloat_allt){
							s_av_scPer_round_string = to_string(static_cast<int>(roundedAnswerFloat_allt));}
						else{ 
							s_av_scPer_round_string = to_string(roundedAnswerFloat_allt);
							while(!s_av_scPer_round_string.empty() && 
									isdigit(s_av_scPer_round_string.back()) && s_av_scPer_round_string.back()
									== '0') {s_av_scPer_round_string.pop_back();}
							}//convert to string
							
						//string answer
						cout<<BRIGHT<<s_av_scPer_round_string<<RSTA<<endl;
						
						}	 //allTime
						
			//cout<<"A.T. avg S/R: "<<(float)sP_allTimeScore_displayFn_V5() / (float)sP_display_allTime_totalRoundsPlayed_V5()<<endl;
			cout<<"All-time good answer given:    "<<BRIGHT<<sP_anyGoodAnswerGiven_allTimeFn_display_V5()<<RSTA<<"\n"
				<<BBLACK<<"All-time longest good answer streak: "<<BRIGHT<<sP_longestGoodAnswerStreakEver_displayFn_V5()<<RSTA<<"\n"
				<<"all-time prev longest good answer streak: "<<BRIGHT<<sP_previousLongestGoodAnswerStreak_everAllT_displayFn_V5()<<RSTA<<"\n"
				<<BBLACK<<"All-time lifes lost: "<<BRIGHT<<sP_lifesLost_allTime_displayFn_V5()<<RSTA<<"\n"
				<<"All-time average life lost per good answer: ";
			//<<sP_avgLifesPerGoodAnswer_allTime_displayFn_V5()<<"\n"; // count it before exitinggame loop
			if(sP_lifesLost_allTime_displayFn_V5() == 0){cout<<BRIGHT<<"Zero ... yet :)"<<RSTA<<endl;}
			if(sP_anyGoodAnswerGiven_allTimeFn_display_V5() == 0){cout<<BRIGHT<<"No good answer given so far... Bu-hoo..."<<RSTA<<endl;}
				else{
						allTimeAverageLifeSpentPerGoodAnswer_V5 = (float)sP_lifesLost_allTime_displayFn_V5() / (float)sP_anyGoodAnswerGiven_allTimeFn_display_V5();
						//Rounding to 2 decimals
						double roundedAnswerFloat_all;
						string sAns;
						roundedAnswerFloat_all = roundf(allTimeAverageLifeSpentPerGoodAnswer_V5 * 100)/100;
						if(static_cast<int>(roundedAnswerFloat_all) == roundedAnswerFloat_all){
							sAns = to_string(static_cast<int>(roundedAnswerFloat_all));}
						else{ 
							sAns = to_string(roundedAnswerFloat_all);
							while(!sAns.empty() && 
									isdigit(sAns.back()) && sAns.back()
									== '0') {sAns.pop_back();}
							}//convert to string
						cout<<BRIGHT<<sAns<<RSTA<<endl;
						}
			
			cout<<BBLACK<<"All-time attempts made: "<<BRIGHT<<sP_attemptCounter_allTime_displayFn_V5()<<RSTA<<endl;
			cout<<"All-time attempt per good answer ratio: ";
			//<<(float)attempts_counterForStatistic_allTime_V5 / (float)anyGoodAnswerGiven_Alltimes_V5<<"\n"
			if(attempts_counterForStatistic_allTime_V5 == 0){cout<<BRIGHT<<"You never tried to answer yet..."<<RSTA<<endl;}
			//if(attempts_counterForStatistic_allTime_V5 == 0){cout<<"You never gave a good answer yet..."<<endl;}
				else{
						sP_attemptPerGoodAnwerRatio_allTime_V5 = (float)attempts_counterForStatistic_allTime_V5 / (float)anyGoodAnswerGiven_Alltimes_V5;
						//Rounding to 2 decimals
						double roundedAnswerFloat_allApG;
						string sApG;
						roundedAnswerFloat_allApG = roundf(sP_attemptPerGoodAnwerRatio_allTime_V5 * 100)/100;
						if(static_cast<int>(roundedAnswerFloat_allApG) == roundedAnswerFloat_allApG){
							sApG = to_string(static_cast<int>(roundedAnswerFloat_allApG));}
						else{ 
							sApG = to_string(roundedAnswerFloat_allApG);
							while(!sApG.empty() && 
									isdigit(sApG.back()) && sApG.back()
									== '0') {sApG.pop_back();}
							}//convert to string
						cout<<BRIGHT<<sApG<<RSTA<<endl;
						}
			cout<<BBLACK<<"Amount of sessions played by you so far: "<<BRIGHT<<sP_sessionCounter_displayFn_V5()<<RSTA<<endl;
			cout<<"All-time shortest given good answer: "<<BRIGHT<<sp_string_shortest_time_goodAnswerGiven_allTime_V5<<RSTA<<"\n";
			cout<<BBLACK<<"All-time longest given good answer: "<<BRIGHT<<sp_string_longest_time_goodAnswerGiven_allTime_V5<<RSTA<<"\n";
			cout<<"Average time spent by giving good answer, all-time: "<<BRIGHT<<sP_averageSecPerGoodAnswer<<" sec"<<RSTA<<endl;	
			cout<<BBLACK<<"Milestones unlocked: "<<BRIGHT<<sP_milestonesUnlocked_counter_displayFn_V5()<<"/31"<<RSTA<<"\n"
				<<endl;
			}
			
	//------------------------------------------------------------------			
	protected:
		string sPname;
		int sPid; //Fn-ed
		int sPlayerOnList_V5; //Fn-ed
		int sP_totalScoreInThisSession_V5; // tick Fn-ed
		int sP_goodAnswerStreek_V5; // tick Fn-ed
		int sP_longestGoodAnswerStreak_V5; // tick Fn-ed
		int sP_totalRoundsPlayed_lastSession_V5; // tick Fn-ed
		int sP_lifes_V5; // Fn-ed
		//--------------------------
		int sP_chosen_level_V5; //(1,2,3,4) 4 - is master level -> unlockable
		//+
		int anyGoodAnswerGiven_lastSession_V5; //thick, Fn-ed
		int lostLifes_counter_lastSessin_V5; // tick, Fn-ed
		float avgScorePerRound_lastSession_V5; //in One/last session tick
		float *pAvgScorePerRound_lastSession_V5; // used
		float averageLifeSpentPerGoodAnswer_lastSession_V5; // thick Fn-ed
		float *pAverageLifeSpentPerGoodAnswer_lastSession_V5; // used
		int attempts_counterForStatistic_singleSession_V5; // thick Fn-ed
		//--------------------------
		//for alltime statistics
		int attempts_counterForStatistic_allTime_V5; // = all single session's data,  invoke Fn before display!!! thick, Fn-ed
		float sP_attemptPerGoodAnwerRatio_singleSession_V5;
		float sP_attemptPerGoodAnwerRatio_allTime_V5;
		int anyGoodAnswerGiven_Alltimes_V5; // thick Fn-ed
		int lostLifes_counter_Alltimes_V5; // thick Fn-ed
		int alltimeRounds_V5; // thick Fn-ed
		int *pAlltimeRounds_V5; // used
		int alltimeScore_V5; // thick Fn-ed
		int* pAlltimeScore_V5; // used
		int previousHighScore_inOneSession_V5; //for achivement comparation // thick Fn-ed
		int* pPreviousHighScore_inOneSession_V5; // used
		int new_highestScore_inOneSession_V5; //from file stored // thick Fn-ed
		int* pNew_HighestScore_inOneSession_V5; //evaluate before display, used
		float avgScorePerRound_allTime_V5; //allTime thick Fn-ed
		float *pAvgScorePerRound_allTime_V5; // used
		float allTimeAverageLifeSpentPerGoodAnswer_V5; // count it before exitinggame loop thick, Fn-ed
		float *pAllTimeAverageLifeSpentPerGoodAnswer_V5; // used
		int longestPlayEver_V5; // if new record -> message at game over... (show previous Highs too) thick, Fn-ed
		int *pLongestPlayEver_V5; //before all yur life gone highest number of rounds, evaluate , used
		int previousLongestPlay_V5; // Fn-ed
		int longest_goodAnswerStreakEver_V5; //play without losing any life thick Fn-ed
		int* pLongest_goodAnswerStreakEver_V5; // Fn-ed, used
		int allTime_previousLongestStreak_V5; // thick Fn-ed
		int sP_milestonesUnlocked_counter_V5;
		string sRoundedAnswer; // for avg score per round in last session
		string sRoundedAnswerAllT; // for avg score per round all-time
		int sP_sessionCounter_inClass;
		int sP_chosen_colorScheme_V5; // 0 = Default, ... 4 = Winter	
		//bool sP_inClass_easySwitch_V5;
		//bool sP_inClass_expertSwitch_V5;
		//time passed
		double sP_last_session_play_time_V5;
		string sP_string_last_session_play_time_V5;
		double sP_allTime_session_play_time_V5;
		string sP_string_allTime_session_play_time_V5;
		double sP_totalSecsPassed_toGiveAnsver_V5; //alltime var
		string sP_averageSecPerGoodAnswer; // comes from invoked function wich prosess data, and "returns" this string (allTime)
		double sP_secsPassedPerGa_singleSessionData; // single session data (total of 1 session)
		string sP_avgSecsPassed_perGoodAnswer_SingleSessionData; //(secsPassed in 1 session with thinking on answer / round)
		//check after each round, and update...
		double sP_shortest_time_goodAnswerGiven_lastSession_V5;
		double sP_longest_time_goodAnswerGiven_lastSession_V5;
		double sp_shortest_time_goodAnswerGiven_allTime_V5;
		double sp_longest_time_goodAnswerGiven_allTime_V5;
		string sP_string_shortest_time_goodAnswerGiven_lastSession_V5;
		string sP_string_longest_time_goodAnswerGiven_lastSession_V5;
		string sp_string_shortest_time_goodAnswerGiven_allTime_V5;
		string sp_string_longest_time_goodAnswerGiven_allTime_V5;
		//---------------------------------------------------------
		int sP_allTime_easy_score_V5;
		int sP_allTime_normal_score_V5;
		int sP_allTime_expert_score_V5;
		int sP_allTime_master_score_V5;
		//-------------------------------------------------------------
		int sP_allTime_rounds_easy_V5;
		int sP_allTime_rounds_normal_V5;
		int sP_allTime_rounds_expert_V5;
		int sP_allTime_rounds_master_V5;
	//------------------------------------------------------------------
		

};
//----------------------------------------------------------------------
//======================================================================
class MplayerClass {
	
	public:
		MplayerClass(string& name) : // CONSTRUCTOR
			mPname_V5(name){
				mPpersonOnList++;
				mPplayerOnList_V5 = mPpersonOnList;
				// initialize some vars at construction
			mP_totalRoundsPlayed_V5 = 0;
			mP_totalScoreInThisSession_V5 = 0;
			mP_goodAnswerStreek_V5 = 0;
			mP_longestGoodAnswerStreak_V5 = 0;
			mP_lifes_V5 = 3;
			mP_skip_V5 = 3;
			mP_currentRound_V5 = 0;
			mP_Total_secsPassed_V5 = 0;
			mP_Alltime_avgSecPerAns = "n/a";} // T.sec/T.a
			
		string mP_serializeFn_V5() {
			string mP_serialString = "dotdotdot";
			return mP_serialString;}
		//--------------------------------------------------------------
		//Name
		void mP_name_setterFn_V5(string a){
			mPname_V5 = a;}
		string mP_name_displayFn_V5(){ return mPname_V5;}
		//ID
		void mP_idNum_setterFn_V5(int i){
			mPid = i;}
		int mP_idNum_displayFn_V5(){ return mPid;}
		//Object on list counter displayFn
		int mP_objectsOn_SpList_displayFn_V5(){ return mPplayerOnList_V5;} // object's 'reference' number/ position on list
		
		//Reset & initializer Fns:
		void mP_totalScoreInThisSession_initialiserFn_V5(int i){
			mP_totalScoreInThisSession_V5 = i;};
		
		void mP_currentRound_setterFn_V5(int i){ 
			mP_currentRound_V5 = mP_currentRound_V5 + i;}
		int mP_currentRound_displayFn_V5(){ return mP_currentRound_V5;}
		void mP_currentRound_initializerFn_V5(int i){
			mP_currentRound_V5 = i;}
		
		void mP_totalRoundsPlayed_initialiserFn_V5(int i){
			mP_totalRoundsPlayed_V5 = i;};
		
		void mP_sessionGoodAnswerCounter_V5_initializerFn(int i){
			mP_goodAnswersGivenInSessionCounter = i;}
		
		void mP_sessionGoodAnswerCounter_V5_setterFn(){	// invoke if good answer given...
			mP_goodAnswersGivenInSessionCounter = mP_goodAnswersGivenInSessionCounter + 1;}
		
		int mP_GoodAnswer_count_displayFn_V5(){return mP_goodAnswersGivenInSessionCounter;}
		
		void mP_goodAnswerStreek_initialiserFn_V5(int i){
			mP_goodAnswerStreek_V5 = i;}
		void mP_longestGoodAnswerStreak_initialiserFn_V5(int i){
			mP_longestGoodAnswerStreak_V5 = i;}
		void mP_lifes_V5_initialiserFn(int i){
			mP_lifes_V5 = i;}
		
		void mP_attemptCounter_singleSession_initializerFn_V5(int i){
			mP_attemptCounter_singleSession = i;}
		//setter
		void mP_attemptCounter_singleSession_setterFn_V5(int i){
			mP_attemptCounter_singleSession = mP_attemptCounter_singleSession + i;}
		
		void mP_lifesLost_inLastSession_initializerFn_V5(int i){
			mP_lifesLostCounter_forSession = i;}
		//setter 
		void mP_lifesLost_inLastSession_setterFn_V5(){
			mP_lifesLostCounter_forSession = mP_lifesLostCounter_forSession - 1;}
		//---------------------------------------------------------------------------------------
		int mP_previousHighScore_displayFn_V5(){ // setter in New high score Fn
			return mP_previousHighScore_inOneSession_V5;}
			
		void mP_newHighScoreInOneSession_setterFn_V5(int i){ // where i = sessions total
			if(i > mP_new_highestScore_inOneSession_V5){
				mP_previousHighScore_inOneSession_V5 = mP_new_highestScore_inOneSession_V5; // sets previous high
				mP_new_highestScore_inOneSession_V5 = i;}}
		int mP_newHighScoreInOneSession_displayFn_V5(){
			return mP_new_highestScore_inOneSession_V5;}
		
		//score
		void mP_totalScoreInThisSession_setterFn_V5(int i){
			mP_totalScoreInThisSession_V5 = mP_totalScoreInThisSession_V5 + i;};
		int mP_totalScoreInThisSession_displayFn_V5(){ return mP_totalScoreInThisSession_V5;}
		//G.A.S.
		void mP_goodAnswerStreek_setterFn_V5(){
			mP_goodAnswerStreek_V5 = mP_goodAnswerStreek_V5 + 1;
			if(mP_goodAnswerStreek_V5 > mP_longestGoodAnswerStreak_V5){
			mP_longestGoodAnswerStreak_V5 = mP_goodAnswerStreek_V5;}
			else {}
			}
		int mP_longestGoodAnswerStreak_displayFn_V5(){ return mP_longestGoodAnswerStreak_V5;}
		int mP_goodAnswerStreek_dispalyFn_V5(){ return mP_goodAnswerStreek_V5;}
		//rounds
		void mP_totalRoundsPlayed_setterFn_V5(int i){
			mP_totalRoundsPlayed_V5 = mP_totalRoundsPlayed_V5 + i;}
		int mP_totalRoundsPlayed_displayFn_V5(){ return mP_totalRoundsPlayed_V5;}
		//lifes
		void mP_lifes_setterFn_V5(int i){
			mP_lifes_V5 = mP_lifes_V5 + i;}
		int mP_lifes_displayFn_V5(){ return mP_lifes_V5;}
		
		void mP_skip_setterFn_V5(int i){
			mP_skip_V5 = mP_skip_V5 + i;}
		int mP_skip_displayFn_V5(){ return mP_skip_V5;}
		void mP_skip_initializerFn_V5(int i){
			mP_skip_V5 = i;}
		
		//secsPassed
		void mP_updeate_Total_secsPassed(int inSecsPassed){
			mP_Total_secsPassed_V5 = mP_Total_secsPassed_V5 + inSecsPassed;}
		
		double mP_total_thinkingTime_displayFn_V5(){return mP_Total_secsPassed_V5;}
		
		//string make AVG S/A (not in use...)
		void mP_calculate_avgSecPerAns_inStringFn_V5(){ // -> invoke before asign it to and save lB string value....
			//taylor to 2 dec first, then return.
			//Rounding to 2 decimals
						float raw_avgSecPerAns;
						raw_avgSecPerAns = mP_Total_secsPassed_V5 / mP_GoodAnswer_count_displayFn_V5();
						string string_avgSecPerAns;
						double rounded_avgSecPerAns;
						rounded_avgSecPerAns = roundf(raw_avgSecPerAns * 100)/100; // rounding to 2 dec
						if(static_cast<int>(rounded_avgSecPerAns) == rounded_avgSecPerAns){
							string_avgSecPerAns = to_string(static_cast<int>(rounded_avgSecPerAns));}
						else{ 
							string_avgSecPerAns = to_string(rounded_avgSecPerAns);
							//tayloring tailing zeros
							while(!string_avgSecPerAns.empty() && 
									isdigit(string_avgSecPerAns.back()) && string_avgSecPerAns.back()
									== '0') {string_avgSecPerAns.pop_back();}
							}
					//update mP var
					mP_Alltime_avgSecPerAns = string_avgSecPerAns;			
					}
		//---------------------------------------------------------			
		string mP_display_Alltime_avgSecPerAnsFn_V5(){
			return mP_Alltime_avgSecPerAns;
		}
		//Statistics display fn:
		void mP_statisticsDisplayFn_V5(){
			
			mP_calculate_avgSecPerAns_inStringFn_V5();
			
			cout<<BRIGHT<<"            *** THE WINNER'S STATISTICS ***\n"<<RSTA<<endl;
			cout<<BBLACK<<"Player's name:"<<RSTA<<" \t"<<BBLACK<<BRIGHT<<mPname_V5<<RSTA<<" | "<<BBLACK<<"Level played:"<<RSTA<<" "<<BBLACK<<BRIGHT;
			if(mP_Level_InClass_displayFn_V5() == 1){cout<<"EASY";}
			if(mP_Level_InClass_displayFn_V5() == 2){cout<<"\33[1;32mNORMAL\33[0m";}
			if(mP_Level_InClass_displayFn_V5() == 3){cout<<"\33[1;33mEXPERT\33[0m";}
			if(mP_Level_InClass_displayFn_V5() == 4){cout<<"\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m";}
			cout<<RSTA<<"\n"<<endl;
			
			cout<<RSTA<<"Total score made during the session: \t"<<BRIGHT<<mP_totalScoreInThisSession_V5<<RSTA<<"\n"
				<<BBLACK<<"Total time spent on giving answers:"<<RSTA<<" \t"<<BBLACK<<BRIGHT<<mP_total_thinkingTime_displayFn_V5()<<" sec"<<RSTA<<"\n"
				<<"Longest good answer streak you've had: \t"<<BRIGHT<<mP_longestGoodAnswerStreak_V5<<RSTA<<"\n"
				<<BBLACK<<"Average time to give a correct answer:"<<RSTA<<" \t"<<BBLACK<<BRIGHT<<mP_Alltime_avgSecPerAns<<" sec"<<RSTA<<"\n"
				<<"Attempt made: \t"<<BRIGHT<<mP_attemptCounter_singleSession<<RSTA<<" | Good answer given:  "<<BRIGHT<<mP_goodAnswersGivenInSessionCounter<<RSTA<<"\n"
				<<BBLACK<<"Lifes lost: \t"<<BRIGHT<<abs(mP_lifesLostCounter_forSession)<<RSTA<<"\n"
				<<"==============================================================\n"
				<<RSTA<<endl;
			
			}
		//--------------------------------------------------------------
		//Display statistic name and score  (align to digit...)
		void mP_displayName_andScoreFn_V5(){
			
			cout<<mP_name_displayFn_V5()<<" | ";
			if(mP_totalScoreInThisSession_displayFn_V5()>= 0 && mP_totalScoreInThisSession_displayFn_V5() <10){
				cout<<" "<<mP_totalScoreInThisSession_displayFn_V5();
			}
			
			else{cout<<mP_totalScoreInThisSession_displayFn_V5();}
			cout<<" scored \t| under ";
			if(mP_total_thinkingTime_displayFn_V5() >= 0 && mP_total_thinkingTime_displayFn_V5() <10)
				{cout<<" "<<mP_total_thinkingTime_displayFn_V5()<<" sec";}
			else{cout<<mP_total_thinkingTime_displayFn_V5()<<" sec";}	
				cout<<endl;
			}
		//===========================================================================
			
		void mP_Level_InClass_setterFn_V5(int played_level){
			mP_Level_Inclass = played_level;
		}
		int mP_Level_InClass_displayFn_V5(){return mP_Level_Inclass;}
	//------------------------------------------------------------------
	protected:	// S = need to save&load to file
		string mPname_V5;	// S
		int mPid;
		int mPplayerOnList_V5;
		int mP_totalScoreInThisSession_V5;
		int mP_goodAnswerStreek_V5;
		int mP_longestGoodAnswerStreak_V5;
		int mP_goodAnswersGivenInSessionCounter;
		int mP_totalRoundsPlayed_V5;
		int mP_lifes_V5;
		int mP_lifesLostCounter_forSession;
		int mP_attemptCounter_singleSession;
		int mP_previousHighScore_inOneSession_V5;
		int mP_new_highestScore_inOneSession_V5;
		int mP_currentRound_V5;
		int mP_skip_V5;
		double mP_Total_secsPassed_V5; // per game = total_ThinkingTime
		string mP_Alltime_avgSecPerAns; //per game
		int mP_Level_Inclass;
		
		//-----for the record/ leaderboard----------
		// it will have its own class, compair data from session, highest score goes to leader board.
		// until it has 15 input. then the next goes on if it is higher then any of on the list, then
		// sort it out into descending score order with new data on.
		// leaderboard saves 3 data: Name, Score, and Date. (to_string)... and level too
		
	};	
//----------------------------------------------------------------------
class LeaderBoardClass{
	
	public:
		LeaderBoardClass(){
			lB_name = "User Name Default";
			lB_score = 0;
			lB_date = "dd/mm/yyyy";	// this format will be provided with a function return... (toDayFn_V5())
			lB_secs_passed_toAnswer = 0; // taylor to 2 decimal when display it !!!
			lB_Level = 0; //normal = default 
			}
		//---------------------------------------------------------------
		// 2nd Loading Constructor
		LeaderBoardClass(string lbName, int lbScore, int total_time_toAnswer, int lb_diff, string lbDate) :
							lB_name(lbName),
							lB_score(lbScore),
							lB_secs_passed_toAnswer(total_time_toAnswer),
							lB_Level(lb_diff),
							lB_date(lbDate){ // initialize here if nedded
								}
		//---------------------------------------------------------------
		
		//random generated text Fn
		string rnd_genTextFn_V5(){
			
			static const string characters ="abcdeefghiijklmnoopqrstuuvwxyz"
											"ABCDEFGHIJKLMNOOPQRSTUUWVXZY"
											"112345667890";
		
				//randomizer
			std::mt19937 rnd_char(rand()); //mersenne twister algorithm
			
			
			//generate lengh between 4-10 chars
			//uniform_int_distribution<> length_dist(4,10);
		
			rnd_char();
	
			int length = rand()%10;
			if(length < 4){while(length < 4){length = rand()%10;}} // no length < 4 allowed
			string generated_text;
			generated_text.reserve(length);
			
			for(int i = 0; i < length; ++i){
				rnd_char();
				//rnd char index
				uniform_int_distribution<> char_dist((rand()%9)+1,characters.size()-1);
				generated_text += characters[char_dist(rnd_char)];
			}
			
			return generated_text;
		}
		//--------------------------------------------------
		
		//Serialization
		string lB_serializeFn_V5(){
				
				string space_ = " ";
				// "encription"
				string junk_1 = rnd_genTextFn_V5();
				string junk_2 = rnd_genTextFn_V5();
				string junk_3 = rnd_genTextFn_V5();
				string junk_4 = rnd_genTextFn_V5();
				string junk_5 = rnd_genTextFn_V5();
				string junk_6 = rnd_genTextFn_V5();
				string junk_7 = rnd_genTextFn_V5();
				string junk_8 = rnd_genTextFn_V5();
				string junk_9 = rnd_genTextFn_V5();
				string junk_10 = rnd_genTextFn_V5();
				string junk_11 = rnd_genTextFn_V5();
				string junk_12 = rnd_genTextFn_V5();
				
				return
					junk_1 + space_ +
					junk_2 + space_ +
					junk_3 + space_ +
					junk_4 + space_ +
					lB_name + space_ +
					junk_5 + space_ +
					junk_6 + space_ +
					to_string(lB_secs_passed_toAnswer) + space_+ 
					junk_7 + space_ +
					to_string(lB_Level) + space_+
					junk_8 + space_ + 
					junk_9 + space_ +
					to_string(lB_score) + space_+
					junk_10 + space_ +
					junk_11 + space_ +
					lB_date + space_ +
					junk_12;
			}
		//-----------------------------------------------------------------
		//operator overwrite:
		bool operator==(LeaderBoardClass& obj) {return lB_name == obj.lB_name && lB_date == obj.lB_date;}
		
		//-----------------------------------------------------------------
		//Display Leaderboard info
		
			
		//update and display Fns:
		//name
		void update_lB_nameFn_V5(string a){
			lB_name = a;}
		string display_lB_nameFn_V5(){return lB_name;}
		//score
		void update_lB_scoreFn_V5(int i){
			lB_score = i;}
		int display_lB_scoreFn_V5(){return lB_score;}
		//date
		void update_lB_dateFn_V5(string d){
			lB_date = d;}
		string display_lB_dateFn_V5(){return lB_date;}
		//secs
		void update_lB_secs_passed_toAnswerFn_V5(int secs){
			lB_secs_passed_toAnswer = secs;}
		int display_lB_secs_passed_toAnswerFn_V5(){return lB_secs_passed_toAnswer;}
		//average secs per ans takes the value from MAIN end of mPlayer gameloop...
		void update_lB_avg_secPerAnsFn_V5(string averageSecPerA){
			lB_avg_secPerAns_string = averageSecPerA;}
		string display_lB_avgSecPerAns_inStringFn_V5(){
			return lB_avg_secPerAns_string;}
		void update_lB_LevelFn_V5(int current_lev){
			lB_Level = current_lev;
		}
		int display_lB_LevelFn_V5(){return lB_Level;}
		
		
	protected:
		string lB_name;
		int lB_score;
		string lB_date;
		int lB_secs_passed_toAnswer; // to average sec/answer (AVG S/A) -> add to manual what it stands for
		int lB_Level;
		string lB_avg_secPerAns_string; // save value to leaderboard (taylor to 2 decimal)
};
//======================================================================
//						*** SAVE FILE THINGS ****
//======================================================================
//Save only last played timePoint singlePlayer/User
string sP_secondPartOfTimePoint_saveFileName = "_lastTimePlayed.txt";
void sp_timePointOnly_saveFn_V5(string saveFileName, SplayerClass obj){
	ofstream sP_t_o_SaveFile(obj.name_displayFn_V5() + sP_secondPartOfTimePoint_saveFileName);
	if(sP_t_o_SaveFile.is_open()){	
		sP_t_o_SaveFile<<obj.sP_timePointOnly_serialFn_V5();
	sP_t_o_SaveFile.close();
	//cout<<"Time point successfully saved!\n"<<endl;
	}
	else{cerr<<"\nERROR: Couldn't open the file for writing...\n"<<endl;}
	}
//----------------------------------------------------------------------
//Load time Fn
time_t loadSaved_Time_V5_Fn(SplayerClass obj){ // assigne this loaded value to object value to complate load
	string tp_sfn = obj.name_displayFn_V5() + sP_secondPartOfTimePoint_saveFileName;
	ifstream saveFile_name(tp_sfn);
	time_t Loaded_savedTime = 0; //initialize here
	
	if(saveFile_name.is_open()){
		saveFile_name>>Loaded_savedTime; // load back the saved data
		saveFile_name.close();
		}
	return Loaded_savedTime;
}
//------------------------------------------------------------------------------
ifstream* sP_LastTimePointFileOpenerFn_V5(SplayerClass& obj) //'ifstream used for input...
{
	ifstream* pFileStream = 0;
	for(;;)
	{
		//open the file specified by user:
		string fileName = obj.name_displayFn_V5() + sP_secondPartOfTimePoint_saveFileName;
		//cout<<"This will open/read file if it's there."<<endl;
			
		//open file for reading: (don't create the file)
		pFileStream = new ifstream(fileName);
		if (pFileStream->good())
			{
				//if we got a save file
				//cout<<"...timePoint save file found...\n"<<endl;//When save file found
				break;}
		else {cerr<<"\nCouldn't open: "<<fileName<<"\n"<<endl;
				//set x to 1
				// if we don't have a save file
				delete pFileStream; break;}
	}	
		return pFileStream;
}
//------------------------------------------------------------------------------------
//name the Save file
string saveFileName_SP_V5 = "saveFile_singlePlayerMode_V5.txt";
string saveFileName_LB_V5 = "saveFile_leaderBoard_V5.txt";
int sP_ifNo_saveFile_found_V5 = 0; // if found var = 1; 
//int mP_ifNo_saveFile_found_V5 = 0;
int lB_ifNo_saveFile_found_V5 = 0;
//declear Player vectors
vector <SplayerClass> sPlayersVector;
vector <MplayerClass> mPlayersVector; // *** NO id requied but need to check No PLAYER with same NAME!!! ***
vector <LeaderBoardClass> leaderList_V5;
//======================================================================
//Save Fn for sPlayer Class:
void sP_saveFNfor_sPlayerClass_V5(string& fileName, vector<SplayerClass>& sPlayers){ // this vector will be sPlayerVector when I invoke it
	ofstream sP_saveFile_V5(saveFileName_SP_V5);
	if(sP_saveFile_V5.is_open()){
		for(auto& obj : sPlayers){ 
			// starts from 1 so it doesnt save "Test user's data"
			//if(sPlayers[0].name_displayFn_V5() == "Guest Player"){ } // do nothing
			//Each person has a new line entry on the file sheet.
			sP_saveFile_V5<<obj.sP_serializeFn_V5()<< '\n';
			}
		sP_saveFile_V5.close();
		//cout<<"\nData saved successfully to "<<saveFileName_SP_V5<<"."<<endl;
			}
	else{cerr<<"\nERROR: Couldn't open the file for writing...\n"<<endl;}
	}
//----------------------------------------------------------------------
//Save Fn for LeaderBoard Class: - leaderboard data... needs refitting
void lB_saveFNfor_leaderBoardClass_V5(string& fileName, vector<LeaderBoardClass>& leaderList_V5){ // include "saveFile_LB_V5" & leaderList objectVector
	ofstream lB_saveFile_V5(saveFileName_LB_V5);
	if(lB_saveFile_V5.is_open()){
		for(auto& obj : leaderList_V5){
			//Each person has a new line entry on the file sheet.
			lB_saveFile_V5<<obj.lB_serializeFn_V5()<< '\n';}
		lB_saveFile_V5.close();
		//cout<<"\nData saved successfully to "<<saveFileName_LB_V5<<"."<<endl;
			}
	else{cerr<<"\nERROR: Couldn't open the file for writing...\n"<<endl;}
	}
//----------------------------------------------------------------------
ifstream* sP_openFileSingleP_V5() //'ifstream used for input...
{
	ifstream* pFileStream = 0;
	for(;;)
	{
		//open the file specified by user:
		string fileName = saveFileName_SP_V5;
		//cout<<"This will open/read file if it's there."<<endl;
			
		//open file for reading: (don't create the file)
		pFileStream = new ifstream(fileName);
		if (pFileStream->good())
			{
				//if we got a save file
				sP_ifNo_saveFile_found_V5 = 1;
				//cout<<"Person save file found...\n"<<endl;//When save file found
				break;}
		else {cerr<<"\nCouldn't open: "<<fileName<<"\n"<<endl;
				//set x to 1
				sP_ifNo_saveFile_found_V5 = 0; // if we don't have a save file
				delete pFileStream; break;}
	}
		return pFileStream;
}
//----------------------------------------------------------------------
//----------------------------------------------------------------------
ifstream* lB_openFileLeaderBoard_V5() //'ifstream used for input...
{
	ifstream* pFileStream = 0;
	for(;;)
	{
		//open the file specified by user:
		string fileName = saveFileName_LB_V5;
		//cout<<"This will open/read file if it's there."<<endl;
			
		//open file for reading: (don't create the file)
		pFileStream = new ifstream(fileName);
		if (pFileStream->good())
			{
				//if we got a save file
				lB_ifNo_saveFile_found_V5 = 1;
				//cout<<"Person save file found...\n"<<endl;//When save file found
				break;}
		else {cerr<<"Couldn't open: "<<fileName<<endl;
				//set x to 1
				lB_ifNo_saveFile_found_V5 = 0; // if we don't have a save file
				delete pFileStream; break;}
	}	
		return pFileStream;
}
//----------------------------------------------------------------------
//                           *** GLOBAL VARS ***

string issues_emilAddres = "xdobranszkia@hotmail.com";
//declear a color object
ColorThemes colorDefault; // (this is in ColorMenu Preview only)
ColorThemes cD; // for the rest of the program
int idBuff;
string nBuff;
int sP_userSelected = -1;
int i = 0;
int currentRounds_test = 0;
int roundScore_V5 = 10;
int yourRoundScore_test;
int attempts_test = 1;
int goodAnswerCounter = 0;
float floatCorrectAnswer;
float *pFloatCorrectAnswer;
int intCorrectAnswer;
int *pIntCorrectAnswer;
bool whileInGameLoop = true;
bool correct = false;
string yourAnswerString;
int gAnsInRowCounter = 0;
int life_updater_var = 3;
string currentCanswer_display;
//int selectUserByNumber = 0; //by default it's set to "Guest user" = sP_userSelected
bool loggedIn = false;
int range = 100; // default range
bool gameIsRunning_OuterShell = true; // OuterShell loop of the Program
int userCounter = 0; // Number of Players Registered on list
bool inSinglePlayerMenu = true; // once userPlayer selected
bool playerUserSelected = false; // while single player user selected
string playerUser; // a spaceholder for Players name
int chooseOfSinglePlayerMenuPoint;
int optionsMenupointSelected;
bool inOptionsMenu = true;
int selectMainMenuPoint;
//atomic<bool> input_recieved(false);
//int countDownSetter;
string yourGoodAnswer;
string correctAnswer;
string inputVar;
//thread timer(countDownFn,10);
int selectedColourTheme;
bool inColourMenu = true;
bool logginBool = false;
bool inGameLoopFn = true;
int rounds; //monitor rounds in GameLoopFn
int scoreWhilePlaying = 0;
int attempts = 0;
int currentLifes = 3;
bool inGame = true;
int roundScore = 10; // default score/round (if you hit correct answer 1st)
//Dificulty level switches (By default is Normal)
bool inDifficultyOptionMenu = true;
string showCurrentDiffLevel = "NORMAL"; //default level
char regOrSelectSplayer;
int checkId;
bool regOrSelectBool_loop = false;
int pin_try = 0; // throwes you out after 3 trys... (at loggin PIN)
bool while_sP_userSelected = false;
int skipp = 3; // by default
bool inWintercolorMenu = true;
string colorThemeDisplayInfo_current = "\33[;33mDefault theme\33[0m";
int sessionCounter_inMain = 0;
char termsConditions; //save this into player object (for whoever signs in 1st, but not the testUser!!!)
void not_played_moreThen_oneWeek_messageFn_V5(SplayerClass obj);
int delete_profileOrnot_int;
int change_name_or_pin_int;
bool in_deleteProfileMenu = true;
bool while_inDelete_profile_bool = true;
string nw_name_buff_V5;
//---------------------------- Multiplayer Global Vars ----------------------------------
bool inMultiPlayerModeShell_V5 = true;
bool mP_while_playingGame_V5 = true;
int pNum_test = 1;
string test_mp_name = "mP_Tester_";
string fullName_test = test_mp_name + to_string(pNum_test);
int count_users_on_mPlist_test = 0;
int mP_i = 0;
int count_mPplayers_with_lifes = 0;
int mPlayerMenuSelected;
int round_buffer;
string mP_nameBuffer;
bool adding_names_to_mPlayerList = true;
int leaderList_V5_count = 1;
bool mP_scoreUpdate_toSameName_done_V5 = false;
bool if_tie_bool = false;
bool in_mP_option_menu = false;
int set_mPlayer_colorTheme = 0;
int mP_Level = 2;
bool mp_auto_turn = false;
bool mp_auto_round = false;
bool mp_unlimitedLoopExit = false;
bool mP_sameName_switch = false;
//=======================================================================================
//							*** FUNCTION DECLARATIONS ***

void colorThemeLoadFn(SplayerClass obj);
void termsAndConDisplayFn_V5();
void manual_displayFn_V5();
void gameLoopFn_V5(SplayerClass obj);
void statistic_outsideFn(SplayerClass obb);
SplayerClass userSelectorFn_V5(int i);
void seedrnd(void);
int rnd1(int range);
int rnd2(int range);
char selectRndOperationFn();
string correctAnswerInStringFn(int n1, int n2, char op);
void exitLoop();
void current_TandC_displayFn_V5();
void unlocked_achivementsFn_V5(SplayerClass obj);
//--------------------Mplayer fns---------------------------------------
MplayerClass mP_userSelectorFn_V5(int i);
void test_mP_gameLoop(MplayerClass& obj);
string toDayFn_v2_V5(); // this version is not updating after compiling the program
string cDate_returnFn_V5(); // this verson updates at each time it's invoked...
void multiplayer_GameLoopFn_V5(MplayerClass obj);
void mP_victoryMessage_displayFn_V5(MplayerClass& obj);
void mP_noneMadeIt_Message_displayFn_V5();
bool return_trueIf_thereSameNameEntryOnLeaderBoardFn_v5(MplayerClass obj);
void update_leaderboard_all_in_one(string name, string date, int t_t_answ, int diff_lev, int score);
void mPlayerColor_previewFn();
string auto_turn_stateFn_V5();
string auto_round_stateFn_V5();
//-----------------------------------------------------------------------------------------
// Sorting things
bool sortByABC_name_sPlayerListFn_V5(SplayerClass a, SplayerClass b);
bool sortByDescendingScore_MplayerClassObjectsFn_V5(MplayerClass a, MplayerClass b);
//sort by score and time (if same score put first the one with less time
bool sortByHighestScore_andQuickestTime_ifScoreIs_same_MplayerFn_V5(MplayerClass a, MplayerClass b);
bool sortByDescendingScore_LeaderBoardListFn_V5(LeaderBoardClass a, LeaderBoardClass b);
void updateLeaderboard_ifItsFull_oneByoneFn_V5(MplayerClass obj); //invoke if player score > the smallest on leaderboard

//======================================================================================
//======================================================================================

//								*** int MAIN () ***
int main(){
	
	
	cout<<endl;
		for(int i=0; i < 3;i++){
			cout<<".";
			fflush(stdin);
			fflush(stdout);
			sleep(1);}
		
	cout<<"\n\n"<<endl;
	cout<<"                       _  _     ___   ____   \n"
		<<"                      //\\/\\\\   //_\\\\   ||  ||__||\n"
		<<"                     //    \\\\ //   \\\\  ||  ||  ||\n"
		<<"\n"
		<<"            ___          ___            ____         ___  ____\n"
		<<"           //   ||__||  //_\\\\  ||  ||  ||_   ||\\ || // _ ||_\n"
		<<"           \\\\__ ||  || //   \\\\ ||_ ||_ ||__  || \\|| \\\\// ||__\n"
		<<"\n"
		<<ITALIC<<"                        by Andras Dobranszki \u00A9\n"<<RSTA
		<<endl;
		cout<<"\n\n"<<endl;
		cout<<"          "<<DIM<<"\33[3mTERMINAL SOFTWARE (Published version 1.1)"<<endl;
		sleep(3);
	
		system("clear");
		
	
	
// *** ADD LOAD FN HERE ***
// once you logged in it will save your choosen colorScheme under your name, so next time it will load in like that already...
	
//======================================================================	
//================= L O A D  Single Player D A T A =====================
	
	//get a file stream:
	ifstream* pFileStream = sP_openFileSingleP_V5();
	
	//if no save file yet...
	if (sP_ifNo_saveFile_found_V5 == 0){
		
		//make the Guest user: ( Occupies Zero on the vector list )
		//NOTE: Guest Player is not playable at the moment as a "free play"
		//Implement -> Guest Players data will be saved too (while u play), but re-initialized to ZERO at each program start.
		string nameGuest = "Guest Player";
		int idGuest = 12221;
		sPlayersVector.push_back(SplayerClass(nameGuest, idGuest));
		
		cout<<"\n*** No Save file not found ***\n"
			<<"    CREATING SAVE FILE...\n"
			<<RSTA<<endl;
		//for test stop here
		cout<<"Press \33[1mENTER\33[0m to continue...\n"<<endl;
		cin.get();
	}	
	
	//else -> save file found and load players data...	
	else{cout<<DIM<<"\33[3mSave file found. Loading";
		for(int i=0; i < 3; i++){
			cout<<".";
			fflush(stdout);
			sleep(1);}
			cout<<RSTA<<"\n\n"<<endl;
		
		while(sP_ifNo_saveFile_found_V5 == 1) //if there is a SAVE file already:
			{
	
				ifstream sP_loadFile_V5(saveFileName_SP_V5);
				
				if(sP_loadFile_V5.is_open()){
					
					string line; // Pull data here before storing itno objects
					
					//Read DATA line by line: (object by object)
					while(getline(sP_loadFile_V5,line)){
						
						istringstream load(line);
						//declear buffers (again)
						string nameJunk;  //1
						string j_name_2; //string sPname_b;  //2
						int junkNum_1_b;  //3
						string junk_too;//int sPid_b; //4
						int junkNum_2_b;  //5
						int sP_lifes_V5_b;  //6
						int junkNum_7_b;  //7
						int alltimeScore_V5_b;  //8
						int junkNum_8_b;  //9
						int alltimeRounds_V5_b;  //10
						int junkNum_9_b;  //11
						int anyGoodAnswerGiven_Alltimes_V5_b;  //12
						int junkNum_11_b;  //13
						int attempts_counterForStatistic_allTime_V5_b;  //14
						int junkNum_13_b;  //15
						int lostLifes_counter_Alltimes_V5_b;  //16
						int junkNum_15_b;  //17
						int new_highestScore_inOneSession_V5_b;  //18
						int junkNum_16_b;  //19
						int previousHighScore_inOneSession_V5_b;  //20
						int junkNum_17_b;  //21
						string j_2;
						string j_6;
						string sPname_b;  //22
						string j_4;
						int longest_goodAnswerStreakEver_V5_b;  //23
						int junkNum_18_b;  //24
						int allTime_previousLongestStreak_V5_b;  //25
						int junkNum_19_b;  //26
						int sP_milestonesUnlocked_counter_V5_b;  //27
						int junkNum_20_b;  //28
						int longestPlayEver_V5_b;  //29
						int junkNum_21_b;  //30
						int previousLongestPlay_V5_b;  //31
						int junkNum_22_b;  //32
						int sP_sessionCounter_inClass_b;  //33
						int junkNum_23_b;  //34
						int sP_chosen_colorScheme_V5_b;  //35
						int sP_chosen_level_V5_b;  //36
						//bool sP_inClass_expertSwitch_V5_b;
						//bool sP_inClass_easySwitch_V5_b;
						double sP_totalSecsPassed_toGiveAnsver_V5_b;  //37
						double sP_allTime_session_play_time_V5_b;  //38
						double sP_shortest_time_goodAnswerGiven_lastSession_V5_b;  //39
						double sP_longest_time_goodAnswerGiven_lastSession_V5_b;  //40
						double sp_shortest_time_goodAnswerGiven_allTime_V5_b;  //41
						double sp_longest_time_goodAnswerGiven_allTime_V5_b;  //42
						int junkNum_6_b;  //43
						string j_8;
						int sPid_b;  //44
						int sP_allTime_easy_score_V5_b;  //45
						int sP_allTime_normal_score_V5_b;  //46
						int sP_allTime_expert_score_V5_b;  //47
						int sP_allTime_master_score_V5_b;  //48
						int sP_allTime_rounds_easy_V5_b;  //49
						int sP_allTime_rounds_normal_V5_b;  //50
						int sP_allTime_rounds_expert_V5_b;  //51
						int sP_allTime_rounds_master_V5_b;  //52
						bool sP_masterlevel_unlocked_b;  //53
						bool sp_milestone_1_V5_b;  //54
						bool sp_milestone_2_V5_b;  //55
						bool sp_milestone_3_V5_b;  //56
						bool sp_milestone_4_V5_b;  //57
						bool sp_milestone_5_V5_b;  //58
						bool sp_milestone_6_V5_b;  //59
						bool sp_milestone_7_V5_b;  //60
						bool sp_milestone_8_V5_b;  //61
						bool sp_milestone_9_V5_b;  //62
						bool sp_milestone_10_V5_b;  //63
						bool sp_milestone_11_V5_b;  //64
						bool sp_milestone_12_V5_b;  //65
						bool sp_milestone_13_V5_b;  //66
						bool sp_milestone_14_V5_b;  //67
						bool sp_milestone_15_V5_b;  //68
						bool sp_milestone_16_V5_b;  //69
						bool sp_milestone_17_V5_b;  //70
						bool sp_milestone_17andHalf_V5_b;  //71
						bool sp_milestone_18_V5_b; //72
						bool milestone_5sec_easy_V5_b;
						bool milestone_3sec_easy_V5_b;
						bool milestone_1sec_easy_V5_b;
						bool milestone_5sec_normal_V5_b;
						bool milestone_3sec_normal_V5_b;
						bool milestone_1sec_normal_V5_b;
						bool milestone_5sec_expert_V5_b;
						bool milestone_3sec_expert_V5_b;
						bool milestone_1sec_expert_V5_b;
						bool milestone_5sec_master_V5_b;
						bool milestone_3sec_master_V5_b;
						bool milestone_1sec_master_V5_b;
						double old_timeTo_saveAnd_load_V5_b;
						//Extract DATA from line -> assemble object:
						
						load>>nameJunk  //1
							>>j_name_2 //string sPname_b;  //2
							>>junkNum_1_b  //3
							>>junk_too//int sPid_b; //4
							>>junkNum_2_b  //5
							>>sP_lifes_V5_b  //6
							>>junkNum_7_b  //7
							>>alltimeScore_V5_b  //8
							>>junkNum_8_b  //9
							>>alltimeRounds_V5_b  //10
							>>junkNum_9_b  //11
							>>anyGoodAnswerGiven_Alltimes_V5_b  //12
							>>junkNum_11_b  //13
							>>attempts_counterForStatistic_allTime_V5_b  //14
							>>junkNum_13_b  //15
							>>lostLifes_counter_Alltimes_V5_b  //16
							>>junkNum_15_b  //17
							>>new_highestScore_inOneSession_V5_b  //18
							>>junkNum_16_b  //19
							>>previousHighScore_inOneSession_V5_b  //20
							>>junkNum_17_b  //21
							>>j_2
							>>j_6
							>>sPname_b  //22
							>>j_4
							>>longest_goodAnswerStreakEver_V5_b  //23
							>>junkNum_18_b  //24
							>>allTime_previousLongestStreak_V5_b  //25
							>>junkNum_19_b  //26
							>>sP_milestonesUnlocked_counter_V5_b  //27
							>>junkNum_20_b  //28
							>>longestPlayEver_V5_b  //29
							>>junkNum_21_b  //30
							>>previousLongestPlay_V5_b  //31
							>>junkNum_22_b  //32
							>>sP_sessionCounter_inClass_b  //33
							>>junkNum_23_b  //34
							>>sP_chosen_colorScheme_V5_b  //35
							>>sP_chosen_level_V5_b  //36
						//bool sP_inClass_expertSwitch_V5_b;
						//bool sP_inClass_easySwitch_V5_b;
							>>sP_totalSecsPassed_toGiveAnsver_V5_b  //37
							>>sP_allTime_session_play_time_V5_b  //38
							>>sP_shortest_time_goodAnswerGiven_lastSession_V5_b  //39
							>>sP_longest_time_goodAnswerGiven_lastSession_V5_b  //40
							>>sp_shortest_time_goodAnswerGiven_allTime_V5_b  //41
							>>sp_longest_time_goodAnswerGiven_allTime_V5_b  //42
							>>junkNum_6_b  //43
							>>j_8
							>>sPid_b  //44
							>>sP_allTime_easy_score_V5_b//49 v
							>>sP_allTime_normal_score_V5_b//50 v
							>>sP_allTime_expert_score_V5_b//51 v
							>>sP_allTime_master_score_V5_b//52 v
							>>sP_allTime_rounds_easy_V5_b//53 v
							>>sP_allTime_rounds_normal_V5_b//54 v
							>>sP_allTime_rounds_expert_V5_b//55 v
							>>sP_allTime_rounds_master_V5_b//56 v
							>>sP_masterlevel_unlocked_b//57 v
							>>sp_milestone_1_V5_b//58 v
							>>sp_milestone_2_V5_b//69 v
							>>sp_milestone_3_V5_b//60 v
							>>sp_milestone_4_V5_b//61 v
							>>sp_milestone_5_V5_b//62 v
							>>sp_milestone_6_V5_b//63 v
							>>sp_milestone_7_V5_b//64 v
							>>sp_milestone_8_V5_b//65 v
							>>sp_milestone_9_V5_b//66 v
							>>sp_milestone_10_V5_b//67 v
							>>sp_milestone_11_V5_b//68 v
							>>sp_milestone_12_V5_b//79 v
							>>sp_milestone_13_V5_b//70 v
							>>sp_milestone_14_V5_b//71 v
							>>sp_milestone_15_V5_b//72 v
							>>sp_milestone_16_V5_b//73 v
							>>sp_milestone_17_V5_b//74 v
							>>sp_milestone_17andHalf_V5_b//75 v
							>>sp_milestone_18_V5_b//76 v
							>>milestone_5sec_easy_V5_b
							>>milestone_3sec_easy_V5_b
							>>milestone_1sec_easy_V5_b
							>>milestone_5sec_normal_V5_b
							>>milestone_3sec_normal_V5_b
							>>milestone_1sec_normal_V5_b
							>>milestone_5sec_expert_V5_b
							>>milestone_3sec_expert_V5_b
							>>milestone_1sec_expert_V5_b
							>>milestone_5sec_master_V5_b
							>>milestone_3sec_master_V5_b
							>>milestone_1sec_master_V5_b
							>>old_timeTo_saveAnd_load_V5_b;
							
						//Re-Create the player (Object): Constructor patern replacement -> need a second constructor for this !!!
						sPlayersVector.emplace_back(
							
							sPname_b,
							sPid_b,
							sP_lifes_V5_b,
							alltimeScore_V5_b,
							alltimeRounds_V5_b,
							anyGoodAnswerGiven_Alltimes_V5_b,
							attempts_counterForStatistic_allTime_V5_b,
							lostLifes_counter_Alltimes_V5_b,
							new_highestScore_inOneSession_V5_b,
							previousHighScore_inOneSession_V5_b,
							//sPname_b,
							longest_goodAnswerStreakEver_V5_b,
							allTime_previousLongestStreak_V5_b,
							sP_milestonesUnlocked_counter_V5_b,
							longestPlayEver_V5_b,
							previousLongestPlay_V5_b,
							sP_sessionCounter_inClass_b,
							sP_chosen_colorScheme_V5_b,
							sP_chosen_level_V5_b,
							//sP_inClass_expertSwitch_V5_b,
							//sP_inClass_easySwitch_V5_b,
							sP_totalSecsPassed_toGiveAnsver_V5_b,
							sP_allTime_session_play_time_V5_b,
							sP_shortest_time_goodAnswerGiven_lastSession_V5_b,
							sP_longest_time_goodAnswerGiven_lastSession_V5_b,
							sp_shortest_time_goodAnswerGiven_allTime_V5_b,
							sp_longest_time_goodAnswerGiven_allTime_V5_b,
							//sPid_b,
							sP_allTime_easy_score_V5_b,
							sP_allTime_normal_score_V5_b,
							sP_allTime_expert_score_V5_b,
							sP_allTime_master_score_V5_b,
							sP_allTime_rounds_easy_V5_b,
							sP_allTime_rounds_normal_V5_b,
							sP_allTime_rounds_expert_V5_b,
							sP_allTime_rounds_master_V5_b,
							sP_masterlevel_unlocked_b,
							sp_milestone_1_V5_b,
							sp_milestone_2_V5_b,
							sp_milestone_3_V5_b,
							sp_milestone_4_V5_b,
							sp_milestone_5_V5_b,
							sp_milestone_6_V5_b,
							sp_milestone_7_V5_b,
							sp_milestone_8_V5_b,
							sp_milestone_9_V5_b,
							sp_milestone_10_V5_b,
							sp_milestone_11_V5_b,
							sp_milestone_12_V5_b,
							sp_milestone_13_V5_b,
							sp_milestone_14_V5_b,
							sp_milestone_15_V5_b,
							sp_milestone_16_V5_b,
							sp_milestone_17_V5_b,
							sp_milestone_17andHalf_V5_b,
							sp_milestone_18_V5_b,
							milestone_5sec_easy_V5_b,
							milestone_3sec_easy_V5_b,
							milestone_1sec_easy_V5_b,
							milestone_5sec_normal_V5_b,
							milestone_3sec_normal_V5_b,
							milestone_1sec_normal_V5_b,
							milestone_5sec_expert_V5_b,
							milestone_3sec_expert_V5_b,
							milestone_1sec_expert_V5_b,
							milestone_5sec_master_V5_b,
							milestone_3sec_master_V5_b,
							milestone_1sec_master_V5_b,
							old_timeTo_saveAnd_load_V5_b
							);
							//sP_secsPassedPerGa_singleSessionData_b
							//);
						}
						
						sP_loadFile_V5.close();
						break;
					}
				
	
				else if(pFileStream->fail())
					{cout<<"Ooh, What happened?!\n"<<endl;
					cerr<<"Error: Couldn't open the file..."<<endl;
					 break;}
		
		} // while loop end
	} // else statement END

//================== End Loading Single Player Data ====================
//======================================================================

//Loading Multiplayer LeaderBoard Data:

//get a file stream:
	ifstream* pLeaderBoard_FileStream = lB_openFileLeaderBoard_V5();
	
	//if no save file yet...
	if (lB_ifNo_saveFile_found_V5 == 0){
		
		
		
		//make 20 fake entryes: ( Occupies Zero on the vector list )
		//NOTE: Guest Player is not playable at the moment as a "free play"
		//Implement -> Guest Players data will be saved too (while u play), but re-initialized to ZERO at each program start.
		string name_lB = "EMPTY";
		int score_lb = 0;
		int fake_time_to_a = 0;
		int fake_level = 0;
		string fakeDate = "dd-mm-yyyy";
		for(int i = 0; i < 20; i++){
			leaderList_V5.push_back(LeaderBoardClass(name_lB, score_lb, fake_time_to_a, fake_level, fakeDate));
			leaderList_V5_count++; // this must be 20 after this loop all the time (1st time run)
			}
		
		
		cout<<DIM<<"\n\33[3m*** No Leader Data Saveed ***\n"
				 <<"  CREATING LEADER BOARD...\n"
			<<RSTA<<endl;
		//for test stop here
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		}
	
	while(lB_ifNo_saveFile_found_V5 == 1) //if there is a SAVE file already:
			{
	
				ifstream lB_loadFile_V5(saveFileName_LB_V5);
				
				if(lB_loadFile_V5.is_open()){
					
					string line; // Pull data here before storing itno objects
					
					//Read DATA line by line: (object by object)
					while(getline(lB_loadFile_V5,line)){
						
						istringstream load(line);
						//declear buffers (again)
						string junk_1;
						string junk_2;
						string junk_3;
						string junk_4;
						string junk_5;
						string junk_6;
						string junk_7;
						string junk_8;
						string junk_9;
						string junk_10;
						string junk_11;
						string junk_12;
						string nameJunk;
						string lBname_b;
						int lBscore_b;
						int lB_secs_passed_toAnswer_b;
						int lB_Level_b;
						string lBdate_b;
						//load from white space to whitespace per string, therefore space no need extructing
						load>>junk_1
							>>junk_2
							>>junk_3
							>>junk_4
							>>lBname_b
							>>junk_5
							>>junk_6
							>>lB_secs_passed_toAnswer_b
							>>junk_7
							>>lB_Level_b
							>>junk_8
							>>junk_9
							>>lBscore_b
							>>junk_10
							>>junk_11
							>>lBdate_b;
						//Refill/Create leaderBoard list
						leaderList_V5.emplace_back(
							lBname_b,
							lBscore_b,
							lB_secs_passed_toAnswer_b,
							lB_Level_b,
							lBdate_b
							);
						}	
						//Close load file
						lB_loadFile_V5.close();
						break;	
					}
					//if poo poo
					else if(pLeaderBoard_FileStream->fail())
					{cout<<"Ooh, What happened?!\n"<<endl;
					cerr<<"Error: Couldn't open the file..."<<endl;
					 break;}
					 
				}//End while loading Leaderboard data loop
					
//================= END OF LOADING MULTIPLAYER DATA ======================		
//========================================================================	
// *** Both display Fn works as long as you asign obj to PlayerObject before quiting gameLoop! ***
	
	
	//Switch board Menu structure:
while(gameIsRunning_OuterShell){
	
	//==================================================================
	//Select menu:
	//		MAIN MENU:
	//		- Single player mode
	//			-Login
	//				-(Once logged in) Play the Game! (ask for timer before you play)
	//				- Statistics
	//				- Number Matrix -15x-
	// 				- Options
	// 					- Color options
	// 					- Difficulty
	//					- Change Name/Pin
	// 					- Delete your profile
	//				- Back (Save before exit)
	//				
	//			-Back
	//		- Multiplayer mode
	//			- Play the Game! (set how many rounds you wanna play), ask for timer Yes/No, play
	//				- Choose how many players play, choose players, play the game, exit end of game
	//			- Leader Board (1st 10 best score) 
	//			-Back ( Score counts towards personal statistics so SAVE before exit)
	
	//		(- Options menu ==> N/A
	//				- Timer option
	//					- 10s, 20s, 30s
	//				- Sound On/OFF )
	
	//		- Number Matrix -15x- (back to "this" MAIN menu when you finished)
	//		- Manual
	//		- Exit Program
	//==================================================================
	
	//test
	//milestone_reaching_50RoundsInSessionFn(50);
	//cout<<"Enter...";
	//cin.get();
	//------------------------------------------------------------------
	
	//========================================================================
	//Add a GAME LOGO LATER HERE a nice GRAPHIC OR BANNER put in a display Fn.
	//=========================================================================
	
	cD.default_colorsFn();
	
	
	fflush(stdin); // clear input stream buffer
	fflush(stdout); // clear output buffer
		string c = "\u00A9";
		//NOTE:
		// The '\xa9' character is the copyright symbol (or u00A9 or u8)
		system("clear");
		
		
		cout<<endl;
		cout<<"                     "<<BRIGHT<<ULINE<<"WELLCOME to MATH CHALLENGE!"<<RSTA<<"\n"<<RSTA
			<<"\n"
			<<"                 "<<BRIGHT<<c<<RSTA<<ITALIC<<" Andras Dobranszki "<<RSTA
			<<BRIGHT<<c<<RSTA<<" 2024 - 2026 "<<BRIGHT<<c<<RSTA<<"\n"<<RSTA
			<<endl;
	
		cout<<"\n" // 10 spaces on front
			<<"         "<<cD.keret_color<<"---------"<<RSTA<<" "<<cD.menu_color1<<"M A T H   C H A L L E N G E"<<RSTA" "<<cD.keret_color<<"----------"<<RSTA<<"\n"
			<<"         "<<cD.keret_color<<"|"<<RSTA<<"                                              "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"         "<<cD.keret_color<<"|"<<RSTA<<"                "<<cD.menu_color1<<"*"<<RSTA<<" "<<cD.menu_color2<<"MAIN MENU"<<RSTA<<" "<<cD.menu_color1<<"*"<<RSTA<<"                 "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"         "<<cD.keret_color<<"|"<<RSTA<<"                                              "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"         "<<cD.keret_color<<"|"<<RSTA<<"            "<<cD.menu_color1<<"To choose a menu point"<<RSTA<<"            "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"         "<<cD.keret_color<<"|"<<RSTA<<"         "<<cD.menu_color1<<"enter the number front of it."<<RSTA<<"        "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"         "<<cD.keret_color<<"|"<<RSTA<<"                                              "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"         "<<cD.keret_color<<"------------------------------------------------"<<RSTA<<"\n"
			<<"\n"
			<<"            "<<cD.keret_color<<"("<<cD.menu_color2<<"1"<<RSTA<<cD.keret_color<<")"<<RSTA<<" - "<<cD.menu_color1<<"Single Player"<<RSTA<<" \n"
			<<"            "<<cD.keret_color<<"("<<cD.menu_color2<<"2"<<RSTA<<cD.keret_color<<")"<<RSTA<<" - "<<cD.menu_color1<<"Multiplayer"<<RSTA<<" \n"
			<<"            "<<cD.keret_color<<"("<<cD.menu_color2<<"3"<<RSTA<<cD.keret_color<<")"<<RSTA<<" - "<<cD.menu_color1<<"Number Matrix 15x15"<<RSTA<<"\n"
			<<"            "<<cD.keret_color<<"("<<cD.menu_color2<<"4"<<RSTA<<cD.keret_color<<")"<<RSTA<<" - "<<cD.menu_color1<<"Manual"<<RSTA<<"\n"
			<<"            "<<cD.keret_color<<"("<<cD.menu_color2<<"0"<<RSTA<<cD.keret_color<<")"<<RSTA<<" - "<<cD.menu_color1<<"EXIT Program"<<RSTA<<"\n"
			<<endl;
		//Select user loop:
		
		while(!(cin>>selectMainMenuPoint))
		{
		
			if(!selectMainMenuPoint)//if not valid Menu Option entered:
			
				{//I need to play a sound if Incorrect! (no message)
				//also delete the wrong answer from screen or
				//tell that is not the correct answer.
        cout<<endl<<cD.keret_color<<"\a	     **********************************"<<RSTA"\n"
			<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
            <<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
            <<RSTA;
            
            fflush(stdin);
        
		cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout<<"			     ";
        continue;
			}
		
			if(selectMainMenuPoint < 0 || selectMainMenuPoint > 5) 
			{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
				 <<endl; continue;}
			else break; 
		}
		
	system("clear");
	//--------------GAME MODE SELECT SWITCH BOARD-----------------------
	
	switch (selectMainMenuPoint)
	
	{
		case 4: // Project manual (How and what)
			
			//function load/reads the content from external txt.... (as it is) and prints to screen
			// line by line.... (not much of frormating text at this point such way...)
			manual_displayFn_V5();
			cin.get();
			cout<<"Press \33[1mENTER\33[0m to go back to main menu:";
			cin.get();
			system("clear");
			break;
		
		case 0: //EXIT Program (from Main Menu)
				
				system("clear");
				exitLoop();
				cout<<"\n"<<endl; // 20 spaces on front
				cout<<"                    "<<cD.keret_color<<"*************************************"<<RSTA<<"\n"
					<<"                    "<<cD.keret_color<<"*"<<RSTA<<"   "<<cD.menu_color1<<"Remember, practice makes it!"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
					<<"                    "<<cD.keret_color<<"*"<<RSTA<<"  "<<cD.menu_color2<<"(If you don't use it, lose it.)"<<RSTA<<"  "<<cD.keret_color<<"*"<<RSTA<<"\n"
					<<"                    "<<cD.keret_color<<"*"<<RSTA<<"   "<<cD.menu_color1<<"But if you have to go, go..."<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
					<<"                    "<<cD.keret_color<<"*"<<RSTA<<"       "<<cD.menu_color1<<"I hope you had fun!"<<RSTA<<"         "<<cD.keret_color<<"*"<<RSTA<<"\n"
					<<"                    "<<cD.keret_color<<"*"<<RSTA<<"         "<<cD.menu_color1<<"C u next time!"<<RSTA<<"            "<<cD.keret_color<<"*"<<RSTA<<"\n"
					<<"                    "<<cD.keret_color<<"*"<<RSTA<<"             "<<cD.back_color<<"Bye  :)"<<RSTA<<"               "<<cD.keret_color<<"*"<<RSTA<<"\n"
					<<"                    "<<cD.keret_color<<"*************************************"<<cD.keret_color<<""<<RSTA<<"\n"
					<<"                      \u00A9 "<<"2024 - 2026"<<" "<<"Andras Dobranszki"
					<<endl;
					
				//Build in Here save functions too...
				//Save the data to file:
				sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector); // include savefile and the Object-vector
				gameIsRunning_OuterShell = false;
				break;
	//--------------------------------------------------------------
		case 1: //Single Player
		
			//reset vars to this menu to default:
			regOrSelectBool_loop = false;
			sP_userSelected = -1;
		
		while(!regOrSelectBool_loop){	
			system("clear");
			
			//Save
			sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector);
			
			
			// LoginFN:
			// Login, and userselector:
	// Display Players on list 10/10 press enter to continue list... (same name alowed as you need 
	// to match id too, to identify the right object.
	cout<<endl;
	cout<<RSTA"          "<<cD.keret_color<<"***"<<RSTA<<" "<<cD.menu_color2<<"S I N G L E  P L A Y E R  M O D E"<<RSTA<<" "<<cD.keret_color<<"***"<<RSTA<<"\n"<<endl;
	//LIst
	//-------------------------------------------------------------------
	cout<<cD.menu_color1<<"Registered players:"<<RSTA"\n"<<endl;
	// Show Player list (without the Guest Users)
	if(sPpersonOnList == 1){cout<<"PLAYER LIST: E M P T Y\n"<<endl;}	
	for(int count = 1; count< sPpersonOnList; count++){
		cout<<"("<<count<<") - "<<cD.menu_color2<<sPlayersVector[count].name_displayFn_V5()<<RSTA<<endl;
		fflush(stdout);
		i++;
		if(i == 10){ 
			cout<<"Wao! This list is long...   :)\n"
				<<"Press \33[1mENTER\33[0m to continue...\n"<<endl;
			i = 1;}}
	i = 1; //reset trigger after display
	//------------------------------------------------------------------		
	cout<<endl;
	cout<<cD.menu_color1<<"To select Player:"<<RSTA<<" Enter ("<<cD.yellow_color<<"S\33[0m)     "<<cD.menu_color1<<"To register New Player:"<<RSTA<<" Enter ("<<cD.youranswer_color<<"R"<<RSTA<<")\n"<<endl;
	cout<<"                            ";
	while(!(cin>>regOrSelectSplayer)){ // char
		if(!regOrSelectSplayer){
			cout<<"\n"<<endl;
			cout<<RSTA<<"Hooops, try to enter ("<<cD.yellow_color<<"mS\33[0m) OR (\33[1;32mR\33[0m) ... ";
			fflush(stdin);
			cin.clear();
			continue;
			}
		if(regOrSelectSplayer != 's' &&regOrSelectSplayer != 'S' && 
			regOrSelectSplayer != 'r' && regOrSelectSplayer != 'R'){
			cout<<"\n"<<endl;
			cout<<cD.itsnotanumber_color<<"INVALID option..."<<RSTA<<" "<<cD.tryagain_color<<"try to enter ("<<cD.yellow_color<<"mS\33[0m) OR (\33[1;32mR\33[0m) ... ";
			fflush(stdin);
			cin.clear();
			}
		else break;}
	//------------------------------------------------------------------
	// Select from list or Register:
	
	
	// SELECT PLAYER FROM LIST
	if(regOrSelectSplayer == 's'){
		
		
		
		if(sPpersonOnList == 1) {cout<<"\n                The list is E M P T Y ...\n"
									 <<"                No Player registered yet...\n"
									 <<"                \33[1mPlease register first!\33[0m\n"<<endl;
				sleep(3);
				continue;}
			cout<<"\n"
				<<"Please select a Player (by its number) from the list above!\n"
				<<"Don't see \"your name\"? Enter (\33[1m0\33[0m) to go \33[1mback\33[0m & REGISTER.\n"<<endl;
			while_sP_userSelected = false;
		    while(!while_sP_userSelected){	
				
			while(!(cin>>sP_userSelected) || sP_userSelected == -1)
		{
		
			if(!sP_userSelected)//if not valid Menu Option entered:
			
				{
					cout<<endl<<cD.keret_color<<"\a	     **********************************"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
						
						fflush(stdin);
					
					cin.clear();
					cin.ignore(numeric_limits<streamsize>::max(), '\n');
					cout<<"			     ";
					continue;
					}
		
				}
			//----------------- Now we got a number in sP_userSelected -
			// not in range
			if(sP_userSelected < 0 || sP_userSelected > ( sPpersonOnList -1 )) // cause you have Guest User as default user
			{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
				 <<endl;
				 sleep(1);
				 sP_userSelected = -1;
				  continue;}
			//back	  
			if(sP_userSelected == 0){while_sP_userSelected = true;
										cout<<"\n33[1mBACK33[0m"<<endl;
										while_sP_userSelected = true;
										sP_userSelected = -1;
										break;}
			// if Player secected
			else {
				while_sP_userSelected = true;
				
				regOrSelectBool_loop = true;}
			}
		}
	//------------------------------------------------------------------
	// REGISTER NEW PLAYER TO THE LIST
	if(regOrSelectSplayer == 'r'){
		system("clear");
		cout<<endl;
		
		//add here T&C writing as a displayFn
		cout<<"          ****************************************************\n"
		<<"          *      Hello and wellcome at Math challenge!       *\n"
		<<"          *     Please read the terms & conditions first,    *\n"
		<<"          * and if you fine with them press '\33[1mA\33[0m' to Accept.   *\n"
		<<"          *         \33[3mIf not... press '\33[1mD\33[0m' to Decline.          *\n"
		<<"          *     ----------------------------------------     *\n"
		<<"          *      Press \33[1mEnter\33[0m to load \33[;33mTerms & Conditons\33[0m!      *\n"
		<<"          ****************************************************"
		<<endl;
	cin.get();
	cin.get();
	system("clear");
		//Terms & Conditions
		cout<<"\n                       *** \33[3mTERMS & CONDITIONS\33[0m ***\n"<<endl;
		
		current_TandC_displayFn_V5();
		 
		cout<<"                   (\33[1mA\33[0m)ccept          (\33[1mD\33[0m)ecline\n"<<endl;
		cout<<"                               ";
		
		while(!(cin>>termsConditions)){
			
			if(termsConditions == 'd' || termsConditions =='D'){
				cout<<"It's okay...\n I can live with that, you know. Thanks  !_!\n"<<endl;
					return 0;}
			
			if(termsConditions == 'a' || termsConditions =='A'){
				
				termsConsBool = true; //proceed
				break;
			}
			else{cout<<"Sorry? Please try again!\n"
					<<"A or a to accept\n"
					<<"D or d to decline\n\n"
					<<"It is your choice!    ";
					}
		}
		//------------------------------------------------------------------------------------------
		
		system("clear");
				cout<<"\n"
			<<"     ***************************************************************\n"
			<<"     *                 "<<BRIGHT<<"Sharing is an ACT of LOVE!"<<RSTA<<"                  *\n"
			<<"     *                   \33[5m* T H A N K  Y O U ! *\33[0m                    *\n"
			<<"     *           "<<BRIGHT<<"... and have fun playing the \"GAME\"  \33[3;33m:)\33[0m"<<RSTA<<"           *\n"
			<<"     ***************************************************************\n"
			<<endl;
			sleep(3);
		
		
		
		//for test stop here
		//cout<<"\nPress \33[1mENTER\33[0m to continue..."<<endl;
		//cin.get();
		
	//--------------------------------------------------------------
	system("clear");
	//Register:
		cout<<"\n              \33[1;m*** R E G I S T E R   N E W   U S E R ***\33[0m\n"<<endl;
		cout<<"\33[1;38mPlease enter your User name :\33[0m \n"
			<<"(Max 15 character long name, use underscore \"_\" instead of space.)\n"
			<<BRIGHT<<"  -->  ";
		cin>>nBuff;
		cout<<RSTA;
		while(nBuff.size() > 15){
			cout<<endl
				<<cD.itsnotanumber_color<<"The choosen name is too long! Please use max 15 characters!"<<RSTA<<"\n"
				<<BRIGHT<<"Enter your User name now: "<<FGREENBOLD;
				cin>>nBuff;
		}
		//------------------------------------------------------------------------------------------
		cout<<RSTA<<endl;
		cout<<"Hi "<<BRIGHT<<nBuff<<RSTA<<"! \n"
			<<"Now, let's enter your (\33[1monly number, max 4 digit\33[0m) special PIN code\n"
			<<BRIGHT<<"(\33[3mYou'll need this in the future in order to able to log in.\33[0m): ";
		while(!(cin>>idBuff))
		{
		
			if(!idBuff)//if not valid Menu Option entered:
			
				{
					cout<<endl<<cD.keret_color<<"\a	     **********************************"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
            
            fflush(stdin);
        
		cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout<<"			     ";
        continue;
			}
		
			if(size_t(idBuff) < 1 || size_t(idBuff) > 4) 
			{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
				 <<endl; continue;}
			else break; 
		}
		
	//if all good -> add player to list:
	sPlayersVector.push_back(SplayerClass(nBuff, idBuff));
	//Let's save this:
	//Save the data to file:
	sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector); // include savefile and the Object-vector
	//------------------------------------------------------------------
	cout<<endl;
	cout<<"Good! That's all done for you, "<<BRIGHT<<nBuff<<RSTA<<"!\n\n"
		<<ITALIC<<"Please press \33[1mENTER\33[0m to go back to Player selection! "<<RSTA;
	cin.get();
	cin.get();
	//continue; //goes back to select user from list
		}
	}//Reg or select loop END
//----------------------------------------------------------------------
	
	// Player Selected, let's ask for ID/PIN
	cout<<"\n"<<endl;
	userSelectorFn_V5(sP_userSelected);
	
	//test
	//cout<<"Selected user's ID: "<<sPlayersVector[sP_userSelected].idNum_displayFn_V5()<<endl;
	
	loggedIn = false;
	while(!loggedIn){
	//cout<<"Greatings "<<sPlayersVector[sP_userSelected].name_displayFn_V5()<<endl;
	cout<<"Let me ask you for your (max 4 digit, only number) "<<cD.menu_color1<<"PIN."<<RSTA<<"\n"
		<<"Please enter your "<<cD.menu_color1<<"PIN"<<RSTA<<" now: ";
	// Check for proper Id entry
	while(!(cin>>checkId) || checkId == -1)
		{
		
			if(!checkId)//if not valid Menu Option entered:
			
				{//I need to play a sound if Incorrect! (no message)
				//also delete the wrong answer from screen or
						//tell that is not the correct answer.
					cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
					
					fflush(stdin);
				
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');
				cout<<"			     ";
				continue;
					}
		
			if(size_t(checkId) < 1 || size_t(checkId) > 4) 
				{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
					 <<endl;
				 continue;}
			
			else break;
		}
				 
		
		// Check for match:
		if(checkId == sPlayersVector[sP_userSelected].idNum_displayFn_V5()){
			//You'll logged in
			cout<<"Thanks, "<<sPlayersVector[sP_userSelected].name_displayFn_V5()
				<<" you good to go!"<<endl;
				playerUserSelected = true;
				 loggedIn = true;
				 checkId = -1; // reset to make sure it goes into asking for it next time too.
				 break;}
		else{cout<<cD.itsnotanumber_color<<"Sorry, that does NOT match with my records..."<<RSTA<<"\n"
				<<cD.tryagain_color<<"Please try again...!"<<RSTA<<endl;
				pin_try = pin_try+1;
				checkId = -1;
				//cin>>checkId;
				if(pin_try>=3){cout<<cD.menu_color2<<"Well, you really need to think about that number, don't you!"<<RSTA<<"\n"
							<<" :) ... "<<cD.menu_color2<<"Come back once you remember!"<<RSTA<<"\n"<<endl;
							return 0;}
					
				//break;
				continue;
				}
	}
	
	//----------------------------------------------------------------------------------------------
	//==============================================================================================
	//----------------------------------Loggin is done----------------------------------------------
			
			system("clear");
			system("clear");
			
			while(playerUserSelected){
				system("clear");
				//("Personal" menu) //reset loggin details oncee you leave this menu!!!
				
				//set/reset key variables for the Logged in user:
			allMilestonesProgress_inDotH = userSelectorFn_V5(sP_userSelected).sP_milestonesUnlocked_counter_displayFn_V5();
			userSelectorFn_V5(sP_userSelected).sP_attemptCounter_allTime_initizlizerFn_V5(); // load data once you have save!
			userSelectorFn_V5(sP_userSelected).sP_allTimeScore_initailazerFn_V5(0); // load once you have saved. (how?)
			userSelectorFn_V5(sP_userSelected).totalRoundsPlayed_initialiserFn_V5(0);
			userSelectorFn_V5(sP_userSelected).totalScoreInThisSession_initialiserFn_V5(0);
			userSelectorFn_V5(sP_userSelected).goodAnswerStreek_initialiserFn_V5(0);
			userSelectorFn_V5(sP_userSelected).longestGoodAnswerStreak_initialiserFn_V5(0); // or load from save file!!!
			
			skipp = 3;
			whileInGameLoop = true;
			//---------------------------------------- COLOR SCHEME SET ----------------------------------------------------------------
			//load back data to colorSheme var:
			
			colorThemeLoadFn(userSelectorFn_V5(sP_userSelected));
			
			//Save the data to file:
			sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector); // include savefile and the Object-vector
			system("clear");
			
			//------------------------------------- COLOR SET --------------------------------------	
			//--------------------------------------------------------------------------------------	
			
			//Level load
			
			//easy
			if(sPlayersVector[sP_userSelected].sP_chosen_level_displayFn_V5() == 1){
				//switch to your level
				easySwitch = true;
				expertSwitch = false;
				//display level
				difficulty_message = "\33[1;37mEasy\33[0m";}
			
			//normal
			if(userSelectorFn_V5(sP_userSelected).sP_chosen_level_displayFn_V5() == 2){
				easySwitch = false;
				expertSwitch = false;
				difficulty_message = "\33[1;32mNormal\33[0m";
			}
			
			//expert	
			if(userSelectorFn_V5(sP_userSelected).sP_chosen_level_displayFn_V5() == 3){
				expertSwitch = true;
				easySwitch = false;
				//display level
				difficulty_message = "\33[1;33mExpert\33[0m";}
			
			//master
			if(userSelectorFn_V5(sP_userSelected).sP_chosen_level_displayFn_V5() == 4){
				easySwitch = true;
				expertSwitch = true;
				difficulty_message = "\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m";
			}
			
			//========================= DIFFICULTY LEVEL SORTED ====================================
			
			//load last time logged in timepoint
			//---------------------------------------------------------------------------------------
			time_t currentTime_var_V5 = time(0);
			double minutesPassed_V5 = (difftime(currentTime_var_V5, sPlayersVector[sP_userSelected].old_timeTo_saveAnd_load_V5)) / 60;
			double hoursPassed_V5 = minutesPassed_V5 / 60;
			double daysPassed_V5 = hoursPassed_V5 / 24;
			
			// if u haven't played for more then a week...
			if(daysPassed_V5 > 7)
				{
					//display message
					not_played_moreThen_oneWeek_messageFn_V5(sPlayersVector[sP_userSelected]);
					//save new timepoint to user:
					sPlayersVector[sP_userSelected].old_timeTo_saveAnd_load_V5 = time(0);
					//Save the data to file:
					sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector);
					
					//string tP_saveFileName = sPlayersVector[sP_userSelected].name_displayFn_V5() + sP_secondPartOfTimePoint_saveFileName;
					//sp_timePointOnly_saveFn_V5(tP_saveFileName, userSelectorFn_V5(sP_userSelected));
				
					}
				
				cout<<"\n"<<endl;
				cout<<"     "<<cD.menu_color1<<"HELLO"<<RSTA<<" "<<cD.menu_color2<<userSelectorFn_V5(sP_userSelected).name_displayFn_V5()<<RSTA<<"\n"<<endl;
				cout<<"    "<<cD.keret_color<<"************************************************************"<<RSTA<<"\n"
					<<"    "<<cD.keret_color<<"*"<<RSTA<<"                   ("<<cD.menu_color2<<"1"<<RSTA<<") - "<<cD.menu_color2<<"PLAY"<<RSTA<<"                             "<<cD.keret_color<<"*"<<RSTA<<"\n"
					<<"    "<<cD.keret_color<<"*"<<RSTA<<"                   ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color2<<"STATISTICS"<<RSTA<<"                       "<<cD.keret_color<<"*"<<RSTA<<"\n"
					<<"    "<<cD.keret_color<<"*"<<RSTA<<"                   ("<<cD.menu_color2<<"3"<<RSTA<<") - "<<cD.menu_color2<<"MILESTONES STATUS"<<RSTA<<"                "<<cD.keret_color<<"*"<<RSTA<<"\n"
					<<"    "<<cD.keret_color<<"*"<<RSTA<<"                   ("<<cD.menu_color2<<"4"<<RSTA<<") - "<<cD.menu_color2<<"NUMBER MATRIX 15x15"<<RSTA<<"              "<<cD.keret_color<<"*"<<RSTA<<"\n"
					<<"    "<<cD.keret_color<<"*"<<RSTA<<"                   ("<<cD.menu_color2<<"5"<<RSTA<<") - "<<cD.menu_color2<<"OPTIONS"<<RSTA<<"                          "<<cD.keret_color<<"*"<<RSTA<<"\n" 
					<<"    "<<cD.keret_color<<"*"<<RSTA<<"                   ("<<cD.back_color<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                             "<<cD.keret_color<<"*"<<RSTA<<"\n"
					<<"    "<<cD.keret_color<<"************************************************************"<<RSTA<<"\n"
					<<"\n"
					<<endl;
	
		//Select user loop:
		cout<<"     Enter the selected menu point: ";
		while(!(cin>>chooseOfSinglePlayerMenuPoint))
		{
		
			if(!chooseOfSinglePlayerMenuPoint)//if not valid Menu Option entered:
			
				{//I need to play a sound if Incorrect! (no message)
				//also delete the wrong answer from screen or
				//tell that is not the correct answer.
        cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
            
            fflush(stdin);
        
		cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout<<"			     ";
        continue;
			}
		
			if(chooseOfSinglePlayerMenuPoint < 0 || chooseOfSinglePlayerMenuPoint > 5) 
				{
				//shortcut to final achivement text: 5110
				if(chooseOfSinglePlayerMenuPoint == 5110){break;}
				else{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
				 <<endl; continue;}
				} 
			else {break;} 
		}
		//--------------------------------------------------------------
		//Single Player User's Switch board (Once Logged in):
	system("clear");
	switch (chooseOfSinglePlayerMenuPoint)
	{
		case 0: //Back
			playerUserSelected = false;
			colorSchemeNumberIn_main = 0;
			cD.default_colorsFn();
			system("clear");
				//Might need to reset, update, save some data here befor we go back...
				break;
		//--------------------------------------------------------------
		case 5110:
			
			cin.get();
			system("clear");
					//load final achivement
					final_achivement_textShortcutFn();
					system("clear");
			break;
		//-------------------------------------------------------------
		case 3: //meliestones status
			
			unlocked_achivementsFn_V5(sPlayersVector[sP_userSelected]);
			
			break;
		//--------------------------------------------------------------
		case 1: // PLAY loop
		
			
			
			//set/reset key variables for the Logged in user:
			userSelectorFn_V5(sP_userSelected).totalRoundsPlayed_initialiserFn_V5(0);
			userSelectorFn_V5(sP_userSelected).totalScoreInThisSession_initialiserFn_V5(0);
			userSelectorFn_V5(sP_userSelected).goodAnswerStreek_initialiserFn_V5(0);
			userSelectorFn_V5(sP_userSelected).sP_allTimeScore_initailazerFn_V5(0); // load once you have saved. (how?)
			rounds = 0;
			// add 1 more each time you start a new game/ session/ play
			userSelectorFn_V5(sP_userSelected).sP_sessionCounter_setterFn_V5( +1); 
			
			//----------------------------------------------------------------------------------
			
			//time at started session:
			time_t start_session_timer;
			start_session_timer = time(0);
			
			//----------------------------------GAME LOOP------------------------------------------
			// Invoke Game loop Fn:
			gameLoopFn_V5(userSelectorFn_V5(sP_userSelected));
			//-------------------------------------------------------------------------------------
			
			//time at finished session:
			time_t end_session_time;
			end_session_time = time(0);
			
			//calculate passed time and save to player:
			double secs_session_lasted;
			secs_session_lasted = difftime(end_session_time, start_session_timer); // bigger - smaller
			
			//save value to player single session data
			sPlayersVector[sP_userSelected].sP_last_session_play_timeFn_V5(secs_session_lasted); 
			//add value to allTime record and save to player
			sPlayersVector[sP_userSelected].sP_allTime_session_play_timeFn_V5();
			//update statistics
			sPlayersVector[sP_userSelected].sP_update_statistic_varsFn_V5();
			
			//Save the data to file:
			sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector); // include savefile and the Object-vector
		
			break;
		//--------------------
		case 2: // Statistics
		
			system("clear");
			// *** use "selectUserByNumber" as reference user in display info and to save... ***
			
			//display info:
			userSelectorFn_V5(sP_userSelected).sP_statisticsDisplayFn_V5();
			
			cout<<endl;
			cout<<cD.menu_color1<<"Press \33[1mENTER\33[0m"<<cD.menu_color1<<" to go "<<cD.back_color<<"back..."<<RSTA;
			fflush(stdin);
			cin.get();
			system("clear");
			break;
			
		//--------------------------------------------------------------
		case 4: // Number matrix 15x15
		
			multiplicationTable15x15Fn();
			
			cout<<"Press \33[1mENTER\33[0m once you finished here..."
				<<endl;
			fflush(stdout);
			fflush(stdin);
			cin.get();
			cin.get();
			system("clear");
		
			break;
		//--------------------------------------------------------------
		case 5: // OPTIONS MENU
		
		inOptionsMenu = true;
			
			while(inOptionsMenu){

				system("clear");

				//Reset menupoint bools:
				inColourMenu = true;
				
			cout<<"\n"<<RSTA<<endl;
			cout<<"             "<<cD.keret_color<<"******** OPTIONS  MENU ********"<<RSTA<<"\n"
				<<"             "<<cD.keret_color<<"*"<<RSTA<<"  ("<<cD.menu_color2<<"1"<<RSTA<<") - "<<cD.menu_color2<<"Colour themes"<<RSTA<<"        "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"             "<<cD.keret_color<<"*"<<RSTA<<"  ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color2<<"Difficulty levels"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"             "<<cD.keret_color<<"*"<<RSTA<<"  ("<<cD.menu_color2<<"3"<<RSTA<<") - "<<cD.menu_color2<<"Change your name"<<RSTA<<"     "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"             "<<cD.keret_color<<"*"<<RSTA<<"  ("<<cD.menu_color2<<"4"<<RSTA<<") - "<<cD.menu_color2<<"Change your PIN"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"             "<<cD.keret_color<<"*"<<RSTA<<"  ("<<cD.menu_color2<<"5"<<RSTA<<") - "<<cD.menu_color2<<"\33[1;31mDelete\33[0m"<<cD.menu_color2<<" your profile"<<RSTA<<"  "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"             "<<cD.keret_color<<"*"<<RSTA<<"  ("<<cD.back_color<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                 "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"             "<<cD.keret_color<<"*******************************"<<RSTA<<"\n"
				<<endl;
			
			cout<<"     "<<cD.menu_color1<<"Enter the selected menu point:"<<RSTA<<" ";
		while(!(cin>>optionsMenupointSelected))
		{
		
			if(!optionsMenupointSelected)//if not valid Menu Option entered:
			
				{//I need to play a sound if Incorrect! (no message)
				//also delete the wrong answer from screen or
				//tell that is not the correct answer.
        cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
            
            fflush(stdin);
        
		cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout<<"			     ";
        continue;
			}
		
			if(optionsMenupointSelected < 0 || optionsMenupointSelected > 4) 
			{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
				 <<endl; continue;}
			else {break;} 
		}
		//--------------------------------------------------------------
		// Activate optionMenupointSelected Switchboard:
		
		switch (optionsMenupointSelected){
			
			case 0:
				
				inOptionsMenu = false;
			system("clear");
				//Might need to reset, update, save some data here befor we go back...
				break;
				
			//----------------------------------------------------------
			//----------------------------------------------------------
			
			case 1: // Colour Thames
				while(inColourMenu){
				system("clear");
				// Name colour Thames and invoke changing fn(ColourThemeName) by changing the existing
				// "Namecodes"  of colours to the choosen ones...
				//defOrange = "\033[;31;40m";
				cout<<""<<endl;
				cout<<"              ============================\n"
					<<"              |   (1) - "<<FYELLOW<<"Default theme"<<RSTA<<"    |\n"
					<<"              |   (2) - "<<"\033[1;32m"<<"Spring theme"<<RSTA<<"     |\n"
					<<"              |   (3) - "<<"\033[1;31m"<<"Summer theme"<<RSTA<<"     |\n"
					<<"              |   (4) - "<<"\033[1;33m"<<"Autumn theme"<<RSTA<<"     |\n"
					<<"              |   (5) - "<<BRIGHT<<"Winter theme"<<RSTA<<"     |\n"
					<<"              |   (0) - "<<FWHITE_BDARK<<"BACK"<<RSTA<<"             |\n"
					<<"              ============================\n";
					
					if(sPlayersVector[sP_userSelected].sP_choosen_colorScheme_displayFn_V5() == 1){
					colorThemeDisplayInfo_current = "\33[1;32mSPRING theme\33[0m";
					cout<<"             ( Current theme: "<<colorThemeDisplayInfo_current<<" )\n"
					<<endl;
					}
					if(sPlayersVector[sP_userSelected].sP_choosen_colorScheme_displayFn_V5() == 2){
					colorThemeDisplayInfo_current = "\33[1;31mSUMMER theme\33[0m";
					cout<<"             ( Current theme: "<<colorThemeDisplayInfo_current<<" )\n"
					<<endl;
					}
					if(sPlayersVector[sP_userSelected].sP_choosen_colorScheme_displayFn_V5() == 3){
					colorThemeDisplayInfo_current = "\033[1;33mAUTUMN theme\33[0m";
					cout<<"             ( Current theme: "<<colorThemeDisplayInfo_current<<" )\n"
					<<endl;
					}
					if(sPlayersVector[sP_userSelected].sP_choosen_colorScheme_displayFn_V5() == 4){
					colorThemeDisplayInfo_current = "\33[1mWINTER theme\33[0m";
					cout<<"             ( Current theme: "<<colorThemeDisplayInfo_current<<" )\n"
					<<endl;
					}
					else{colorThemeDisplayInfo_current = "\33[33mDEFAULT theme\33[0m";}
					
					
					cout<<"Please select a colour theme of your liking!\n"
					<<endl;
					while(!(cin>>selectedColourTheme))
		{
		
			if(!selectedColourTheme)//if not valid Menu Option entered:
			
				{//I need to play a sound if Incorrect! (no message)
				//also delete the wrong answer from screen or
				//tell that is not the correct answer.
        cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
            
            fflush(stdin);
        
		cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout<<"			     ";
        continue;
			}
		
			if(selectedColourTheme < 0 || selectedColourTheme > 5) 
			{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
				 <<endl; continue;}
			else {break;} 
		}
		//--------------------------------------------------------------
		//Switchboard your choice:
		switch (selectedColourTheme){
			
			case 0: //BACK
				
				 inColourMenu = false;
			system("clear");
				//Might need to reset, update, save some data here befor we go back...
				break;
				//-----------------------------------------------
			case 1: // DEFAULT
				if(selectedColourTheme == 1){
					
					system("clear");
					
					inWintercolorMenu = true;
					
					while(inWintercolorMenu){
					cout<<"\n"<<endl;	
					cout<<RSTA<<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color1<<"Enter"<<RSTA<<" ("<<cD.menu_color1<<"1"<<RSTA<<") - "<<cD.menu_color1<<"to Preview colour theme"<<RSTA<<" "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color2<<"Enter"<<RSTA<<" ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color2<<"to Apply colour theme"<<RSTA<<"   "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.back_color<<"Enter"<<RSTA<<" ("<<cD.back_color<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                    "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<endl;
					
					int colorMenuChoice;
					while(!(cin>>colorMenuChoice)){
				
					if(!colorMenuChoice)//if not valid Menu Option entered:
						{
						//also delete the wrong answer from screen or
						//tell that is not the correct answer.
						cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
					
						fflush(stdin);
						
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
						cout<<"			     ";
						continue;
							}
				
					if(colorMenuChoice < 0 || colorMenuChoice > 2) 
					{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
						 <<endl; continue;}
						 
					else {break;}
				}
			//-------------------------------------------------------------------------------
					
					if(colorMenuChoice == 0) {
						//back
						system("clear");
						inWintercolorMenu = false;
						break;}
						
					if(colorMenuChoice == 1){
						//preview color theme
						system("clear");
						colorDefault.default_colorsFn();
							cout<<"Default:"<<endl;
							
							cout<<"          "<<colorDefault.menu_color1<<"- PREVIEW DISPLAY -\n"
								<<colorDefault.keret_color<<"***************************************************"<<RSTA<<"\n"
								<<colorDefault.keret_color<<"*"<<RSTA<<colorDefault.menu_color1<<" Player's"<<RSTA<<" "<<colorDefault.menu_color2<<"Name"
								<<RSTA<<"       "<<colorDefault.menu_color1<<"Session's Total Score:"<<RSTA<<" "<<colorDefault.menu_color2
								<<"2344 "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<"                                               \n"
								<<"           "<<colorDefault.equattionText_color<<"Equation:"<<RSTA<<" "
								<<colorDefault.equation_color1<<"33"<<RSTA<<" "<<colorDefault.operation_color<<"/"<<RSTA<<" "
								<<colorDefault.equation_color2
								<<"7"<<RSTA<<" "<<colorDefault.operation_color<<"="<<RSTA"          "<<colorDefault.keret_color<<"*\n"
								<<"*"<<RSTA<<"                                                 \n"
								<<colorDefault.keret_color<<"***************************************************"<<RSTA"\n"
								<<"\n"
								<<"      "<<colorDefault.menu_color1<<"Your answer:"<<RSTA<<" "<<colorDefault.youranswer_color<<"4.71"<<RSTA"\n"
								<<"\n"
								<<RSTA"           "<<colorDefault.yes_color<<"YES"<<RSTA<<" "<<colorDefault.smily_color<<":)"<<RSTA<<"\n"
								<<"\n"
								<<"              "<<colorDefault.next_color<<"NEXT"<<colorDefault.keret_color
								<<"("<<colorDefault.next_color<<"n"
								<<colorDefault.keret_color<<")"<<RSTA
								<<"  or  "<<colorDefault.stop_color<<"STOP"<<colorDefault.keret_color
								<<"("<<colorDefault.stop_color<<"s"
								<<colorDefault.keret_color<<")"<<RSTA"\n"
								<<"                   "<<colorDefault.equation_color1<<"-->"<<RSTA
								//if your answer 'n' color same as next. if 's' color is same as stop...
								<<colorDefault.menu_color1<<" n"<<RSTA<<"\n"
								<<"\n"
								<<colorDefault.keret_color<<"*"<<RSTA<<"    "<<colorDefault.itsnotanumber_color<<"This is not a number"<<RSTA<<"             "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<"              "<<colorDefault.tryagain_color<<"Please, try again!"<<RSTA<<"      "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<colorDefault.keret_color<<"****************************************************"<<RSTA<<"\n"
								<<endl;
							//Set colourThemeFn()
							//Ask user Do you want to set this colour theme?
							cout<<"Press \33[1mENTER\33[0m if you've done here..."<<endl;
							cin.get();
							cin.get();
							system("clear");
							colorDefault.default_colorsFn();
					}	// end preview if
					
				if(colorMenuChoice == 2){
					// Apply your choice
					system("clear");
					
					colorDefault.default_colorsFn();
					cD.default_colorsFn();
					colorThemeDisplayInfo_current = "\33[33mDEFAULT theme\33[0m";
					colorSchemeNumberIn_main = 0;
					//set value in class var - to save and load
					sPlayersVector[sP_userSelected].sP_chosen_colorScheme_initializerFn_V5(0);
					//userSelectorFn_V5(sP_userSelected).chosen_colorScheme_V5 = colorSchemeNumberIn_main;
					//Save the data to file:
					sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector); // include savefile and the Object-vector
					cout<<"\n\n\n\n\n\n\n\n\n\n\n"<<endl;
					cout<<setw(25)<<BRIGHT<<"That's all done for you "
						<<sPlayersVector[sP_userSelected].name_displayFn_V5()<<RSTA<<endl;
					//TestLine:
					//cout<<"colorcode: "<<sPlayersVector[sP_userSelected].sP_choosen_colorScheme_displayFn_V5();
					inWintercolorMenu = false;
					sleep(2);
					}
				}
			}
				break;
				//-------------------------------------------------------
			case 2: // SPRING
				if(selectedColourTheme == 2){
					
					
					system("clear");
					
					inWintercolorMenu = true;
					
					while(inWintercolorMenu){
					cout<<"\n"<<endl;	
					cout<<RSTA<<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color1<<"Enter"<<RSTA<<" ("<<cD.menu_color1<<"1"<<RSTA<<") - "<<cD.menu_color1<<"to Preview colour theme"<<RSTA<<" "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color2<<"Enter"<<RSTA<<" ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color2<<"to Apply colour theme"<<RSTA<<"   "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.back_color<<"Enter"<<RSTA<<" ("<<cD.back_color<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                    "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<endl;
							  
					
					
					int colorMenuChoice;
					while(!(cin>>colorMenuChoice)){
				
					if(!colorMenuChoice)//if not valid Menu Option entered:
						{
						//also delete the wrong answer from screen or
						//tell that is not the correct answer.
						cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
					
						fflush(stdin);
						
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
						cout<<"			     ";
						continue;
							}
				
					if(colorMenuChoice < 0 || colorMenuChoice > 2) 
					{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
						 <<endl; continue;}
						 
					else {break;}
				}
			//-------------------------------------------------------------------------------
					
					if(colorMenuChoice == 0) {
						//back
						system("clear");
						inWintercolorMenu = false;
						break;}
						
					if(colorMenuChoice == 1){
						//preview color theme
						system("clear");
						colorDefault.spring_colorsFn();
							cout<<"Spring:"<<endl;
							
							cout<<"          "<<colorDefault.menu_color1<<"- PREVIEW DISPLAY -\n"
								<<colorDefault.keret_color<<"***************************************************"<<RSTA<<"\n"
								<<colorDefault.keret_color<<"*"<<RSTA<<colorDefault.menu_color1<<" Player's"<<RSTA<<" "<<colorDefault.menu_color2<<"Name"
								<<RSTA<<"       "<<colorDefault.menu_color1<<"Session's Total Score:"<<RSTA<<" "<<colorDefault.menu_color2
								<<"2344 "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<"                                               \n"
								<<"           "<<colorDefault.equattionText_color<<"Equation:"<<RSTA<<" "
								<<colorDefault.equation_color1<<"33"<<RSTA<<" "<<colorDefault.operation_color<<"/"<<RSTA<<" "
								<<colorDefault.equation_color2
								<<"7"<<RSTA<<" "<<colorDefault.operation_color<<"="<<RSTA"          "<<colorDefault.keret_color<<"*\n"
								<<"*"<<RSTA<<"                                                 \n"
								<<colorDefault.keret_color<<"***************************************************"<<RSTA"\n"
								<<"\n"
								<<"      "<<colorDefault.menu_color1<<"Your answer:"<<RSTA<<" "<<colorDefault.youranswer_color<<"4.71"<<RSTA"\n"
								<<"\n"
								<<RSTA"           "<<colorDefault.yes_color<<"YES"<<RSTA<<" "<<colorDefault.smily_color<<":)"<<RSTA<<"\n"
								<<"\n"
								<<"              "<<colorDefault.next_color<<"NEXT"<<colorDefault.keret_color
								<<"("<<colorDefault.next_color<<"n"
								<<colorDefault.keret_color<<")"<<RSTA
								<<"  or  "<<colorDefault.stop_color<<"STOP"<<colorDefault.keret_color
								<<"("<<colorDefault.stop_color<<"s"
								<<colorDefault.keret_color<<")"<<RSTA"\n"
								<<"                   "<<colorDefault.equation_color1<<"-->"<<RSTA
								//if your answer 'n' color same as next. if 's' color is same as stop...
								<<colorDefault.menu_color1<<" n"<<RSTA<<"\n"
								<<"\n"
								<<colorDefault.keret_color<<"*"<<RSTA<<"    "<<colorDefault.itsnotanumber_color<<"This is not a number"<<RSTA<<"             "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<"              "<<colorDefault.tryagain_color<<"Please, try again!"<<RSTA<<"      "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<colorDefault.keret_color<<"****************************************************"<<RSTA<<"\n"
								<<endl;
							//Set colourThemeFn()
							//Ask user Do you want to set this colour theme?
							cout<<"Press \33[1mENTER\33[0m if you've done here..."<<endl;
							cin.get();
							cin.get();
							system("clear");
							colorDefault.default_colorsFn();
					}	// end preview if
					
				if(colorMenuChoice == 2){
					// Apply your choice
					system("clear");
					
					//set value in class var - to save and load
					sPlayersVector[sP_userSelected].sP_chosen_colorScheme_initializerFn_V5(1);
					
					if(sPlayersVector[sP_userSelected].sP_choosen_colorScheme_displayFn_V5() == 1){
						
						cD.spring_colorsFn();
					colorThemeDisplayInfo_current = "\33[1;32mSPRING theme\33[0m";
					//colorSchemeNumberIn_main = 1;
					
					//cout<<userSelectorFn_V5(sP_userSelected).sP_choosen_colorScheme_displayFn_V5();
					//userSelectorFn_V5(sP_userSelected).chosen_colorScheme_V5 = colorSchemeNumberIn_main;
					//Save the data to file:
					sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector); // include savefile and the Object-vector
					cout<<"\n\n\n\n\n\n\n\n\n\n\n"<<endl;
					cout<<setw(25)<<BRIGHT<<"That's all done for you "
						<<sPlayersVector[sP_userSelected].name_displayFn_V5()<<RSTA<<endl;
					//TestLine:
					//cout<<"colorcode: "<<userSelectorFn_V5(sP_userSelected).sP_choosen_colorScheme_displayFn_V5();
					}
					
					//colorDefault.spring_colorsFn();
					
					inWintercolorMenu = false;
					sleep(2);
					}
				}
			}
				break;
				//------------------------------------------------------
				case 3: // SUMMER
				if(selectedColourTheme == 3){
					
				system("clear");
					
					inWintercolorMenu = true;
					
					while(inWintercolorMenu){
					cout<<"\n"<<endl;	
					cout<<RSTA<<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color1<<"Enter"<<RSTA<<" ("<<cD.menu_color1<<"1"<<RSTA<<") - "<<cD.menu_color1<<"to Preview colour theme"<<RSTA<<" "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color2<<"Enter"<<RSTA<<" ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color2<<"to Apply colour theme"<<RSTA<<"   "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.back_color<<"Enter"<<RSTA<<" ("<<cD.back_color<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                    "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<endl;
					
					int colorMenuChoice;
					while(!(cin>>colorMenuChoice)){
				
					if(!colorMenuChoice)//if not valid Menu Option entered:
						{
						//also delete the wrong answer from screen or
						//tell that is not the correct answer.
						cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
					
						fflush(stdin);
						
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
						cout<<"			     ";
						continue;
							}
				
					if(colorMenuChoice < 0 || colorMenuChoice > 2) 
					{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
						 <<endl; continue;}
						 
					else {break;}
				}
			//-------------------------------------------------------------------------------
					
					if(colorMenuChoice == 0) {
						//back
						system("clear");
						inWintercolorMenu = false;
						break;}
						
					if(colorMenuChoice == 1){
						//preview color theme
						system("clear");
						colorDefault.summer_colorsFn();
							cout<<"SUMMER:"<<endl;
							
							cout<<"          "<<colorDefault.menu_color1<<"- PREVIEW DISPLAY -\n"
								<<colorDefault.keret_color<<"***************************************************"<<RSTA<<"\n"
								<<colorDefault.keret_color<<"*"<<RSTA<<colorDefault.menu_color1<<" Player's"<<RSTA<<" "<<colorDefault.menu_color2<<"Name"
								<<RSTA<<"       "<<colorDefault.menu_color1<<"Session's Total Score:"<<RSTA<<" "<<colorDefault.menu_color2
								<<"2344 "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<"                                               \n"
								<<"           "<<colorDefault.equattionText_color<<"Equation:"<<RSTA<<" "
								<<colorDefault.equation_color1<<"33"<<RSTA<<" "<<colorDefault.operation_color<<"/"<<RSTA<<" "
								<<colorDefault.equation_color2
								<<"7"<<RSTA<<" "<<colorDefault.operation_color<<"="<<RSTA"          "<<colorDefault.keret_color<<"*\n"
								<<"*"<<RSTA<<"                                                 \n"
								<<colorDefault.keret_color<<"***************************************************"<<RSTA"\n"
								<<"\n"
								<<"      "<<colorDefault.menu_color1<<"Your answer:"<<RSTA<<" "<<colorDefault.youranswer_color<<"4.71"<<RSTA"\n"
								<<"\n"
								<<RSTA"           "<<colorDefault.yes_color<<"YES"<<RSTA<<" "<<colorDefault.smily_color<<":)"<<RSTA<<"\n"
								<<"\n"
								<<"              "<<colorDefault.next_color<<"NEXT"<<colorDefault.keret_color
								<<"("<<colorDefault.next_color<<"n"
								<<colorDefault.keret_color<<")"<<RSTA
								<<"  or  "<<colorDefault.stop_color<<"STOP"<<colorDefault.keret_color
								<<"("<<colorDefault.stop_color<<"s"
								<<colorDefault.keret_color<<")"<<RSTA"\n"
								<<"                   "<<colorDefault.equation_color1<<"-->"<<RSTA
								//if your answer 'n' color same as next. if 's' color is same as stop...
								<<colorDefault.menu_color1<<" n"<<RSTA<<"\n"
								<<"\n"
								<<colorDefault.keret_color<<"*"<<RSTA<<"    "<<colorDefault.itsnotanumber_color<<"This is not a number"<<RSTA<<"             "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<"              "<<colorDefault.tryagain_color<<"Please, try again!"<<RSTA<<"      "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<colorDefault.keret_color<<"****************************************************"<<RSTA<<"\n"
								<<endl;
							//Set colourThemeFn()
							//Ask user Do you want to set this colour theme?
							cout<<"Press \33[1mENTER\33[0m if you've done here..."<<endl;
							cin.get();
							cin.get();
							system("clear");
							colorDefault.default_colorsFn();
					}	// end preview if
					
				if(colorMenuChoice == 2){
					// Apply your choice
					system("clear");
					
					
					colorSchemeNumberIn_main = 2;
					//set value in class var - to save and load
					sPlayersVector[sP_userSelected].sP_chosen_colorScheme_initializerFn_V5(2);
					
					if(sPlayersVector[sP_userSelected].sP_choosen_colorScheme_displayFn_V5() == 2){
					
					colorDefault.summer_colorsFn();
					cD.summer_colorsFn();
					colorThemeDisplayInfo_current = "\33[1;31mSUMMER theme\33[0m";
					
					//userSelectorFn_V5(sP_userSelected).chosen_colorScheme_V5 = colorSchemeNumberIn_main;
					//Save the data to file:
					sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector); // include savefile and the Object-vector
					cout<<"\n\n\n\n\n\n\n\n\n\n\n"<<endl;
					cout<<setw(25)<<BRIGHT<<"That's all done for you "
						<<sPlayersVector[sP_userSelected].name_displayFn_V5()<<RSTA<<endl;
					}
					//TestLine:
					//cout<<"colorcode: "<<sPlayersVector[sP_userSelected].sP_choosen_colorScheme_displayFn_V5();
					inWintercolorMenu = false;
					sleep(2);
					}
				}
			}
				break;
				//---------------------------------------------------------
				case 4: // AUTUMN
				if(selectedColourTheme == 4){
					
				system("clear");
					
					inWintercolorMenu = true;
					
					while(inWintercolorMenu){
					cout<<"\n"<<endl;	
					cout<<RSTA<<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color1<<"Enter"<<RSTA<<" ("<<cD.menu_color1<<"1"<<RSTA<<") - "<<cD.menu_color1<<"to Preview colour theme"<<RSTA<<" "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color2<<"Enter"<<RSTA<<" ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color2<<"to Apply colour theme"<<RSTA<<"   "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.back_color<<"Enter"<<RSTA<<" ("<<cD.back_color<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                    "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<endl;
					
					int colorMenuChoice;
					while(!(cin>>colorMenuChoice)){
				
					if(!colorMenuChoice)//if not valid Menu Option entered:
						{
						//also delete the wrong answer from screen or
						//tell that is not the correct answer.
						cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
					
						fflush(stdin);
						
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
						cout<<"			     ";
						continue;
							}
				
					if(colorMenuChoice < 0 || colorMenuChoice > 2) 
					{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
						 <<endl; continue;}
						 
					else {break;}
				}
			//-------------------------------------------------------------------------------
					
					if(colorMenuChoice == 0) {
						//back
						system("clear");
						inWintercolorMenu = false;
						break;}
						
					if(colorMenuChoice == 1){
						//preview color theme
						system("clear");
						colorDefault.autumn_colorsFn();
							cout<<"AUTUMN:"<<endl;
							
							cout<<"          "<<colorDefault.menu_color1<<"- PREVIEW DISPLAY -\n"
								<<colorDefault.keret_color<<"***************************************************"<<RSTA<<"\n"
								<<colorDefault.keret_color<<"*"<<RSTA<<colorDefault.menu_color1<<" Player's"<<RSTA<<" "<<colorDefault.menu_color2<<"Name"
								<<RSTA<<"       "<<colorDefault.menu_color1<<"Session's Total Score:"<<RSTA<<" "<<colorDefault.menu_color2
								<<"2344 "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<"                                               \n"
								<<"           "<<colorDefault.equattionText_color<<"Equation:"<<RSTA<<" "
								<<colorDefault.equation_color1<<"33"<<RSTA<<" "<<colorDefault.operation_color<<"/"<<RSTA<<" "
								<<colorDefault.equation_color2
								<<"7"<<RSTA<<" "<<colorDefault.operation_color<<"="<<RSTA"          "<<colorDefault.keret_color<<"*\n"
								<<"*"<<RSTA<<"                                                 \n"
								<<colorDefault.keret_color<<"***************************************************"<<RSTA"\n"
								<<"\n"
								<<"      "<<colorDefault.menu_color1<<"Your answer:"<<RSTA<<" "<<colorDefault.youranswer_color<<"4.71"<<RSTA"\n"
								<<"\n"
								<<RSTA"           "<<colorDefault.yes_color<<"YES"<<RSTA<<" "<<colorDefault.smily_color<<":)"<<RSTA<<"\n"
								<<"\n"
								<<"              "<<colorDefault.next_color<<"NEXT"<<colorDefault.keret_color
								<<"("<<colorDefault.next_color<<"n"
								<<colorDefault.keret_color<<")"<<RSTA
								<<"  or  "<<colorDefault.stop_color<<"STOP"<<colorDefault.keret_color
								<<"("<<colorDefault.stop_color<<"s"
								<<colorDefault.keret_color<<")"<<RSTA"\n"
								<<"                   "<<colorDefault.equation_color1<<"-->"<<RSTA
								//if your answer 'n' color same as next. if 's' color is same as stop...
								<<colorDefault.menu_color1<<" n"<<RSTA<<"\n"
								<<"\n"
								<<colorDefault.keret_color<<"*"<<RSTA<<"    "<<colorDefault.itsnotanumber_color<<"This is not a number"<<RSTA<<"             "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<"              "<<colorDefault.tryagain_color<<"Please, try again!"<<RSTA<<"      "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<colorDefault.keret_color<<"****************************************************"<<RSTA<<"\n"
								<<endl;
							//Set colourThemeFn()
							//Ask user Do you want to set this colour theme?
							cout<<"Press \33[1mENTER\33[0m if you've done here..."<<endl;
							cin.get();
							cin.get();
							system("clear");
							colorDefault.default_colorsFn();
					}	// end preview if
					
				if(colorMenuChoice == 2){
					// Apply your choice
					system("clear");
					
					
					colorSchemeNumberIn_main = 3;
					//set value in class var - to save and load
					sPlayersVector[sP_userSelected].sP_chosen_colorScheme_initializerFn_V5(3);
					if(sPlayersVector[sP_userSelected].sP_choosen_colorScheme_displayFn_V5() == 3){
					colorDefault.autumn_colorsFn();
					cD.autumn_colorsFn();
					colorThemeDisplayInfo_current = "\033[1;33mAUTUMN theme\33[0m";	
					
					//userSelectorFn_V5(sP_userSelected).chosen_colorScheme_V5 = colorSchemeNumberIn_main;
					//Save the data to file:
					sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector); // include savefile and the Object-vector
					cout<<"\n\n\n\n\n\n\n\n\n\n\n"<<endl;
					cout<<setw(25)<<BRIGHT<<"That's all done for you "
						<<sPlayersVector[sP_userSelected].name_displayFn_V5()<<RSTA<<endl;
					}
					//TestLine:
					//cout<<"colorcode: "<<sPlayersVector[sP_userSelected].sP_choosen_colorScheme_displayFn_V5();
					inWintercolorMenu = false;
					sleep(2);
					}
				}
			}
				break;
				//---------------------------------------------------------
				case 5: //Winter
				if(selectedColourTheme == 5){
					
					system("clear");
					
					inWintercolorMenu = true;
					
					while(inWintercolorMenu){
					cout<<"\n"<<endl;	
					cout<<RSTA<<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color1<<"Enter"<<RSTA<<" ("<<cD.menu_color1<<"1"<<RSTA<<") - "<<cD.menu_color1<<"to Preview colour theme"<<RSTA<<" "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color2<<"Enter"<<RSTA<<" ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color2<<"to Apply colour theme"<<RSTA<<"   "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.back_color<<"Enter"<<RSTA<<" ("<<cD.back_color<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                    "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<endl;
					
					int colorMenuChoice;
					while(!(cin>>colorMenuChoice)){
				
					if(!colorMenuChoice)//if not valid Menu Option entered:
						{
						//also delete the wrong answer from screen or
						//tell that is not the correct answer.
						cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
					
						fflush(stdin);
						
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
						cout<<"			     ";
						continue;
							}
				
					if(colorMenuChoice < 0 || colorMenuChoice > 2) 
					{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
						 <<endl; continue;}
						 
					else {break;}
				}
			//-------------------------------------------------------------------------------
					
					if(colorMenuChoice == 0) {
						//back
						system("clear");
						inWintercolorMenu = false;
						break;}
						
					if(colorMenuChoice == 1){
						//preview color theme
						system("clear");
						colorDefault.winter_colorsFn();
							cout<<"Winter:"<<endl;
							
							cout<<"          "<<colorDefault.menu_color1<<"- PREVIEW DISPLAY -\n"
								<<colorDefault.keret_color<<"***************************************************"<<RSTA<<"\n"
								<<colorDefault.keret_color<<"*"<<RSTA<<colorDefault.menu_color1<<" Player's"<<RSTA<<" "<<colorDefault.menu_color2<<"Name"
								<<RSTA<<"       "<<colorDefault.menu_color1<<"Session's Total Score:"<<RSTA<<" "<<colorDefault.menu_color2
								<<"2344 "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<"                                               \n"
								<<"           "<<colorDefault.equattionText_color<<"Equation:"<<RSTA<<" "
								<<colorDefault.equation_color1<<"33"<<RSTA<<" "<<colorDefault.operation_color<<"/"<<RSTA<<" "
								<<colorDefault.equation_color2
								<<"7"<<RSTA<<" "<<colorDefault.operation_color<<"="<<RSTA"          "<<colorDefault.keret_color<<"*\n"
								<<"*"<<RSTA<<"                                                 \n"
								<<colorDefault.keret_color<<"***************************************************"<<RSTA"\n"
								<<"\n"
								<<"      "<<colorDefault.menu_color1<<"Your answer:"<<RSTA<<" "<<colorDefault.youranswer_color<<"4.71"<<RSTA"\n"
								<<"\n"
								<<RSTA"           "<<colorDefault.yes_color<<"YES"<<RSTA<<" "<<colorDefault.smily_color<<":)"<<RSTA<<"\n"
								<<"\n"
								<<"              "<<colorDefault.next_color<<"NEXT"<<colorDefault.keret_color
								<<"("<<colorDefault.next_color<<"n"
								<<colorDefault.keret_color<<")"<<RSTA
								<<"  or  "<<colorDefault.stop_color<<"STOP"<<colorDefault.keret_color
								<<"("<<colorDefault.stop_color<<"s"
								<<colorDefault.keret_color<<")"<<RSTA"\n"
								<<"                   "<<colorDefault.equation_color1<<"-->"<<RSTA
								//if your answer 'n' color same as next. if 's' color is same as stop...
								<<colorDefault.menu_color1<<" n"<<RSTA<<"\n"
								<<"\n"
								<<colorDefault.keret_color<<"*"<<RSTA<<"    "<<colorDefault.itsnotanumber_color<<"This is not a number"<<RSTA<<"             "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<"              "<<colorDefault.tryagain_color<<"Please, try again!"<<RSTA<<"      "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<colorDefault.keret_color<<"****************************************************"<<RSTA<<"\n"
								<<endl;
							//Set colourThemeFn()
							//Ask user Do you want to set this colour theme?
							cout<<"Press \33[1mENTER\33[0m if you've done here..."<<endl;
							cin.get();
							cin.get();
							system("clear");
							colorDefault.default_colorsFn();
					}	// end preview if
					
				if(colorMenuChoice == 2){
					// Apply your choice
					system("clear");
					
					
					colorSchemeNumberIn_main = 4;
					//set value in class var - to save and load
					sPlayersVector[sP_userSelected].sP_chosen_colorScheme_initializerFn_V5(4);
					if(sPlayersVector[sP_userSelected].sP_choosen_colorScheme_displayFn_V5() == 4){
					colorDefault.winter_colorsFn();
					cD.winter_colorsFn();
					colorThemeDisplayInfo_current = "\33[1mWINTER theme\33[0m";	
					
					//userSelectorFn_V5(sP_userSelected).chosen_colorScheme_V5 = colorSchemeNumberIn_main;
					//Save the data to file:
					sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector); // include savefile and the Object-vector
					cout<<"\n\n\n\n\n\n\n\n\n\n\n"<<endl;
					cout<<setw(25)<<BRIGHT<<"That's all done for you "
						<<sPlayersVector[sP_userSelected].name_displayFn_V5()<<RSTA<<endl;
					}
					//TestLine:
					//cout<<"colorcode: "<<sPlayersVector[sP_userSelected].sP_choosen_colorScheme_displayFn_V5();
					inWintercolorMenu = false;
					sleep(2);
					}
			
				} // end of while in winterColor Menu loop
				
						} // end if statement, case 5 color menu 
				break;
			} // end color switchboard
			
			} // end loop "while in color menu"	
			break;
			//----------------------------------------------------------
			case 2: //difficulty levels
			
				inDifficultyOptionMenu = true;
			
			while(inDifficultyOptionMenu)
			{
				system("clear");
				if(sPlayersVector[sP_userSelected].sP_chosen_level_displayFn_V5() == 1){
					showCurrentDiffLevel = "\33[1;37mEASY\33[0m";
				}
				if(sPlayersVector[sP_userSelected].sP_chosen_level_displayFn_V5() == 2){
					showCurrentDiffLevel = "\33[1;32mNORMAL\33[0m";
				}
				if(sPlayersVector[sP_userSelected].sP_chosen_level_displayFn_V5() == 3){
					showCurrentDiffLevel = "\33[;1;33mEXPERT\33[0m";
				}
				if(sPlayersVector[sP_userSelected].sP_chosen_level_displayFn_V5() == 4){
					showCurrentDiffLevel = "\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m";
				}
				
				
				
				cout<<"\n"
					<<"                    Current difficulty: "<<showCurrentDiffLevel<<RSTA<<endl;
				cout<<"\n"
					<<setw(30)<<"                    \33[4m*** CHOOSE DIFFICULTY ***"<<RSTA<<"\n"<<endl;
				cout<<setw(30)<<"          \33[3mPlease note\33[0m: By default the game is running\n"
					<<setw(43)<<"                       on \33[3;33mNORMAL\33[0m difficulty.\n"<<endl;
				cout<<setw(30)<<"          (\33[1m1\33[0m) - \33[1;37mEASY\33[0m -   You'll get to solve equations\n"
					<<setw(42)<<"                         including numbers between \33[1m0-10\33[0m."<<endl;
				cout<<setw(30)<<"          (\33[1;32m2\33[0m) - \33[1;32mNORMAL\33[0m - You'll get to solve equations\n"
					<<setw(44)<<"                         including numbers between \33[1;32m0-100\33[0m."<<endl;
				cout<<setw(30)<<"          (\33[;1;33m3\33[0m) - \33[;1;33mEXPERT\33[0m - You'll get to solve equations\n"
					<<setw(42)<<"                         including numbers between \33[;1;33m0-1000\33[0m.\n"<<endl;
				if(sPlayersVector[sP_userSelected].sP_masterlevel_unlocked == true){
					cout<<setw(30)<<"          (\33[1;31m4\33[0m) - \33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m - You'll get to solve equations\n"
					<<setw(42)<<"                        including numbers between \33[1;31m0-10000\33[0m.\n"<<endl;
				}
				int ch;
				cout<<setw(30)<<"          Setting difficulty by entering the number\n"
					<<"          sitting front of your choice --> ";
				
				cin>>ch; // make this idiotproof!!!!
				
				if(ch == 1){
					//set easy diff
					easySwitch = true;
					expertSwitch = false;
					inDifficultyOptionMenu = false;
					cout<<"\n"<<setw(30)<<"Game set to "<<BRIGHT<<"\33[1;37mEASY\33[0m"<<RSTA<<" difficulty for you!"<<endl;
					difficulty_message = "\33[1;37mEasy\33[0m";
					sPlayersVector[sP_userSelected].sP_chosen_level_initializerFn_V5(1);
					//Save the data to file:
					sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector);
					
					//test if played...
					//cout<<"da....."<<sPlayersVector[sP_userSelected].sP_chosen_level_displayFn_V5()<<endl;
					
					sleep(2);
					break;}
					
				if(ch == 2){
					//set normal diff
					easySwitch = false;
					expertSwitch = false;
					inDifficultyOptionMenu = false;
					cout<<"\n"<<setw(30)<<"Game set to "<<BRIGHT<<"\33[1;32mNORMAL\33[0m"<<RSTA<<" difficulty for you!"<<endl;
					difficulty_message = "\33[1;32mNormal\33[0m";
					sPlayersVector[sP_userSelected].sP_chosen_level_initializerFn_V5(2);
					//Save the data to file:
					sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector);
					
					//test if played...
					//cout<<"da....."<<sPlayersVector[sP_userSelected].sP_chosen_level_displayFn_V5()<<endl;
					
					sleep(2);
					break;}
					
				if(ch == 3){
					//set expert diff
					easySwitch = false;
					expertSwitch = true;
					inDifficultyOptionMenu = false;
					cout<<"\n"<<setw(30)<<"Game set to "<<BRIGHT<<"\33[1;33mEXPERT\33[0m"<<RSTA<<" difficulty for you!"<<endl;
					difficulty_message = "\33[1;33mExpert\33[0m";
					sPlayersVector[sP_userSelected].sP_chosen_level_initializerFn_V5(3);
					//Save the data to file:
					sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector);
					
					//test if played...
					//cout<<"da....."<<sPlayersVector[sP_userSelected].sP_chosen_level_displayFn_V5()<<endl;
					
					sleep(2);
					break;}
					
				if(ch == 4 && sPlayersVector[sP_userSelected].sP_masterlevel_unlocked == true){
					//set MASTER diff
					easySwitch = true;
					expertSwitch = true;
					inDifficultyOptionMenu = false;
					cout<<"\n"<<setw(30)<<"Game set to "<<BRIGHT
						<<"\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m"
						<<RSTA<<" difficulty for you!"<<endl;
					difficulty_message = "\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m";
					sPlayersVector[sP_userSelected].sP_chosen_level_initializerFn_V5(4);
					//Save the data to file:
					sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector);
					
					//test if played...
					//cout<<"da....."<<sPlayersVector[sP_userSelected].sP_chosen_level_displayFn_V5()<<endl;
					
					sleep(2);
					break;}
					
				else{cout<<"\n"<<setw(30)<<"Sorry, I didn't get that!\n"
						<<setw(30)<<"Please try again!"<<endl;
						continue;}
					}	
					
				break;	
				
			//---------------------------------------------------------
			
			case 3: // Change name
			
				system("clear");
				// ask for new name/PIN -> save to buffer,
				cout<<"\n     "<<cD.menu_color2<<"Please enter new name:"<<RSTA<<" ";
				nw_name_buff_V5 = "default";
				cin>>nw_name_buff_V5;
				// then set it to the user, and save.
				//put logik here:
				sPlayersVector[sP_userSelected].name_setterFn_V5(nw_name_buff_V5);
				cout<<"\n"<<cD.equattionText_color<<"Okay, that's all done for you,"<<RSTA<<" "
					<<cD.operation_color<<sPlayersVector[sP_userSelected].name_displayFn_V5()<<"."<<RSTA<<endl;
				sleep(2);
				//Save the data to file:
				sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector); // include savefile and the Object-vector
			
			break;
			//----------------------------------------------------------
			case 4: // Change pin
			
				system("clear");
				cout<<"\n"<<endl;
				cout<<"     "<<cD.menu_color1<<"Please enter new PIN:"<<RSTA<<" ";
				int nw_pin_buff_V5;
				cin>>nw_pin_buff_V5;
				// put logik here
				sPlayersVector[sP_userSelected].idNum_setterFn_V5(nw_pin_buff_V5);
				cout<<"\n"<<cD.equattionText_color<<"Okay, that's all changed for you,"<<RSTA<<" "
					<<cD.operation_color<<sPlayersVector[sP_userSelected].name_displayFn_V5()<<"."<<RSTA<<endl;
				sleep(2);
				//Save the data to file:
				sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector); // include savefile and the Object-vector
			
			break;
			//----------------------------------------------------------
			case 5: // Delete profile
			
				in_deleteProfileMenu = true;
		
		
		while(in_deleteProfileMenu){
			system("clear");
			// Invoke Change DeleteProfileFn
			cout<<"            "<<cD.keret_color<<"*********************************"<<RSTA<<"\n"
				<<"            "<<cD.keret_color<<"*"<<RSTA<<"  ("<<cD.menu_color1<<"1"<<RSTA<<") - "<<cD.menu_color1<<"DELETE your profile"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"            "<<cD.keret_color<<"*"<<RSTA<<"  ("<<cD.menu_color2<<"0"<<RSTA") - "<<cD.menu_color2<<"BACK"<<RSTA<<"                   "<<cD.keret_color<<"*"<<RSTA"\n"
				<<"            "<<cD.keret_color<<"*********************************"<<RSTA<<"\n"
				<<endl;
				
			
		cout<<"     "<<cD.equattionText_color<<"Enter the selected menu point:"<<RSTA<<" ";
		while(!(cin>>delete_profileOrnot_int))
		{
		
			if(!delete_profileOrnot_int)//if not valid Menu Option entered:
			
				{//I need to play a sound if Incorrect! (no message)
				//also delete the wrong answer from screen or
				//tell that is not the correct answer.
        cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
            
            fflush(stdin);
        
		cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout<<"			     ";
        continue;
			}
		
			if(delete_profileOrnot_int < 0 || delete_profileOrnot_int > 5) 
			{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
				 <<endl; continue;}
			else {break;} 
		}
		//--------------------------------------------------------------
		switch (delete_profileOrnot_int){
			
			case 0: //BACK
					playerUserSelected = false;
					in_deleteProfileMenu = false;
			        system("clear");
					//Might need to reset, update, save some data here befor we go back...
					break;
			//---------------------------------------------------------		
			case 1:	// DELETE profile
				
				while_inDelete_profile_bool = true;
				while(while_inDelete_profile_bool){
				// ask that you about to delet your profile... note that your statistics
				// will be deleted too.
				cout<<"\n\33[1mAre you sure you want to \33[1;31mDELETE\33[1m your profile,\33[0m "<<cD.equation_color1<<sPlayersVector[sP_userSelected].name_displayFn_V5()
					<<"\33[1m?\33[0m\n"<<endl;
				cout<<"PRESS (\33[1;32mY\33[0m) if \33[1;32mYES\33[0m or (\33[1;31mN\33[0m) if \33[1;31mNO\33[0m"<<endl;
				
				char delete_user_buffer_char;
				delete_user_buffer_char = 0;
				
				cin>>delete_user_buffer_char;	
					//if YES...
					if(delete_user_buffer_char == 'y' || delete_user_buffer_char == 'Y'){
						cout<<"Please enter your \33[1mPIN\33[0m to confirm \33[1;31mDELETION\33[0m!\n"<<endl;
						int pin_buffer;
						pin_buffer = 0;
						cin>>pin_buffer;
							if(pin_buffer == sPlayersVector[sP_userSelected].idNum_displayFn_V5()){
								//delete
								cout<<FREDBOLD<<"\nDELETION COMFIRMED."<<RSTA<<"\n";
								cout<<"(After deleted your profile program will terminate.\n"
									<<"Please, restart it manualLy if you'd like to play again!)\n\n"
									<<"Thank you!"<<endl;
								sleep(3);
								cout<<"\nDeleting ";
								for(int n = 3; n > 0; n--){
									cout<<".";
									sleep(1);
									fflush(stdout);}
								//erase player profile logic	
								sPlayersVector.erase(sPlayersVector.begin() + sP_userSelected); // .begin() is the "guest users"
									cout<<FREDBOLD<<"\nProfile deleted."<<RSTA<<endl;
									//save changes	
									sP_saveFNfor_sPlayerClass_V5(saveFileName_SP_V5,sPlayersVector);
									sleep(1);
									//exit loop
									exitLoop();
									return 0;
								
									}
								else{
									cout<<BRIGHT<<"\nWrong \33[1;31mPIN\33[1;m! Please, try again..."<<RSTA<<endl;
									sleep(2);
									system("clear");}							
							
								break;
								}
						// if NO....	
						if(delete_user_buffer_char == 'n' || delete_user_buffer_char == 'N'){
							cout<<"\nI see... You change your mind! Fine..."<<endl;
							sleep(2);
							while_inDelete_profile_bool = false;
							in_deleteProfileMenu = false;
							break;}
						// invalid option
						else{cout<<"\n Not a valid option. Please enter 'Y' or 'N'\n"<<endl;
							cin>>delete_user_buffer_char;
							continue;}
					}
				
				
				break;
			} // switchboard end (delete profile)
		}//while in_deleteProfileMenu END
			break;
			
			//----------------------------------------------------------	
			}//Options Switchboard END
		}//While in Options menu END
		
	
		
		//--------------------------------------------------------------
			} // END of (SINGLE PLAYER) "Logged in" PERSONAL MENU SWITCH BOARD
		
		//--------------------------------------------------------------
				} // (while userPlayerSelected Loop END)
				
				break; // END OF SINGLE PLAYER MENU
	//------------------------------------------------------------------
	//====================================================================================================================================
		case 2: // MultiPlayer
		
				//================================= TO DO & HOW & WHAT ===========================================
				//1; Who's playin'? (no pin requied just name ( no same name criteria!!! implement compare)
				//		- assign players to vector -> check prev versions for the loop for multiplayer....
				//		- then return to menu, show player names on top of screen... | 1 | 2 | 3 | ....
				//2; Play the game
				//		- same loop from single player... milestones too, but dont count achived achivements
				//		- One round is over once every player had its turn (show it on a counter Current Player: 2 | Turns:(2/4) | Next Player: 3
				//		- memorize records, save to file only player's name and score -> for leader board records
				//3; Leaderboard
				//		- Keep on record the 10 highest score ( on a vector ) (leaderboard class -> it's own save&loadFn)
				//				- save record with unique id, so if user with same name still get to keep prev record...
				//				- once list of 10 is full check if there is any higher score from current session then saved
				//				- if yes update list accordingly
				//4; Set difficulty
				//		- same as Sp mode (isolate it to mP mode!!!)
				//5; Set colour theme
				//		- same as Sp mode (isolate it to mP mode!!!)
				//0; BACK ot Main menu
				//=================================================================================================
		
			inMultiPlayerModeShell_V5 = true;
			
			while(inMultiPlayerModeShell_V5){
				
				
				system("clear");
				
				//reset menupoint
				//mPlayerMenuSelected = -1;
				//Load color theme
				if(set_mPlayer_colorTheme == 0){cD.default_colorsFn();}
				if(set_mPlayer_colorTheme == 1){cD.spring_colorsFn();}
				if(set_mPlayer_colorTheme == 2){cD.summer_colorsFn();}
				if(set_mPlayer_colorTheme == 3){cD.autumn_colorsFn();}
				if(set_mPlayer_colorTheme == 4){cD.winter_colorsFn();}
				
				
				cout<<"\n\n\n"<<endl;
				cout<<"                        "
					<<FREDBOLD<<"M"
					<<FBLUEBOLD<<"U"
					<<FGREENBOLD<<"L"
					<<FWHITEBOLD<<"T"
					<<FMAGENTABOLD<<"I"
					<<FYELLOWBOLD<<"P"
					<<FREDBOLD<<"L"
					<<FWHITEBOLD<<"A"
					<<FGREENBOLD<<"Y"
					<<FBLUEBOLD<<"E"
					<<FCAYENBOLD<<"R"<<RSTA<<" "
					<<FYELLOWBOLD<<"M"
					<<FWHITEBOLD"O"
					<<FCAYENBOLD<<"D"
					<<FMAGENTABOLD<<"E"<<RSTA<<" \n";
					
				cout<<"               "<<cD.keret_color<<"=================================="<<RSTA<<"\n"
					<<"               "<<cD.keret_color<<"|"<<RSTA<<"       "<<cD.keret_color<<"("<<cD.menu_color2<<"1"<<cD.keret_color<<")"<<RSTA<<" - "<<cD.menu_color1<<"Play the Game"<<RSTA<<"      "<<cD.keret_color<<"|"<<RSTA<<"\n"
					<<"               "<<cD.keret_color<<"|"<<RSTA<<"       "<<cD.keret_color<<"("<<cD.menu_color2<<"2"<<cD.keret_color<<")"<<RSTA<<" - "<<cD.menu_color1<<"Options"<<RSTA<<"            "<<cD.keret_color<<"|"<<RSTA<<"\n"
					<<"               "<<cD.keret_color<<"|"<<RSTA<<"       "<<cD.keret_color<<"("<<cD.menu_color2<<"3"<<cD.keret_color<<")"<<RSTA<<" - "<<cD.menu_color1<<"Leaderboard"<<RSTA"        "<<cD.keret_color<<"|"<<RSTA<<"\n"
					<<"               "<<cD.keret_color<<"|"<<RSTA<<"       "<<cD.keret_color<<"("<<cD.menu_color2<<"0"<<cD.keret_color<<")"<<RSTA<<" - "<<cD.back_color<<"BACK"<<RSTA<<"               "<<cD.keret_color<<"|"<<RSTA<<"\n"
					<<"               "<<cD.keret_color<<"=================================="<<RSTA<<"\n"
					<<endl;
				
				while(!(cin>>mPlayerMenuSelected))
		{
		
			if(!mPlayerMenuSelected)//if not valid Menu Option entered:
			
				{//I need to play a sound if Incorrect! (no message)
				//also delete the wrong answer from screen or
				//tell that is not the correct answer.
        cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
            
            fflush(stdin);
        
		cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout<<"			     ";
        continue;
			}
		
			if(mPlayerMenuSelected < 0 || mPlayerMenuSelected > 3) 
			{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
				 <<endl; continue;}
			else {break;} 
		}
					
		//------------------------------------------------------------------------------------------		
				
		switch (mPlayerMenuSelected){
					
				case 0: // Back to main menu
					
						inMultiPlayerModeShell_V5 = false;
						system("clear");
						break;
	//----------------------------------------------------------------------------------------------	
	
	//MPlayer LOOP:
	
				case 1: // Play the game (Mplayer)
					
				
						
					system("clear");
					mP_while_playingGame_V5 = true;
					//erase previus players from  (play)list
					//delete players from mPlayer Vector -> reset for next time
					mPlayersVector.clear();
					mPpersonOnList = 0;
					mp_unlimitedLoopExit = false;
					//for(mP_i = mPpersonOnList; mP_i > 0; mP_i--){mPlayersVector.pop_back();}
			
	cout<<endl;
	cout<<"      "<<cD.menu_color1<<"Alright! Who's playin'? \33[3m(minimum two player needed)\33[0m"<<RSTA<<"\n"
		<<"      "<<cD.menu_color1<<ITALIC<<"(Please don't enter the same name for two or more players.)"<<RSTA<<"\n\n"
		<<"      "<<cD.menu_color2<<"Enter the name of the 1st player, please!"<<RSTA<<"\n"
		<<ITALIC<<"      (Max size of name: 10 letters) : "<<RSTA;
	
	adding_names_to_mPlayerList = true;
		
	while(adding_names_to_mPlayerList){
	
	cin>>mP_nameBuffer;
		
	
	//stop adding names
	if(mP_nameBuffer == "q" || mP_nameBuffer == "Q"){
		if(mPlayersVector.size() == 1){
			cout<<"\n\33[1mPlease, you can not play multiplayer alone!!! COME ON!  :)\33[0m\n";
			cout<<"\n      Who else is playing with you this time?"<<RSTA<<"\n"
		<<ITALIC<<"      (Enter '"<<BRIGHT<<"q"<<RSTA<<ITALIC<<"' or '"<<BRIGHT<<"Q"<<RSTA
		<<ITALIC<<"' as a name once you got all the players.)\n"<<RSTA
		<<cD.menu_color2<<"      Please enter the name of the "<<cD.next_color<<"next player"<<cD.menu_color2<<": "<<RSTA;
		continue;
		}
		else{
			adding_names_to_mPlayerList = false;
			break;}
		}
		
	//Max 10 char if more erase the overflow
	if(mP_nameBuffer.size() > 10){
		while(mP_nameBuffer.size() > 10){
			mP_nameBuffer.erase(mP_nameBuffer.length()-1);}
			}
	//If less then 10, add padding to make it 10 (use space)
	if(mP_nameBuffer.size() < 10 && (mP_nameBuffer != "q" || mP_nameBuffer != "Q")){
		while(mP_nameBuffer.size() < 10){
			mP_nameBuffer.append(1,' ');}
			}
			
			
	//Check same name in same session
	for(auto& obj : mPlayersVector){
		
		if(obj.mP_name_displayFn_V5() == mP_nameBuffer){
			cout<<"\n    That name has already taken in this session!\n"
				<<"    \33[1mPlease choose an other name!"<<RSTA<<endl;
			sleep(2);
			mP_sameName_switch = true;
			break;
		}
		else{mP_sameName_switch = false;}
	}
	//if not same -> add the player
	if(mP_sameName_switch){continue;}
	else if(!mP_sameName_switch){mPlayersVector.push_back(mP_nameBuffer);}
	
	cout<<"\n"<<endl;
	cout<<cD.menu_color1<<"      Yes,"<<RSTA<<" "<<cD.equattionText_color<<mP_nameBuffer<<cD.menu_color1<<"\n"
		<<"      Who else is playing with you this time?"<<RSTA<<"\n"
		<<ITALIC<<"      (Enter '"<<BRIGHT<<"q"<<RSTA<<ITALIC<<"' or '"<<BRIGHT<<"Q"<<RSTA
		<<ITALIC<<"' as a name once you got all the players.)\n"<<RSTA
		<<"      "<<cD.menu_color2<<"Please enter the name of the "<<cD.next_color<<"next player \33[1m: "<<RSTA;
		
		
	}
	
	
	if(mPlayersVector.empty()){continue;}
		
	system("clear");
		mP_i = 1;
		cout<<"\n"
			<<"              "<<cD.menu_color1<<"*** ENLISTED PLAYERS ***\n"
			<<"              "<<cD.keret_color<<"========================"<<RSTA<<endl;
			
		for(mP_i = 0; mP_i < mPpersonOnList; mP_i++){
		cout<<"                   "<<cD.menu_color1<<mP_i + 1<<RSTA<<". "
		<<cD.menu_color2<<mPlayersVector[mP_i].mP_name_displayFn_V5()<<RSTA<<endl;
		//update diff level to players on lb
		mPlayersVector[mP_i].mP_Level_InClass_setterFn_V5(mP_Level);
		}
	
	
	cout<<"\n"              
		<<cD.menu_color1<<"      Set target round! "<<cD.keret_color<<"(\33[3mEnter "<<RSTA<<"'\33[1m0\33[0m'"<<cD.keret_color<<" \33[3mto play unlimited rounds"<<RSTA")"<<cD.menu_color1<<" : "<<RSTA;
	rounds = 1;	
	//reset round _buffer
	round_buffer = -1;
	while(!(cin>>round_buffer)){
		
		if(!round_buffer)//if not valid Menu Option entered:
			
				{//I need to play a sound if Incorrect! (no message)
				//also delete the wrong answer from screen or
				//tell that is not the correct answer.
        cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
            
            fflush(stdin);
        
		cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout<<"			     ";
        continue;
			}
		
			if(round_buffer < 0) 
			{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
				 <<endl; continue;}
			else {break;} 
		
		}
		//------------------------------------------------------------------------------------------
		
		
		cout<<endl;
		cout<<"              "<<cD.smily_color<<"Alright players! That's all set! Have fun! :)"<<RSTA<<"\n"<<endl;
		cout<<"Press \33[1mENTER\33[0m to continue..."<<RSTA<<endl;
		cin.get();
		cin.get();
		
		
	//----------------------------------------------------------------------------------------------
	//Reset values to the next game
	for(auto& obj : mPlayersVector){
			obj.mP_attemptCounter_singleSession_initializerFn_V5(0);
			obj.mP_currentRound_initializerFn_V5(1);
			obj.mP_totalScoreInThisSession_initialiserFn_V5(0);
			obj.mP_goodAnswerStreek_initialiserFn_V5(0);
			obj.mP_longestGoodAnswerStreak_initialiserFn_V5(0);
			obj.mP_sessionGoodAnswerCounter_V5_initializerFn(0);
			obj.mP_skip_initializerFn_V5(3);
			obj.mP_lifes_V5_initialiserFn(3);
			obj.mP_lifesLost_inLastSession_initializerFn_V5(0);
		}

	system("clear");
	
	//================================== TURN BY TURN LOOP =========================================
	//========================================MPLAYER===============================================
	//Game start, turn by turn loop: // Until exit...
	
	while(mP_while_playingGame_V5){
		
		//reset mP_i counter
		mP_i = 0;
		//reset GA counter
		//mP_sessionGoodAnswerCounter_V5_initializerFn(0);
		//get each user has its turn: // One round
		for(mP_i = 0; mP_i < mPpersonOnList; mP_i++){
			
			system("clear");
			//if player game overed, the other players still can play. Creating a podium order...
			//if only one player left with life can decide to stop or keep playing....
			if(mPlayersVector[mP_i].mP_lifes_displayFn_V5() <= 0){continue;}
			
			//==========================================================
			//========= MULTIPLAYER GAME LOOP INVOKED HERE =============
			else{
				 
				 whileInGameLoop = true; // So the next player can enter the gameloop...
				 //The Mplayer gameLoop
				 multiplayer_GameLoopFn_V5(mPlayersVector[mP_i]);
				 //mPlayersVector[mP_i].mP_totalRoundsPlayed_displayFn_V5() = mPlayersVector[mP_i].mP_currentRound_displayFn_V5();
				}
			//----------------------------------------------------------
			//Auto-Turn
			if(mP_i < (mPpersonOnList - 1)){
			if(!mp_auto_turn){
				system("clear");
				cout<<"\n\n\n\n"<<endl;
				cout<<BRIGHT<<"                      *** \33[5mNEXT PLAYER\33[0m ***\n\n"
					<<"                                 \33[3m(PRESS ENTER)\33[0m"<<endl;
				cin.get();
			}
			//stop/exit if unlimited round and auto round is on
			else if(mp_auto_turn){
				if(mp_unlimitedLoopExit){break;}
				for(int i = 3; i >0;i--){
				system("clear");
				cout<<"\n\n\n\n"<<endl;
				cout<<BRIGHT<<"                      *** \33[5mNEXT PLAYER\33[0m ***\n\n";			
				
					cout<<"                            \33[3m- "<<i<<" -\33[0m";
					fflush(stdin);
					fflush(stdout);
					sleep(1);
					}
				}
			}
		} //END OF one turn gameloop
		//==========================================================================================		 	
		//==========================================================================================	
			
			//    ***CHECKING PLAYER-LIST and PLAYER STATUS***
			
			system("clear");
			// search for players with life left
			// if only one left with life Display on that player the victory message
			
			// get the count
			count_mPplayers_with_lifes = 0;
			
			for(auto& obj : mPlayersVector){
				if(obj.mP_lifes_displayFn_V5() > 0){
					count_mPplayers_with_lifes++;}
				}
				
			//Display message if only one left with life:		
			if(count_mPplayers_with_lifes == 1){
				
				for(mP_i = 0; mP_i < mPpersonOnList; mP_i++){
				if(mPlayersVector[mP_i].mP_lifes_displayFn_V5() > 0){
				//display Victory message Fn:
				//mP_victoryMessage_displayFn_V5(mPlayersVector[mP_i]);
				cout<<cD.menu_color1<<"You are the last player standing "<<cD.menu_color2<<mPlayersVector[mP_i].mP_name_displayFn_V5()<<RSTA<<"\n"<<endl;
				cout<<cD.menu_color1<<"But are you the quickest and highest scorer?"<<RSTA;
				sleep(1);
				cout<<cD.menu_color2<<" ... Let's find out!"<<RSTA<<"\n"<<endl;
				}
				}
				
				//1st; Invoke sorting Fn ... then run the display Fn
					sort(mPlayersVector.begin(),mPlayersVector.end(),sortByHighestScore_andQuickestTime_ifScoreIs_same_MplayerFn_V5);
				
				if(mPlayersVector[0].mP_totalScoreInThisSession_displayFn_V5() == 0){
						system("clear");
						cout<<"\n\n\n\nWell, well, well.... Try harder next time! Shall we? :)\n"<<endl;
						sleep(3);
						system("clear");
					}
					else{
				//Victory message
					mP_victoryMessage_displayFn_V5(mPlayersVector[0]);
				system("clear");
				cout<<endl;
					mPlayersVector[0].mP_statisticsDisplayFn_V5();
					
			//2nd; 	the 1st 3 -> podium finish
					cout<<endl
						<<cD.menu_color2<<"Congratulation to the podium finishers!"<<RSTA<<"\n"<<endl;
					int counter = 1;
					
					//if 3 or more player
					if(mPpersonOnList >= 3){
						for(mP_i = 0; mP_i < 3; mP_i++){
						cout<<cD.equation_color1<<counter<<RSTA<<". ";
						mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();
						counter++;}
						}
					if(mPpersonOnList < 3){
						for(mP_i = 0; mP_i < mPpersonOnList; mP_i++){
						cout<<cD.equation_color1<<counter<<RSTA<<". ";
						mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();
						counter++;}
						}
					
					fflush(stdin);
					cout<<endl;
					cout<<cD.menu_color2<<"Press \33[1mENTER\33[0m once you finished admiring eachothers performance..."<<RSTA<<endl;
					cin.get();
				}
					//========================================UPDATE LB=============================
					
					//update LeaderBoard entries:
					for(auto& obj : mPlayersVector){
						
						if(obj.mP_totalScoreInThisSession_displayFn_V5()> leaderList_V5.back().display_lB_scoreFn_V5()){
							//update
							update_leaderboard_all_in_one(
									obj.mP_name_displayFn_V5(), //name
									cDate_returnFn_V5(), //date
									obj.mP_total_thinkingTime_displayFn_V5(), // total time to answer
									obj.mP_Level_InClass_displayFn_V5(),
									obj.mP_totalScoreInThisSession_displayFn_V5()); // score
											//missing played level
							//resort lb
								sort(leaderList_V5.begin(),leaderList_V5.end(),sortByDescendingScore_LeaderBoardListFn_V5);
								//add to sorting fn: if score same... put less time aquired 1st
						}
						
					}
					
					//------------------------------------------------------------------------------
					//save records to file -> LeaderBoard
					lB_saveFNfor_leaderBoardClass_V5(saveFileName_LB_V5, leaderList_V5); // include "saveFilename_LB_V5" & leaderList objectVector
					
					//test line
					//cout<<"update & save done... #2 - if only one left"<<endl;
					
				//exit to Mplayer menu...
				mP_while_playingGame_V5 = false;
				break;
				}
			//----------------------------------------------------------------------------------------------------------------	
			
			//if no one made it...
			if(count_mPplayers_with_lifes == 0) {
				
					system("clear");
					mP_noneMadeIt_Message_displayFn_V5();
					system("clear");
					cout<<endl
						<<cD.menu_color1<<"(Only "<<cD.menu_color2<<rounds
						<<cD.menu_color1<<" rounds done out of "<<cD.menu_color2<<round_buffer
						<<cD.menu_color1<<")\n"<<RSTA<<endl;
					cout<<cD.keret_color<<"Let's see who scored the most..."<<RSTA<<endl;
					//1st; Invoke sorting Fn ... then run the display Fn
					sort(mPlayersVector.begin(),mPlayersVector.end(),sortByHighestScore_andQuickestTime_ifScoreIs_same_MplayerFn_V5);
					
					//Victory message
					//mP_victoryMessage_displayFn_V5(mPlayersVector[0]);
					//system("clear");
					//mPlayersVector[0].mP_statisticsDisplayFn_V5();
					if(mPlayersVector[0].mP_totalScoreInThisSession_displayFn_V5() == 0){
						system("clear");
						cout<<"\n\n\n\nWell, well, well.... Try harder next time! Shall we? :)\n"<<endl;
						sleep(3);
						system("clear");
					}
					else{
					//2nd; 	the 1st 3 -> podium finish
					cout<<endl
						<<cD.menu_color2<<"Congratulation to the podium finishers!"<<RSTA<<"\n"<<endl;
					int counter = 1;
					
					//if 3 or more player
					if(mPpersonOnList >= 3){
						for(mP_i = 0; mP_i < 3; mP_i++){
						cout<<cD.equation_color1<<counter<<RSTA<<". ";
						mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();
						counter++;}
						}
					if(mPpersonOnList < 3){
						for(mP_i = 0; mP_i < mPpersonOnList; mP_i++){
						cout<<cD.equation_color1<<counter<<RSTA<<". ";
						mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();
						counter++;}
						}
						
					fflush(stdin);	
					cout<<endl;
					cout<<cD.menu_color2<<"Press \33[1mENTER\33[0m once you finished admiring eachothers performance..."<<RSTA<<endl;
					cin.get();
					system("clear");
				}
					//========================================UPDATE LB=============================
					
					//update LeaderBoard entries:
					for(auto& obj : mPlayersVector){
						
						if(obj.mP_totalScoreInThisSession_displayFn_V5()> leaderList_V5.back().display_lB_scoreFn_V5()){
							//update
							update_leaderboard_all_in_one(
									obj.mP_name_displayFn_V5(), //name
									cDate_returnFn_V5(), //date
									obj.mP_total_thinkingTime_displayFn_V5(), // total time to answer
									obj.mP_Level_InClass_displayFn_V5(),
									obj.mP_totalScoreInThisSession_displayFn_V5()); // score
											
							//resort lb
								sort(leaderList_V5.begin(),leaderList_V5.end(),sortByDescendingScore_LeaderBoardListFn_V5);
								//add to sorting fn: if score same... put less time aquired 1st
						}
						
					}
					
					//------------------------------------------------------------------------------
					//save records to file -> LeaderBoard
					lB_saveFNfor_leaderBoardClass_V5(saveFileName_LB_V5, leaderList_V5); // include "saveFilename_LB_V5" & leaderList objectVector
					
					//test line
					//cout<<"update & save done... #3 - if noone made it"<<endl;
					
					break;
					}
			 //---------------------------------------------------------
			 //if auto-round was on, and you decided to quit/exit before set rounds reached or
			 // you set unlimited rounds to start with....
			 if(mp_unlimitedLoopExit){
				 
				 cout<<"\n"<<cD.menu_color1<<"Rounds complated: "<<cD.menu_color2<<rounds -1<<RSTA<<endl;
				 cout<<cD.menu_color1<<"Now, let's see the results...\n"<<endl;
																
					//1st; Invoke sorting Fn ... then run the display Fn
					sort(mPlayersVector.begin(),mPlayersVector.end(),sortByHighestScore_andQuickestTime_ifScoreIs_same_MplayerFn_V5);
					
					if(mPlayersVector[0].mP_totalScoreInThisSession_displayFn_V5() == 0){
						system("clear");
						cout<<"\n\n\n\nWell, well, well.... Try harder next time! Shall we? :)\n"<<endl;
						sleep(3);
						system("clear");
					}
					else{
					//victory message
								mP_victoryMessage_displayFn_V5(	mPlayersVector[0] );
								system("clear");
								cout<<endl;
								mPlayersVector[0].mP_statisticsDisplayFn_V5();

					
					//2nd; 	the 1st 3 -> podium finish
					cout<<cD.menu_color2<<"Congratulation to the podium finishers!"<<RSTA<<"\n"<<endl;
					int counter = 1;
					
					//if 3 or more player
					if(mPpersonOnList >= 3){
						for(mP_i = 0; mP_i < 3; mP_i++){
						cout<<cD.equation_color1<<counter<<RSTA<<". ";
						mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();
						counter++;}
						}
					if(mPpersonOnList < 3){
						for(mP_i = 0; mP_i < mPpersonOnList; mP_i++){
						cout<<cD.equation_color1<<counter<<RSTA<<". ";
						mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();
						counter++;}
						}
					cout<<endl;
					cout<<cD.menu_color2<<"Press \33[1mENTER\33[0m once you finished admiring eachothers performance..."<<RSTA<<endl;
					cin.get();
					}
					//========================================UPDATE LB=============================
					
					//update LeaderBoard entries:
					for(auto& obj : mPlayersVector){
						
						if(obj.mP_totalScoreInThisSession_displayFn_V5()> leaderList_V5.back().display_lB_scoreFn_V5()){
							//update
							update_leaderboard_all_in_one(
									obj.mP_name_displayFn_V5(), //name
									cDate_returnFn_V5(), //date
									obj.mP_total_thinkingTime_displayFn_V5(), // total time to answer
									obj.mP_Level_InClass_displayFn_V5(),
									obj.mP_totalScoreInThisSession_displayFn_V5()); // score
											//missing played level
							//resort lb
								sort(leaderList_V5.begin(),leaderList_V5.end(),sortByDescendingScore_LeaderBoardListFn_V5);
								//add to sorting fn: if score same... put less time aquired 1st
						}
						
					
					}
					
					//------------------------------------------------------------------------------
					//save records to file -> LeaderBoard
					lB_saveFNfor_leaderBoardClass_V5(saveFileName_LB_V5, leaderList_V5); // include "saveFilename_LB_V5" & leaderList objectVector
					
					//test line
					//cout<<"update & save done... #1"<<endl;
					fflush(stdin);
					
					mP_while_playingGame_V5 = false;
						
					break;	
					
					}
			 //---------------------------------------------------------
			 
			 else{
				  
					
					//if targeted rounds are complated and still players with life
					// display Victory and Highest score Player as winner, 2nd 3rd too
					// Apply the sorting algorithm here.... (mini leaderboard end of game)
					if(round_buffer > 0 && rounds >= round_buffer && count_mPplayers_with_lifes > 1){
						
					cout<<"\n"<<cD.menu_color1<<"Targeted round complated. Now, let's see the results...\n"<<endl;
																
					//1st; Invoke sorting Fn ... then run the display Fn
					sort(mPlayersVector.begin(),mPlayersVector.end(),sortByHighestScore_andQuickestTime_ifScoreIs_same_MplayerFn_V5);
					
					if(mPlayersVector[0].mP_totalScoreInThisSession_displayFn_V5() == 0){
						system("clear");
						cout<<"\n\n\n\nWell, well, well.... Try harder next time! Shall we? :)\n"<<endl;
						sleep(3);
						system("clear");
					}
					else{
					//victory message
								mP_victoryMessage_displayFn_V5(	mPlayersVector[0] );
								system("clear");
								cout<<endl;
								mPlayersVector[0].mP_statisticsDisplayFn_V5();

					
					//2nd; 	the 1st 3 -> podium finish
					cout<<cD.menu_color2<<"Congratulation to the podium finishers!"<<RSTA<<"\n"<<endl;
					int counter = 1;
					
					//if 3 or more player
					if(mPpersonOnList >= 3){
						for(mP_i = 0; mP_i < 3; mP_i++){
						cout<<cD.equation_color1<<counter<<RSTA<<". ";
						mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();
						counter++;}
						}
					if(mPpersonOnList < 3){
						for(mP_i = 0; mP_i < mPpersonOnList; mP_i++){
						cout<<cD.equation_color1<<counter<<RSTA<<". ";
						mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();
						counter++;}
						}
					cout<<endl;	
					cout<<cD.menu_color2<<"Press \33[1mENTER\33[0m once you finished admiring eachothers performance..."<<RSTA<<endl;
					cin.get();
					}
					//========================================UPDATE LB=============================
					
					//update LeaderBoard entries:
					for(auto& obj : mPlayersVector){
						
						if(obj.mP_totalScoreInThisSession_displayFn_V5()> leaderList_V5.back().display_lB_scoreFn_V5()){
							//update
							update_leaderboard_all_in_one(
									obj.mP_name_displayFn_V5(), //name
									cDate_returnFn_V5(), //date
									obj.mP_total_thinkingTime_displayFn_V5(), // total time to answer
									obj.mP_Level_InClass_displayFn_V5(),
									obj.mP_totalScoreInThisSession_displayFn_V5()); // score
											//missing played level
							//resort lb
								sort(leaderList_V5.begin(),leaderList_V5.end(),sortByDescendingScore_LeaderBoardListFn_V5);
								//add to sorting fn: if score same... put less time aquired 1st
						}
						
					}
					
					//------------------------------------------------------------------------------
					//save records to file -> LeaderBoard
					lB_saveFNfor_leaderBoardClass_V5(saveFileName_LB_V5, leaderList_V5); // include "saveFilename_LB_V5" & leaderList objectVector
					
					//test line
					//cout<<"update & save done... #1"<<endl;
					fflush(stdin);
					cout<<endl;
					
					mP_while_playingGame_V5 = false;
						
					break;	
					
					}
							
				}
				//END of Evaluation
				//----------------------------------------------------------------------------------
				
					//Next round or Exit...
							
					system("clear");
					cout<<endl;
					cout<<endl;
					cout<<endl;
					cout<<endl;
					cout<<endl;
					cout<<endl; // space = 15 on front
					
					cout<<"           "<<cD.keret_color<<"***********************************************************"<<RSTA<<"\n"
						<<"           "<<cD.keret_color<<"*"<<RSTA<<"   "<<cD.menu_color1<<"Exit from game via entering"<<RSTA<<" \'"<<cD.menu_color2<<"q"<<RSTA<<"\' "<<cD.menu_color1<<"or"<<RSTA<<" \'"<<cD.menu_color2<<"Q"<<RSTA<<"\' "<<cD.menu_color1<<"at the end of  "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"           "<<cD.keret_color<<"*"<<RSTA<<"     "<<cD.menu_color1<<"the round "<<cD.menu_color2<<"or"<<cD.menu_color1<<" by complating the targeted rounds.     "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"           "<<cD.keret_color<<"***********************************************************"<<RSTA<<"\n\n"<<endl;
					
					if(round_buffer == 0){cout<<"               "<<cD.menu_color1<<"Round"<<RSTA<<" -"<<cD.menu_color2<<rounds<<RSTA"- "<<cD.menu_color1<<"Done."<<RSTA<<"\n";}
					else{cout<<"               "<<cD.menu_color1<<"Round"<<RSTA<<" "<<cD.menu_color2<<rounds<<RSTA"/"<<cD.menu_color2<<round_buffer<<RSTA<<" "<<cD.menu_color1<<"Done."<<RSTA<<"\n";}
					
						//auto-round
						
						if(mp_auto_round){
							if(mp_unlimitedLoopExit){break;}
							for(int i = 3; i>0;i--){
							system("clear");
							cout<<endl;
							cout<<"\n\n\n"<<endl;
							cout<<"                    "<<cD.keret_color<<"*** N E X T    R O U N D ***"<<RSTA"\n"<<endl;
							
							cout<<"                                "<<BRIGHT<<i<<RSTA;
							fflush(stdout);
							sleep(1);
							}
							//update vars
							rounds = rounds +1;
							continue;
							system("clear");}
						
					
					cout<<"\n"
						<<"           "<<cD.keret_color<<"======================================"<<RSTA<<"\n"
						<<"           "<<cD.keret_color<<"|"<<RSTA<<"  "<<cD.menu_color1<<"Press"<<RSTA<<" ("<<cD.yes_color<<"N"<<RSTA<<") "<<cD.menu_color1<<"to start \33[1;32mNEXT\33[0m"<<cD.menu_color1<<" round..."<<RSTA<<"  "<<cD.keret_color<<"|"<<RSTA<<"\n"
						<<"           "<<cD.keret_color<<"|"<<RSTA<<"  "<<cD.menu_color1<<"Press"<<RSTA<<" ("<<cD.back_color<<"Q"<<RSTA<<") "<<cD.menu_color1<<"to \33[1;31mSTOP\33[0m"<<cD.menu_color1<<" and exit..."<<RSTA<<"     "<<cD.keret_color<<"|"<<RSTA<<"\n"
						<<"           "<<cD.keret_color<<"======================================"<<RSTA<<"\n"
						<<endl;
					
					char w;
					if(mp_auto_round && mp_unlimitedLoopExit){w = 'q';}
					while(!(cin>>w)){
						if(mp_auto_round && mp_unlimitedLoopExit){
							w = 'q';
							}
					
					if(w !='n' || w != 'N' || w!='q' || w!='Q'){
						cout<<cD.itsnotanumber_color<<"Sorry! What?..."<<RSTA<<endl;
						cout<<cD.tryagain_color<<"Try again!"<<RSTA<<endl;
						cin>>w;
						continue;}
					else{break;}
						}
						
					
				//-----------------------------------------------------
						
				if(w == 'q' || w=='Q'){
					mP_while_playingGame_V5 = false;
					//inMultiPlayerModeShell_V5 = false;
					if(rounds >= round_buffer && count_mPplayers_with_lifes > 1){
					system("clear");
					cout<<cD.menu_color1<<"Let's see who scored more this time...!"<<RSTA<<"\n"<<endl;
					//1st; Invoke sorting Fn ... then run the display Fn
					sort(mPlayersVector.begin(),mPlayersVector.end(),sortByHighestScore_andQuickestTime_ifScoreIs_same_MplayerFn_V5);
					//compair for tie
					if_tie_bool = false;
					for(mP_i = 0;mP_i < mPpersonOnList; mP_i++){
						if(mPlayersVector[mP_i].mP_totalScoreInThisSession_displayFn_V5() == mPlayersVector[mP_i + 1].mP_totalScoreInThisSession_displayFn_V5())
						{
							cout<<"That's a tie between "<<mPlayersVector[mP_i].mP_name_displayFn_V5()
								<<" and "<<mPlayersVector[mP_i + 1].mP_name_displayFn_V5()<<endl;
							cout<<"Let's see who spent less time to think on the answers....\n";
							cout<<mPlayersVector[mP_i].mP_name_displayFn_V5()
								<<" your total thinking time was: "
								<<mPlayersVector[mP_i].mP_total_thinkingTime_displayFn_V5()
								<<"second.\n";
							// if total thinking time is less that person is the winner in case of tie
							if(mPlayersVector[0].mP_total_thinkingTime_displayFn_V5() < mPlayersVector[1].mP_total_thinkingTime_displayFn_V5()){
									cout<<"The WINNER is: "<<mPlayersVector[0].mP_name_displayFn_V5()<<"\n"
										<<"with "<<BRIGHT<<mPlayersVector[0].mP_totalScoreInThisSession_displayFn_V5()<<RSTA
										<<" total score and "
										<<BRIGHT<<mPlayersVector[0].mP_total_thinkingTime_displayFn_V5()<<RSTA
										<<"s of total thinking time.\n"
										<<"WELL DONE "<<cD.menu_color1<<mPlayersVector[0].mP_name_displayFn_V5()<<RSTA<<"\n"<<endl;}
										
							else{cout<<"The WINNER is: "<<BRIGHT<<mPlayersVector[1].mP_name_displayFn_V5()<<RSTA<<"\n"
										<<"with "<<BRIGHT<<mPlayersVector[1].mP_totalScoreInThisSession_displayFn_V5()<<RSTA
										<<" total score and "
										<<BRIGHT<<mPlayersVector[1].mP_total_thinkingTime_displayFn_V5()<<RSTA
										<<"s of total thinking time.\n"
										<<"WELL DONE "<<cD.menu_color1<<mPlayersVector[1].mP_name_displayFn_V5()<<"\n"<<endl;}
								if_tie_bool = true;
						}
					}
					if(if_tie_bool == false){
					cout<<"\n          "<<cD.equattionText_color<<mPlayersVector[0].mP_name_displayFn_V5()<<RSTA<<"\n"
						<<cD.menu_color2<<"           ...you are the WINNER with "<<cD.equation_color1
						<<mPlayersVector[0].mP_totalScoreInThisSession_displayFn_V5()
						<<cD.menu_color2<<" score!"<<RSTA<<"\n"
						<<"Total thinking time: "<<BRIGHT<<mPlayersVector[0].mP_total_thinkingTime_displayFn_V5()<<RSTA<<"s\n"
						<<endl;
						}
					
					mP_victoryMessage_displayFn_V5(	mPlayersVector[0] );
								system("clear");
								cout<<endl;
								mPlayersVector[0].mP_statisticsDisplayFn_V5();
					
					//2nd; 	the 1st 3 -> podium finish
					cout<<cD.menu_color1<<"Congratulation to the podium finish for:"<<RSTA<<"\n"<<endl;
					int counter = 1;
					
					
					for(mP_i = 0; mP_i < 3; mP_i++){
						cout<<counter<<". ";
						//if tie -> get's the same number
						if(mPlayersVector[mP_i].mP_totalScoreInThisSession_displayFn_V5() == mPlayersVector[mP_i + 1].mP_totalScoreInThisSession_displayFn_V5() 
							// || mPlayersVector[mP_i - 1].mP_totalScoreInThisSession_displayFn_V5() == mPlayersVector[mP_i].mP_totalScoreInThisSession_displayFn_V5()
							){
							mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();}
						//else ++ counter
						else{mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();
						counter++;}
						}
					}
					
					
					else{
						system("clear");
					cout<<cD.menu_color1<<"Let's see who scored more this time...!"<<RSTA<<"\n"<<endl;
					//1st; Invoke sorting Fn ... then run the display Fn
					sort(mPlayersVector.begin(),mPlayersVector.end(),sortByHighestScore_andQuickestTime_ifScoreIs_same_MplayerFn_V5);
					//compair for tie
					for(mP_i = 0;mP_i < mPpersonOnList; mP_i++){
						if(mPlayersVector[mP_i].mP_totalScoreInThisSession_displayFn_V5() == mPlayersVector[mP_i + 1].mP_totalScoreInThisSession_displayFn_V5()){
							cout<<"That's a tie between "<<mPlayersVector[mP_i].mP_name_displayFn_V5()
								<<" and "<<mPlayersVector[mP_i + 1].mP_name_displayFn_V5()<<endl;}
						}
					
					cout<<"\n"<<cD.equattionText_color<<mPlayersVector[0].mP_name_displayFn_V5()<<cD.menu_color2<<" you are the WINNER with "<<cD.equation_color1<<mPlayersVector[0].mP_totalScoreInThisSession_displayFn_V5()<<cD.menu_color2<<" score!"<<RSTA<<"\n"<<endl;
					
					//Winners statistic
					mP_victoryMessage_displayFn_V5(	mPlayersVector[0] );
								system("clear");
								cout<<endl;
								mPlayersVector[0].mP_statisticsDisplayFn_V5();
					
					//2nd; 	the 1st 3 -> podium finish
					cout<<cD.menu_color1<<"Congratulation to the podium finishers:"<<RSTA<<"\n"<<endl;
					int counter = 1;
					if(mPpersonOnList < 3){
						for(mP_i = 0; mP_i < mPpersonOnList - 1; mP_i++){
						cout<<counter<<". ";
						//if tie -> get's the same number
						if(mPlayersVector[mP_i].mP_totalScoreInThisSession_displayFn_V5() == mPlayersVector[mP_i + 1].mP_totalScoreInThisSession_displayFn_V5() 
							// ||	mPlayersVector[mP_i - 1].mP_totalScoreInThisSession_displayFn_V5() == mPlayersVector[mP_i].mP_totalScoreInThisSession_displayFn_V5()
							){
							mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();}
						//else ++ counter
						else{mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();
						counter++;}
						}
					}
					else{for(mP_i = 0; mP_i < 3; mP_i++){
						cout<<counter<<". ";
						//if tie -> get's the same number
						if(mPlayersVector[mP_i].mP_totalScoreInThisSession_displayFn_V5() == mPlayersVector[mP_i + 1].mP_totalScoreInThisSession_displayFn_V5() 
							//	||	mPlayersVector[mP_i - 1].mP_totalScoreInThisSession_displayFn_V5() == mPlayersVector[mP_i].mP_totalScoreInThisSession_displayFn_V5()
							){
							mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();}
						//else ++ counter
						else{mPlayersVector[mP_i].mP_displayName_andScoreFn_V5();
						counter++;}
						}
					}
					//==============================================================================
					//========================================UPDATE LB=============================
					
					//update LeaderBoard entries:
					for(auto& obj : mPlayersVector){
						
						if(obj.mP_totalScoreInThisSession_displayFn_V5()> leaderList_V5.back().display_lB_scoreFn_V5()){
							//update
							update_leaderboard_all_in_one(
									obj.mP_name_displayFn_V5(), //name
									cDate_returnFn_V5(), //date
									obj.mP_total_thinkingTime_displayFn_V5(), // total time to answer
									obj.mP_Level_InClass_displayFn_V5(),
									obj.mP_totalScoreInThisSession_displayFn_V5()); // score
											//missing played level
							//resort lb
								sort(leaderList_V5.begin(),leaderList_V5.end(),sortByDescendingScore_LeaderBoardListFn_V5);
								//add to sorting fn: if score same... put less time aquired 1st
						}
						
					}
					
					//------------------------------------------------------------------------------
					//save records to file -> LeaderBoard
					lB_saveFNfor_leaderBoardClass_V5(saveFileName_LB_V5, leaderList_V5); // include "saveFilename_LB_V5" & leaderList objectVector
					
					//test line
					//cout<<"update & save done... #2"<<endl;
					
					//===============================================================================
					//===============================================================================
					
				}
					
					cout<<endl;
					cout<<cD.menu_color2<<"Press \33[1mENTER\33[0m once you finished admiring eachothers performance..."<<RSTA<<endl;
					
					cin.get();
					//cin.get();
					
					break;
					
				}
					
				// Next round...		
				if(w == 'n' || w=='N'){ 
					//update vars
					rounds = rounds +1;
					//round_buffer--;
					continue;
					}	// Keep playing
		
			
			} // End mP_while_playingGame_V5
				
		break; //case 1 (game play)
	
	//==============================================================================================

		case 2:	//M player Options menu
			
			system("clear");
			in_mP_option_menu = true;
		
			while(in_mP_option_menu){
			
			system("clear");
			cout<<"\n"
				<<"\n"<<endl;
			cout<<"                   "<<FREDBOLD<<"M"
					<<FBLUEBOLD<<"U"
					<<FGREENBOLD<<"L"
					<<FWHITEBOLD<<"T"
					<<FMAGENTABOLD<<"I"
					<<FYELLOWBOLD<<"P"
					<<FREDBOLD<<"L"
					<<FWHITEBOLD<<"A"
					<<FGREENBOLD<<"Y"
					<<FBLUEBOLD<<"E"
					<<FCAYENBOLD<<"R"<<RSTA<<cD.menu_color1<<" OPTIONS menu"<<RSTA<<"\n"
				<<"          "<<cD.keret_color<<"============================================="<<RSTA<<"\n"
				<<"          "<<cD.keret_color<<"*"<<RSTA<<"                                           "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"          "<<cD.keret_color<<"*"<<RSTA<<"         ("<<cD.menu_color2<<"1"<<RSTA<<") - "<<cD.menu_color1<<"Difficulty levels"<<RSTA<<"           "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"          "<<cD.keret_color<<"*"<<RSTA<<"         ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color1<<"Colour schemes"<<RSTA<<"              "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"          "<<cD.keret_color<<"*"<<RSTA<<"         ("<<cD.menu_color2<<"3"<<RSTA<<") - "<<cD.menu_color1<<"Auto turn";
		if(!mp_auto_turn){cout<<RSTA<<" ON/\33[1;31mOFF\33[0m";}
		if(mp_auto_turn){cout<<RSTA<<" \33[1;32mNO\33[0m/OFF";}
		cout<<RSTA<<"            "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"          "<<cD.keret_color<<"*"<<RSTA<<"         ("<<cD.menu_color2<<"4"<<RSTA<<") - "<<cD.menu_color1<<"Auto round";
		if(!mp_auto_round){cout<<RSTA<<" ON/\33[1;31mOFF\33[0m";}
		if(mp_auto_round){cout<<RSTA<<" \33[1;32mNO\33[0m/OFF";}
		cout<<RSTA<<"           "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"          "<<cD.keret_color<<"*"<<RSTA<<"         ("<<cD.menu_color2<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                        "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"          "<<cD.keret_color<<"*"<<RSTA<<"                                           "<<cD.keret_color<<"*"<<RSTA<<"\n"
				<<"          "<<cD.keret_color<<"============================================="<<RSTA<<"\n"
				<<endl;
			
			
			cout<<"     "<<cD.menu_color1<<"Enter the selected menu point:"<<RSTA<<" ";
		while(!(cin>>optionsMenupointSelected))
		{
		
			if(!optionsMenupointSelected)//if not valid Menu Option entered:
			
				{//I need to play a sound if Incorrect! (no message)
				//also delete the wrong answer from screen or
				//tell that is not the correct answer.
        cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
            
            fflush(stdin);
        
		cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout<<"			     ";
        continue;
			}
		
			if(optionsMenupointSelected < 0 || optionsMenupointSelected > 4) 
			{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
				 <<endl; continue;}
			else {break;} 
		}
		//--------------------------------------------------------------
		// Activate optionMenupointSelected Switchboard:
		
		switch (optionsMenupointSelected){
			
			case 0:
				
				in_mP_option_menu = false;
			system("clear");
				//Might need to reset, update, save some data here befor we go back...
				break;
				
			//----------------------------------------------------------
			case 3: //auto turn
				char aT_choice;
				
				if(!mp_auto_turn){
				cout<<"\n"
					<<"    Would you like to turn \33[1;32mON\33[0m \"auto-turn\"?\n"
					<<"    It will initiatate a 3 sec countdown\n"
					<<"    before the next player's turn.\n"
					<<"    Then automatically loads the next player's turn. \n"
					<<"    Please enter (\33[1;32mY\33[0m) for YES or (\33[1;31mN\33[0m) for NO ... ";
				
					cin>>aT_choice;
					if(aT_choice == 'Y' || aT_choice == 'y'){mp_auto_turn = true;}
					if(aT_choice == 'N' || aT_choice == 'n'){mp_auto_turn = false;}
					}
					
				else if(mp_auto_turn){
				cout<<"\n"
					<<"    Would you like to turn \33[1;31mOFF\33[0m \"auto-turn\"?\n"
					<<"    Please enter (\33[1;32mY\33[0m) for YES or (\33[1;31mN\33[0m) for NO ... ";
					
					cin>>aT_choice;
					if(aT_choice == 'Y' || aT_choice == 'y'){mp_auto_turn = false;}
					if(aT_choice == 'N' || aT_choice == 'n'){mp_auto_turn = true;}
					}	
				
				else{
					cout<<"\n    Please select Yes (\33[1;32mY\33[0m) or No (\33[1;31mN\33[0m)...\n"<<endl;
					sleep(3);
					continue;}
				
				fflush(stdin);
				fflush(stdout);
	
					sleep(1);
					system("clear");
			
				break;
			//----------------------------------------------------------
			case 4: //auto round
			
					char aTr_choice;
				
				if(!mp_auto_round){
				cout<<"\n"
					<<"    Would you like to turn \33[1;32mON\33[0m \"auto-round\"?\n"
					<<"    It will initiatate a 3 sec countdown\n"
					<<"    before the next round.\n"
					<<"    Then automatically starts the next round. \n"
					<<"    Please enter (\33[1;32mY\33[0m) for YES or (\33[1;31mN\33[0m) for NO ... ";
				
					cin>>aTr_choice;
					if(aTr_choice == 'Y' || aTr_choice == 'y'){mp_auto_round = true;}
					if(aTr_choice == 'N' || aTr_choice == 'n'){mp_auto_round = false;}
					}
					
				else if(mp_auto_round){
				cout<<"\n"
					<<"    Would you like to turn \33[1;31mOFF\33[0m \"auto-round\"?\n"
					<<"    Please enter (\33[1;32mY\33[0m) for YES or (\33[1;31mN\33[0m) for NO ... ";
					
					cin>>aT_choice;
					if(aTr_choice == 'Y' || aTr_choice == 'y'){mp_auto_round = false;}
					if(aTr_choice == 'N' || aTr_choice == 'n'){mp_auto_round = true;}
					}	
				
				else{
					cout<<"\n    Please select Yes (\33[1;32mY\33[0m) or No (\33[1;31mN\33[0m)...\n"<<endl;
					sleep(3);
					continue;}
				
				fflush(stdin);
				fflush(stdout);
	
					sleep(1);
					system("clear");
			
				break;
			
			//----------------------------------------------------------
			case 2: // Colour Thames
			
				inColourMenu = true;
			
				while(inColourMenu){
					
				system("clear");
				// Name colour Thames and invoke changing fn(ColourThemeName) by changing the existing
				// "Namecodes"  of colours to the choosen ones...
				//defOrange = "\033[;31;40m";
				cout<<""<<endl;
				cout<<"              ============================\n"
					<<"              |   (1) - "<<FYELLOW<<"Default theme"<<RSTA<<"    |\n"
					<<"              |   (2) - "<<"\033[1;32m"<<"Spring theme"<<RSTA<<"     |\n"
					<<"              |   (3) - "<<"\033[1;31m"<<"Summer theme"<<RSTA<<"     |\n"
					<<"              |   (4) - "<<"\033[1;33m"<<"Autumn theme"<<RSTA<<"     |\n"
					<<"              |   (5) - "<<BRIGHT<<"Winter theme"<<RSTA<<"     |\n"
					<<"              |   (0) - "<<FWHITE_BDARK<<"BACK"<<RSTA<<"             |\n"
					<<"              ============================\n"
					<<"             ( Current theme: "<<colorThemeDisplayInfo_current<<" )\n"
					<<endl;
					
					cout<<"Please select a colour theme of your liking!\n"
					<<endl;
					while(!(cin>>selectedColourTheme))
		{
		
			if(!selectedColourTheme)//if not valid Menu Option entered:
			
				{//I need to play a sound if Incorrect! (no message)
				//also delete the wrong answer from screen or
				//tell that is not the correct answer.
        cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
            
            fflush(stdin);
        
		cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
		cout<<"			     ";
        continue;
			}
		
			if(selectedColourTheme < 0 || selectedColourTheme > 5) 
			{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
				 <<endl; continue;}
			else {break;} 
		}
		//--------------------------------------------------------------
		//Switchboard your choice:
		switch (selectedColourTheme){
			
			case 0: //BACK
				
				 inColourMenu = false;
			system("clear");
				//Might need to reset, update, save some data here befor we go back...
				break;
				//-----------------------------------------------
			case 1: // DEFAULT
				if(selectedColourTheme == 1){
					
					system("clear");
					
					inWintercolorMenu = true;
					
					while(inWintercolorMenu){
					cout<<"\n"<<endl;	
					cout<<RSTA<<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color1<<"Enter"<<RSTA<<" ("<<cD.menu_color1<<"1"<<RSTA<<") - "<<cD.menu_color1<<"to Preview colour theme"<<RSTA<<" "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color2<<"Enter"<<RSTA<<" ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color2<<"to Apply colour theme"<<RSTA<<"   "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.back_color<<"Enter"<<RSTA<<" ("<<cD.back_color<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                    "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<endl;
					
					int colorMenuChoice;
					while(!(cin>>colorMenuChoice)){
				
					if(!colorMenuChoice)//if not valid Menu Option entered:
						{
						//also delete the wrong answer from screen or
						//tell that is not the correct answer.
						cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
					
						fflush(stdin);
						
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
						cout<<"			     ";
						continue;
							}
				
					if(colorMenuChoice < 0 || colorMenuChoice > 2) 
					{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
						 <<endl; continue;}
						 
					else {break;}
				}
			//-------------------------------------------------------------------------------
					
					if(colorMenuChoice == 0) {
						//back
						system("clear");
						inWintercolorMenu = false;
						break;}
						
					if(colorMenuChoice == 1){
						//preview color theme
						system("clear");
						colorDefault.default_colorsFn();
							cout<<"Default:"<<endl;
							
							//preview fn
							mPlayerColor_previewFn();
							
							//Set colourThemeFn()
							//Ask user Do you want to set this colour theme?
							cout<<"Press \33[1mENTER\33[0m if you've done here..."<<endl;
							cin.get();
							cin.get();
							system("clear");
							colorDefault.default_colorsFn();
					}	// end preview if
					
				if(colorMenuChoice == 2){
					// Apply your choice
					system("clear");
					
					colorDefault.default_colorsFn();
					cD.default_colorsFn();
					set_mPlayer_colorTheme = 0;
					colorThemeDisplayInfo_current = "\33[33mDEFAULT theme\33[0m";
					
					cout<<"\n\n\n\n\n\n\n\n\n\n\n"<<endl;
					cout<<setw(25)<<BRIGHT<<"That's all done for you "<<RSTA<<endl;
						
					inWintercolorMenu = false;
					sleep(2);
					}
				}
			}
				break;
				//-------------------------------------------------------
			case 2: // SPRING
				if(selectedColourTheme == 2){
					
					
					system("clear");
					
					inWintercolorMenu = true;
					
					while(inWintercolorMenu){
					cout<<"\n"<<endl;	
					cout<<RSTA<<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color1<<"Enter"<<RSTA<<" ("<<cD.menu_color1<<"1"<<RSTA<<") - "<<cD.menu_color1<<"to Preview colour theme"<<RSTA<<" "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color2<<"Enter"<<RSTA<<" ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color2<<"to Apply colour theme"<<RSTA<<"   "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.back_color<<"Enter"<<RSTA<<" ("<<cD.back_color<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                    "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<endl;
							  
					
					
					int colorMenuChoice;
					while(!(cin>>colorMenuChoice)){
				
					if(!colorMenuChoice)//if not valid Menu Option entered:
						{
						//also delete the wrong answer from screen or
						//tell that is not the correct answer.
						cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
					
						fflush(stdin);
						
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
						cout<<"			     ";
						continue;
							}
				
					if(colorMenuChoice < 0 || colorMenuChoice > 2) 
					{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
						 <<endl; continue;}
						 
					else {break;}
				}
			//-------------------------------------------------------------------------------
					
					if(colorMenuChoice == 0) {
						//back
						system("clear");
						inWintercolorMenu = false;
						break;}
						
					if(colorMenuChoice == 1){
						//preview color theme
						system("clear");
						colorDefault.spring_colorsFn();
							cout<<"Spring:"<<endl;
							
							//preview Fn
							mPlayerColor_previewFn();
							
							//Set colourThemeFn()
							//Ask user Do you want to set this colour theme?
							cout<<"Press \33[1mENTER\33[0m if you've done here..."<<endl;
							cin.get();
							cin.get();
							system("clear");
							colorDefault.default_colorsFn();
					}	// end preview if
					
				if(colorMenuChoice == 2){
					// Apply your choice
					system("clear");
					
					
						cD.spring_colorsFn();
						set_mPlayer_colorTheme = 1;
					colorThemeDisplayInfo_current = "\33[1;32mSPRING theme\33[0m";
					
					cout<<"\n\n\n\n\n\n\n\n\n\n\n"<<endl;
					cout<<setw(25)<<BRIGHT<<"That's all done for you "<<RSTA<<endl;
						
					inWintercolorMenu = false;
					sleep(2);	
					}
					
					//colorDefault.spring_colorsFn();
					
					
					}
				}
			
				break;
				//------------------------------------------------------
				case 3: // SUMMER
				if(selectedColourTheme == 3){
					
				system("clear");
					
					inWintercolorMenu = true;
					
					while(inWintercolorMenu){
					cout<<"\n"<<endl;	
					cout<<RSTA<<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color1<<"Enter"<<RSTA<<" ("<<cD.menu_color1<<"1"<<RSTA<<") - "<<cD.menu_color1<<"to Preview colour theme"<<RSTA<<" "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color2<<"Enter"<<RSTA<<" ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color2<<"to Apply colour theme"<<RSTA<<"   "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.back_color<<"Enter"<<RSTA<<" ("<<cD.back_color<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                    "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<endl;
					
					int colorMenuChoice;
					while(!(cin>>colorMenuChoice)){
				
					if(!colorMenuChoice)//if not valid Menu Option entered:
						{
						//also delete the wrong answer from screen or
						//tell that is not the correct answer.
						cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
					
						fflush(stdin);
						
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
						cout<<"			     ";
						continue;
							}
				
					if(colorMenuChoice < 0 || colorMenuChoice > 2) 
					{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
						 <<endl; continue;}
						 
					else {break;}
				}
			//-------------------------------------------------------------------------------
					
					if(colorMenuChoice == 0) {
						//back
						system("clear");
						inWintercolorMenu = false;
						break;}
						
					if(colorMenuChoice == 1){
						//preview color theme
						system("clear");
						colorDefault.summer_colorsFn();
							cout<<"SUMMER:"<<endl;
						
						//preview fn
						mPlayerColor_previewFn();
						
							//Set colourThemeFn()
							//Ask user Do you want to set this colour theme?
							cout<<"Press \33[1mENTER\33[0m if you've done here..."<<endl;
							cin.get();
							cin.get();
							system("clear");
							colorDefault.default_colorsFn();
					}	// end preview if
					
				if(colorMenuChoice == 2){
					// Apply your choice
					system("clear");
					
					colorDefault.summer_colorsFn();
					set_mPlayer_colorTheme = 2;
					cD.summer_colorsFn();
					colorThemeDisplayInfo_current = "\33[1;31mSUMMER theme\33[0m";
					
					cout<<"\n\n\n\n\n\n\n\n\n\n\n"<<endl;
					cout<<setw(25)<<BRIGHT<<"That's all done for you "<<RSTA<<endl;
						
					inWintercolorMenu = false;
					sleep(2);
					}
				}
			}
				break;
				//---------------------------------------------------------
				case 4: // AUTUMN
				if(selectedColourTheme == 4){
					
				system("clear");
					
					inWintercolorMenu = true;
					
					while(inWintercolorMenu){
					cout<<"\n"<<endl;	
					cout<<RSTA<<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color1<<"Enter"<<RSTA<<" ("<<cD.menu_color1<<"1"<<RSTA<<") - "<<cD.menu_color1<<"to Preview colour theme"<<RSTA<<" "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color2<<"Enter"<<RSTA<<" ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color2<<"to Apply colour theme"<<RSTA<<"   "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.back_color<<"Enter"<<RSTA<<" ("<<cD.back_color<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                    "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<endl;
					
					int colorMenuChoice;
					while(!(cin>>colorMenuChoice)){
				
					if(!colorMenuChoice)//if not valid Menu Option entered:
						{
						//also delete the wrong answer from screen or
						//tell that is not the correct answer.
						cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
					
						fflush(stdin);
						
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
						cout<<"			     ";
						continue;
							}
				
					if(colorMenuChoice < 0 || colorMenuChoice > 2) 
					{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
						 <<endl; continue;}
						 
					else {break;}
				}
			//-------------------------------------------------------------------------------
					
					if(colorMenuChoice == 0) {
						//back
						system("clear");
						inWintercolorMenu = false;
						break;}
						
					if(colorMenuChoice == 1){
						//preview color theme
						system("clear");
						colorDefault.autumn_colorsFn();
							cout<<"AUTUMN:"<<endl;
							
							//preview fn
							mPlayerColor_previewFn();
							
							//Set colourThemeFn()
							//Ask user Do you want to set this colour theme?
							cout<<"Press \33[1mENTER\33[0m if you've done here..."<<endl;
							cin.get();
							cin.get();
							system("clear");
							colorDefault.default_colorsFn();
					}	// end preview if
					
				if(colorMenuChoice == 2){
					// Apply your choice
					system("clear");
					
					colorDefault.autumn_colorsFn();
					set_mPlayer_colorTheme = 3;
					cD.autumn_colorsFn();
					colorThemeDisplayInfo_current = "\033[1;33mAUTUMN theme\33[0m";
					
					cout<<"\n\n\n\n\n\n\n\n\n\n\n"<<endl;
					cout<<setw(25)<<BRIGHT<<"That's all done for you "<<RSTA<<endl;
						
					inWintercolorMenu = false;
					sleep(2);
					}
				}
			}
				break;
				//---------------------------------------------------------
				case 5: //WINTER
				if(selectedColourTheme == 5){
					
					system("clear");
					
					inWintercolorMenu = true;
					
					while(inWintercolorMenu){
					cout<<"\n"<<endl;	
					cout<<RSTA<<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color1<<"Enter"<<RSTA<<" ("<<cD.menu_color1<<"1"<<RSTA<<") - "<<cD.menu_color1<<"to Preview colour theme"<<RSTA<<" "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color2<<"Enter"<<RSTA<<" ("<<cD.menu_color2<<"2"<<RSTA<<") - "<<cD.menu_color2<<"to Apply colour theme"<<RSTA<<"   "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.back_color<<"Enter"<<RSTA<<" ("<<cD.back_color<<"0"<<RSTA<<") - "<<cD.back_color<<"BACK"<<RSTA<<"                    "<<cD.keret_color<<"|"<<RSTA<<"\n"
							  <<"     "<<cD.keret_color<<"|=====================================|"<<RSTA<<"\n"
							  <<endl;
					
					int colorMenuChoice;
					while(!(cin>>colorMenuChoice)){
				
					if(!colorMenuChoice)//if not valid Menu Option entered:
						{
						//also delete the wrong answer from screen or
						//tell that is not the correct answer.
						cout<<endl<<"	     "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.itsnotanumber_color<<"That isn't a NUMBER!"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
						<<"	     "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.keret_color<<"***"<<cD.tryagain_color<<"Please, try again!"<<cD.keret_color<<"***"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA"\n"
						<<"	     "<<cD.keret_color<<"**********************************"<<RSTA"\n"
						<<RSTA;
					
						fflush(stdin);
						
						cin.clear();
						cin.ignore(numeric_limits<streamsize>::max(), '\n');
						cout<<"			     ";
						continue;
							}
				
					if(colorMenuChoice < 0 || colorMenuChoice > 2) 
					{cout<<RSTA<<"	----	"<<cD.itsnotanumber_color<<"***"<<cD.tryagain_color<<"INVALID OPTION!"<<cD.itsnotanumber_color<<"***"<<RSTA<<"	----"
						 <<endl; continue;}
						 
					else {break;}
				}
			//-------------------------------------------------------------------------------
					
					if(colorMenuChoice == 0) {
						//back
						system("clear");
						inWintercolorMenu = false;
						break;}
						
					if(colorMenuChoice == 1){
						//preview color theme
						system("clear");
						colorDefault.winter_colorsFn();
							cout<<"Winter:"<<endl;
							
							//preview display
							mPlayerColor_previewFn();
							
							//Set colourThemeFn()
							//Ask user Do you want to set this colour theme?
							cout<<"Press \33[1mENTER\33[0m if you've done here..."<<endl;
							cin.get();
							cin.get();
							system("clear");
							colorDefault.default_colorsFn();
					}	// end preview if
					
				if(colorMenuChoice == 2){
					// Apply your choice
					system("clear");
					
					colorDefault.winter_colorsFn();
					set_mPlayer_colorTheme = 4;
					cD.winter_colorsFn();
					colorThemeDisplayInfo_current = "\33[1mWINTER theme\33[0m";
					
					cout<<"\n\n\n\n\n\n\n\n\n\n\n"<<endl;
					cout<<setw(25)<<BRIGHT<<"That's all done for you "<<RSTA<<endl;
										
					inWintercolorMenu = false;
					sleep(2);
					}
			
				} // end of while in winterColor Menu loop
				
						} // end if statement, case 5 color menu 
				break;
			} // end color switchboard
			
			} // end loop "while in color menu"	
			break;
			//----------------------------------------------------------
			
			
			//----------------------------------------------------------
			case 1: //difficulty levels
			
				inDifficultyOptionMenu = true;
			
			while(inDifficultyOptionMenu)
			{
				system("clear");
				if(easySwitch == true && expertSwitch == false){
					showCurrentDiffLevel = "\33[1;37mEASY\33[0m";
				}
				if(easySwitch == false && expertSwitch == false){
					showCurrentDiffLevel = "\33[1;32mNORMAL\33[0m";
				}
				if(easySwitch == false && expertSwitch == true){
					showCurrentDiffLevel = "\33[1;33mEXPERT\33[0m";
				}
				if(easySwitch == true && expertSwitch == true){
					showCurrentDiffLevel = "\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m";
				}
				
				
				
				cout<<"\n"
					<<"                    Current difficulty: "<<showCurrentDiffLevel<<RSTA<<endl;
				cout<<"\n"
					<<setw(30)<<"                    \33[4m*** CHOOSE DIFFICULTY ***"<<RSTA<<"\n"<<endl;
				cout<<setw(30)<<"          \33[3mPlease note\33[0m: By default the game is running\n"
					<<setw(43)<<"                       on \33[3;33mNORMAL\33[0m difficulty.\n"<<endl;
				cout<<setw(30)<<"          (\33[1;37m1\33[0m) - \33[1;37mEASY\33[0m -   You'll get to solve equations\n"
					<<setw(42)<<"                         including numbers between \33[1m0-10\33[0m."<<endl;
				cout<<setw(30)<<"          (\33[1;32m2\33[0m) - \33[1;32mNORMAL\33[0m - You'll get to solve equations\n"
					<<setw(44)<<"                         including numbers between \33[1;32m0-100\33[0m."<<endl;
				cout<<setw(30)<<"          (\33[1;33m3\33[0m) - \33[1;33mEXPERT\33[0m - You'll get to solve equations\n"
					<<setw(42)<<"                         including numbers between \33[;1;33m0-1000\33[0m."<<endl;
				cout<<setw(30)<<"          (\33[1;31m4\33[0m) - \33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m - You'll get to solve equations\n"
					<<setw(42)<<"                        including numbers between \33[1;31m0-10000\33[0m.\n"<<endl;
				int ch;
				cout<<setw(30)<<"          Setting difficulty by entering the number\n"
					<<"          sitting front of your choice --> ";
				
				cin>>ch; // make this idiotproof!!!!
				
				if(ch == 1){
					//set easy diff
					easySwitch = true;
					expertSwitch = false;
					mP_Level = 1;
					
					inDifficultyOptionMenu = false;
					cout<<"\n"<<setw(30)<<"Game set to "<<BRIGHT<<"\33[1;37mEASY\33[0m"<<RSTA<<" difficulty for you!"<<endl;
					difficulty_message = "\33[1;37mEasy\33[0m";
					
					sleep(3);
					break;}
					
				if(ch == 2){
					//set normal diff
					easySwitch = false;
					expertSwitch = false;
					mP_Level = 2;
					inDifficultyOptionMenu = false;
					cout<<"\n"<<setw(30)<<"Game set to "<<BRIGHT<<"\33[1;32mNORMAL\33[0m"<<RSTA<<" difficulty for you!"<<endl;
					difficulty_message = "\33[1;32mNormal\33[0m";
					
					sleep(3);
					break;}
					
				if(ch == 3){
					//set expert diff
					easySwitch = false;
					expertSwitch = true;
					mP_Level =3;
					inDifficultyOptionMenu = false;
					cout<<"\n"<<setw(30)<<"Game set to "<<BRIGHT<<"\33[1;33mEXPERT\33[0m"<<RSTA<<" difficulty for you!"<<endl;
					difficulty_message = "\33[1;33mExpert\33[0m";
					
					
					sleep(3);
					break;}
					
				if(ch == 4){
					//set MASTER diff
					easySwitch = true;
					expertSwitch = true;
					mP_Level = 4;
					inDifficultyOptionMenu = false;
					cout<<"\n"<<setw(30)<<"Game set to "<<BRIGHT
						<<"\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m"
						<<RSTA<<" difficulty for you!"<<endl;
					difficulty_message = "\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m";
					
					sleep(3);
					break;}
					
				else{cout<<"\n"<<setw(30)<<"Sorry, I didn't get that!\n"
						<<setw(30)<<"Please try again!"<<endl;
						continue;}
						
				} // end if while in diff option	
					
				//in_mP_option_menu = false;
					
				system("clear");
				break;	
				
			//---------------------------------------------------------
			
			}// end of Options switchboard
		} //End of while in option menu
	
				break;	// case 2 (mplayer options)
					
					
		//-----------------------------------------------------------------------------------------	
			case 3: // Leaderboard menu (Mplayer)
					
						system("clear");
						cout<<"\n                     "<<ULINE<<"\33[1m*** L E A D E R  B O A R D ***"<<RSTA<<"\n"<<endl;
				
						
					//1st; Invoke sorting Fn ... then run the display Fn
					sort(leaderList_V5.begin(),leaderList_V5.end(),sortByDescendingScore_LeaderBoardListFn_V5);
					
					//  ****
					// Player-name max 10 char, if not space added as padding.
					cout<<"\n"
						<<"      "<<ULINE<<cD.keret_color<<"NAME"<<RSTA<<"       |    "<<ULINE<<cD.keret_color<<"SCORE"<<RSTA<<"    | "<<ULINE<<cD.keret_color<<"TIME to Ans."<<RSTA<<" |   "<<ULINE<<cD.keret_color<<"LEVEL"<<RSTA<<"    |    "<<ULINE<<cD.keret_color<<"DATE"<<RSTA<<"   \n"<<RSTA
						<<"========================================================================"<<endl;
					
					int counter = 1;
					bool colorSwitch = true;
					// pass info to Leaderboard Class, and display from there:  
					//vector <LeaderBoardClass> leaderList;
					//Load from save leader list.
					//Save only name, score, answer-time and date (all in string format)
					//If last session someone score enough to go on leaderboard -> update list & resort list
					//Max 15 entry on list
					
					for(auto& obj : leaderList_V5){
					
					string padding = " ";
					// Line A
					if(colorSwitch){
					//counter	
					cout<<cD.menu_color1<<counter<<"."<<RSTA;
					while((to_string(counter).size() + padding.size()) < 4){
						padding.append(1,' ');
					}
					cout<<padding;
					//name
					cout<<cD.menu_color1<<obj.display_lB_nameFn_V5();
					//name padding
					if((obj.display_lB_nameFn_V5()).size() < 10){
						//reset padding to 1 space before each use
						padding = " ";
						while(((obj.display_lB_nameFn_V5()).size() + padding.size()) < 10){
							padding.append(1,' ');}
						cout<<padding<<"  |   ";}
					else if((obj.display_lB_nameFn_V5()).size() == 10){cout<<"  |   ";}
					//score
					cout<<cD.menu_color1<<obj.display_lB_scoreFn_V5();
					//score padding
					if(to_string(obj.display_lB_scoreFn_V5()).size() < 9){
						//reset padding to 1 space before each use
						padding = " ";
						while((to_string(obj.display_lB_scoreFn_V5()).size() + padding.size()) < 9){
							padding.append(1,' ');}
						cout<<padding<<" |  ";}
					//Time to answer 
						// If time > 1000s -> convert to min
						if(obj.display_lB_secs_passed_toAnswerFn_V5() > 1000){
							
							float minute_holder;
							minute_holder = obj.display_lB_secs_passed_toAnswerFn_V5() / 60;
							
							//Rounding to 2 decimals
							float roundedAnswerFloat_;
							string sAns;
							roundedAnswerFloat_ = roundf(minute_holder * 100)/100;
							if(static_cast<int>(roundedAnswerFloat_) == roundedAnswerFloat_){
							//convert to string
							sAns = to_string(static_cast<int>(roundedAnswerFloat_));}
							else{ 
								sAns = to_string(roundedAnswerFloat_);
								while(!sAns.empty() && 
										isdigit(sAns.back()) && sAns.back()
										== '0') {sAns.pop_back();}
								}
							cout<<cD.menu_color1<<sAns<<" min";
							//Padding
							if(sAns.size() < 6){
								//reset padding to 1 space before each use
								padding = " ";
								while((sAns.size() + padding.size()) < 6){
									padding.append(1,' ');
									}
								cout<<padding<<"  |   ";
							}
						}
						else{cout<<cD.menu_color1<<obj.display_lB_secs_passed_toAnswerFn_V5()<<" sec";
							//Time to answer padding
							if(to_string(obj.display_lB_secs_passed_toAnswerFn_V5()).size() < 6){
							//reset padding to 1 space before each use
							padding = " ";
							while((to_string(obj.display_lB_secs_passed_toAnswerFn_V5()).size() + padding.size()) < 6){
							padding.append(1,' ');}
							cout<<padding<<"  |   ";}
						}
					//Level
					if(obj.display_lB_LevelFn_V5() == 0){cout<<"n/a     ";}
					if(obj.display_lB_LevelFn_V5() == 1){cout<<"\33[1;37mEASY\33[0m    ";}
					if(obj.display_lB_LevelFn_V5() == 2){cout<<"\33[1;32mNORMAL\33[0m  ";}
					if(obj.display_lB_LevelFn_V5() == 3){cout<<"\33[1;33mEXPERT\33[0m  ";}
					if(obj.display_lB_LevelFn_V5() == 4){cout<<"\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m  ";}
						cout<<cD.menu_color1<<" |  ";
					//date
					cout<<cD.menu_color1<<obj.display_lB_dateFn_V5()
						<<endl;
					counter++;
					colorSwitch = false;
						}
					else{
					// Line B	
					//counter
					cout<<cD.menu_color2<<counter<<"."<<RSTA;
					while((to_string(counter).size() + padding.size()) < 4){
						padding.append(1,' ');
					}
					cout<<padding;
					//name
					cout<<cD.menu_color2<<obj.display_lB_nameFn_V5();
					//name padding
					if((obj.display_lB_nameFn_V5()).size() < 10){
						//reset padding to 1 space before each use
						padding = " ";
						while(((obj.display_lB_nameFn_V5()).size() + padding.size()) < 10){
							padding.append(1,' ');}
						cout<<padding<<"  |   ";}
					else if((obj.display_lB_nameFn_V5()).size() == 10){cout<<"  |   ";}
					//score
					cout<<cD.menu_color2<<obj.display_lB_scoreFn_V5();
					//score padding
					if(to_string(obj.display_lB_scoreFn_V5()).size() < 9){
						//reset padding to 1 space before each use
						padding = " ";
						while((to_string(obj.display_lB_scoreFn_V5()).size() + padding.size()) < 9){
							padding.append(1,' ');}
						cout<<padding<<" |  ";}
					//Time to answer
					// If time > 1000s -> convert to min
						if(obj.display_lB_secs_passed_toAnswerFn_V5() > 1000){
							
							float minute_holder;
							minute_holder = obj.display_lB_secs_passed_toAnswerFn_V5() / 60;
							
							//Rounding to 2 decimals
							float roundedAnswerFloat_;
							string sAns;
							roundedAnswerFloat_ = roundf(minute_holder * 100)/100;
							if(static_cast<int>(roundedAnswerFloat_) == roundedAnswerFloat_){
							//convert to string
							sAns = to_string(static_cast<int>(roundedAnswerFloat_));}
							else{ 
								sAns = to_string(roundedAnswerFloat_);
								while(!sAns.empty() && 
										isdigit(sAns.back()) && sAns.back()
										== '0') {sAns.pop_back();}
								}
							cout<<cD.menu_color2<<sAns<<" min";
							//Padding
							if(sAns.size() < 6){
								//reset padding to 1 space before each use
								padding = " ";
								while((sAns.size() + padding.size()) < 6){
									padding.append(1,' ');
									}
								cout<<padding<<"  |   ";
							}
						} 
					else{cout<<cD.menu_color2<<obj.display_lB_secs_passed_toAnswerFn_V5()<<" sec";
						//Time to answer padding
						if(to_string(obj.display_lB_secs_passed_toAnswerFn_V5()).size() < 6){
						//reset padding to 1 space before each use
						padding = " ";
						while((to_string(obj.display_lB_secs_passed_toAnswerFn_V5()).size() + padding.size()) < 6){
							padding.append(1,' ');}
						cout<<padding<<"  |   ";}
					}
					//Level
					if(obj.display_lB_LevelFn_V5() == 0){cout<<"n/a     ";}
					if(obj.display_lB_LevelFn_V5() == 1){cout<<"\33[1;37mEASY"<<RSTA<<cD.menu_color2<<"    ";}
					if(obj.display_lB_LevelFn_V5() == 2){cout<<"\33[1;32mNORMAL"<<RSTA<<cD.menu_color2<<"  ";}
					if(obj.display_lB_LevelFn_V5() == 3){cout<<"\33[1;33mEXPERT"<<RSTA<<cD.menu_color2<<"  ";}
					if(obj.display_lB_LevelFn_V5() == 4){cout<<"\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR"<<cD.menu_color2<<"  ";}
						cout<<cD.menu_color2<<" |  ";
					//date
					cout<<cD.menu_color2<<obj.display_lB_dateFn_V5()
						<<endl;
					counter++;
					colorSwitch = true;}	
					if(counter == 16){break;}
						}

					cout<<cD.menu_color2<<"\nPress \33[1mENTER"<<RSTA<<cD.menu_color2<<" to continue..."<<RSTA<<endl;
					cin.get();
					cin.get();
						
						
						break;
					//--------------------------------------------------	
						} // end of Mplayer switchboard
						
				
				
			//reset diff levels to normal/ defalult
			easySwitch = false;
			expertSwitch = false;	
			//reset color choice to default
			cD.default_colorsFn();
				
			} // multiplayer shell End
		
			break;
	//===== END OF MULTIPLAYER MODE =======================================================================================================		
	//---------------------
		case 3: // Number Matrix 15x15
		
			multiplicationTable15x15Fn();
			
			cout<<"Press \33[1mENTER\33[0m once you finished here..."
				<<endl;
			fflush(stdout);
			fflush(stdin);
			cin.get();
			cin.get();
			system("clear");
			break;
	//==================================================================
	} // Main menu switchboard END
	
	}// Outer Shell loop END

//======================= END OF MAIN () ===============================	
return 0;	
}
//==================================================================================================
//==================================================================================================
//								*** FUNCTION BODY ***



//======================================================================
//				***		MULTIPLAYER GAMELOOP FN		***
//======================================================================
void multiplayer_GameLoopFn_V5(MplayerClass obj){
	
	
	obj.mP_currentRound_initializerFn_V5(rounds);
	
	string name_without_padding;
	name_without_padding = obj.mP_name_displayFn_V5();
	
	//give you 3 lifes to start with, unless you have more saved!!!!!!
	while(whileInGameLoop){
		
		system("clear");
		
		// if player has no life left, loop pops to the next player stright away...
		if(obj.mP_lifes_displayFn_V5() <= 0){
			whileInGameLoop = false;
			break;}
		
		
		//dificulty determin range (both off == default level) both On never happens
		if(mP_Level == 1){
			easySwitch = true;
			expertSwitch = false;
			difficulty_message = "\33[1;37mEASY\33[0m";
			range = 10;} //EASY

		if(mP_Level == 2){
			easySwitch = false;
			expertSwitch = false;
			difficulty_message = "\33[1;32mNORMAL\33[0m";
			range = 100;} //NORMAL
		if(mP_Level == 3){
			expertSwitch = true;
			easySwitch = false;
			difficulty_message = "\33[1;33mEXPERT\33[0m";
			range = 1000;} //EXPERT
		if(mP_Level == 4){
			easySwitch = true;
			expertSwitch = true;
			difficulty_message = "\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m";
			range = 10000;} // Master Level
		
		
		
		
		seedrnd();
		int rn1 = rnd1(range);
		int rn2 = rnd2(range);
		char operation = selectRndOperationFn();
		if(operation == '/' && rn2 == 0){rn2 = rn2 + 1;}
		
		attempts_test = 1;
		//Equation and Answer Fn:
		//Correct current answer (in string):
		string currentCorrectAnswerString = correctAnswerInStringFn(rn1,rn2,operation);
		currentCanswer_display = currentCorrectAnswerString;
		//-----------------------------------------------------------------------------
		
		//----------------------------------------------------------------------------	
		// If u didn't quit or skip you are entiteled to have a "round award"
		
		// 9; 10 rounds played in a row (in one session) milestone
		if(obj.mP_totalRoundsPlayed_displayFn_V5() == 10 && milestone_reaching_10RoundsInSession){
			milestone_reaching_10RoundsInSessionFn(obj.mP_totalRoundsPlayed_displayFn_V5());
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			//Phisiquly add + 1 life
			obj.mP_lifes_setterFn_V5(+1);
			// updates obj.
			//sPlayersVector[sP_userSelected] = obj;
			//for test Stop:
						cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");
		}
		//---------------------------------------------------------------------------------
		// 10; 50 rounds played in a row (in one session) milestone
		if(obj.mP_totalRoundsPlayed_displayFn_V5() == 50 && milestone_reaching_50RoundsInSession){
			milestone_reaching_50RoundsInSessionFn(obj.mP_totalRoundsPlayed_displayFn_V5());
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			//Phisiquly add + 2 life
			obj.mP_lifes_setterFn_V5(+2);
			// updates obj.
			//sPlayersVector[sP_userSelected] = obj;
			//for test Stop:
						cout<<"(Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");
						
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() >= 5 && obj.mP_lifes_displayFn_V5() <= 6){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								system("clear");
								}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() >= 10 && obj.mP_lifes_displayFn_V5() <= 11){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+2);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								system("clear");
								}
						
		}
		//------------------------------------------------------------------------------------
		// 11; 100 rounds played in a row (in one session) milestone
		if(obj.mP_totalRoundsPlayed_displayFn_V5() == 100 && milestone_reaching_100RoundsInSession){
			milestone_reaching_100RoundsInSessionFn(obj.mP_totalRoundsPlayed_displayFn_V5());
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			//Phisiquly add + 3 life
			obj.mP_lifes_setterFn_V5(+3);
			// updates obj.
			//sPlayersVector[sP_userSelected] = obj;
			//for test Stop:
						cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");
						
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() >= 5 && obj.mP_lifes_displayFn_V5() <= 7){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								system("clear");
								}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() >= 10 && obj.mP_lifes_displayFn_V5() <= 12){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+2);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								system("clear");
								}
		}
		//------------------------------------------------------------------------------------
		//This if never played in Mplayer mode....
		if(obj.mP_lifes_displayFn_V5() <= 0){
			
			cout<<"\n"
				<<"                    You are out of lifes....\n"<<RSTA<<endl;
						//cout<<"           "<<BRIGHT<<i<<RSTA<<"\n"<<endl;
			sleep(2);	
			cout<<setw(14)<<cD.tryagain_color<<" But don't be sad! You got This! Just KEEP PRACTICING!"<<RSTA
				<<endl;
			cout<<endl;
			while(name_without_padding.back() == ' '){
				name_without_padding.pop_back();
			}
			cout<<setw(14)<<cD.menu_color2<<obj.mP_name_displayFn_V5()<<RSTA
				<<cD.whiteBold_color<<"\33[0m, your total score from this session is: "
				<<RSTA
				<<cD.youranswer_color<<obj.mP_totalScoreInThisSession_displayFn_V5()
				<<RSTA          
				<<endl;
					for(int i = 0; i > 2; i++){
						cout<<".";
						fflush(stdout);
						sleep(1);}
						
					system("clear");
					
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<setw(35)<<" *** "<<FREDBOLD<<"\33[5mGAME OVER!"<<RSTA<<" ***\n"
							<<"\n"  //test message
							<<"                                    "<<cD.menu_color1<<"FOR"<<RSTA<<" "<<cD.menu_color1<<"YOU,"<<RSTA<<"\n\n"
							<<"                                    "<<cD.menu_color2<<obj.mP_name_displayFn_V5()<<RSTA<<"\n"<<endl;
						sleep(1);
						
				//for test Stop:
				cout<<"\n\n"
					<<setw(37)<<"Press \33[1mENTER\33[0m to continue..."<<endl;
				cin.get();

				 
			correct = true;
			whileInGameLoop = false;
			obj.mP_totalRoundsPlayed_setterFn_V5(-1);
			
			obj.mP_newHighScoreInOneSession_setterFn_V5(obj.mP_totalScoreInThisSession_displayFn_V5());
						
						
			system("clear");
			break;
			}	
		//--------------------------------------------------------------
		//Display
		else{
		
		cout<<"           "<<RSTA<<cD.menu_color1<<"Level: "<<RSTA<<difficulty_message<<RSTA
			<<"   "<<cD.menu_color1<<"AUTO-ROUND: "<<RSTA<<auto_turn_stateFn_V5()<<RSTA
			<<"   "<<cD.menu_color1<<"AUTO-TURN: "<<RSTA<<auto_round_stateFn_V5()<<RSTA<<endl;
		if(mp_auto_round){
		cout<<"           "<<ITALIC<<"(Enter \'\33[1mq\33[0m\' or \'\33[1mQ\33[0m\' if you want to stop/exit...)"<<RSTA<<endl;}
		cout<<"           "<<cD.keret_color<<"****************************************************"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"                                                  "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"      "<<ULINE<<"NOTE:"<<RSTA<<" "<<cD.menu_color1<<"If there is a division equation,"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.menu_color1<<"please round up your answer to 2 decimals!"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"      (\33[3m"<<cD.menu_color2<<"Unless the result is whole number."<<RSTA<<")        "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<RSTA<<"           "<<cD.keret_color<<"*"<<RSTA<<"                                                  "<<cD.keret_color<<"*"<<RSTA<<"\n"
			
			
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"   "<<cD.menu_color1<<"Enter"<<RSTA<<" "<<BRIGHT<<"'s'"<<RSTA<<" "<<cD.menu_color1<<"or"<<RSTA<<" "<<BRIGHT<<"'S'"
			<<RSTA<<" "<<cD.menu_color1<<"as an answer if you'd like"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"                 "<<cD.menu_color1<<"to"<<RSTA<<" "<<cD.menu_color2<<"SKIP"<<RSTA<<" "<<cD.menu_color1<<"the equation."<<RSTA<<"            "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"     (\33[1mG.A.S.\33[0m -> "<<cD.menu_color1<<"stands for good answer streak"<<RSTA<<")    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"                                                  "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"****************************************************"<<RSTA<<"\n"
		<<endl;
		//----------------------------------------------------------------------------------------------
		cout<<"           "<<cD.menu_color1<<"PLAYER:"<<RSTA<<" "<<cD.menu_color2<<obj.mP_name_displayFn_V5()<<RSTA
			<<"     "<<cD.menu_color1<<"YOUR TOTAL SCORE:"<<RSTA<<" "<<cD.menu_color2<<obj.mP_totalScoreInThisSession_displayFn_V5()<<RSTA
			<<"       "<<cD.menu_color1<<"ROUND:"<<RSTA<<" "<<BRIGHT<<cD.menu_color2<<obj.mP_currentRound_displayFn_V5()<<RSTA<<"\n"<<endl;
		cout<<"           "<<cD.menu_color1<<"LIFE LEFT:"<<RSTA<<" "<<cD.menu_color2<<obj.mP_lifes_displayFn_V5()<<RSTA; // load from save file if > 3
		cout<<"       "<<cD.menu_color1<<"G.A.S.:"<<RSTA<<" "<<cD.menu_color2<<obj.mP_goodAnswerStreek_dispalyFn_V5()<<RSTA
			<<"       "<<cD.menu_color1<<"SKIPS left:"<<RSTA<<" "<<cD.menu_color2<<obj.mP_skip_displayFn_V5()<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"--------------------------------------------------------------------"<<RSTA<<"\n"
				<<endl;		
		cout<<setw(26)<<cD.equattionText_color<<"EQUATION:"<<RSTA<<" "<<cD.equation_color1<<rn1<<RSTA<<" "<<cD.operation_color<<operation<<RSTA<<" "<<cD.equation_color2<<rn2<<RSTA<<" "<<cD.operation_color<<"="<<RSTA<<" ";
		
		//--------------------------------------------------------------
		//Answer Loop:
		
		correct = false;
		//clear buffers...
		fflush(stdin);
		fflush(stdout);
		cin.clear();
	
		//Add starter time point:
		time_t starter_timePoint_V5 = time(0);
		
	do{ //while not correct
		
	//Ask for answer string
	cin>>yourAnswerString;
	cin.get();
	//-------------------EVALUATING ANSWER--------------------------
				
		//--------------------------------------------------------------------------------
		//If stop/exit:
		if(yourAnswerString == "q" || yourAnswerString == "Q"){
			whileInGameLoop = false;
			correct = true;
			mp_unlimitedLoopExit = true;
		
			break;
		}
		
		// If SKIP:
		if(yourAnswerString == "s" || yourAnswerString == "S"){
			if(obj.mP_skip_displayFn_V5()  > 0){
			//skipp = skipp -1;
			obj.mP_skip_setterFn_V5( -1 );
			//update playerStatus
			mPlayersVector[mP_i] = obj;
			
			correct = true;
			whileInGameLoop = false; // -> So Next Player turns
			break;}
			else{
				cout<<endl;
				cout<<"                     "<<cD.tryagain_color<<"NO MORE SKIPPING..."<<RSTA<<"\n\n"
					<<"              "<<"\33[1;32mANSWER\33[0m or \33[1;31mQUIT\33[0m, \33[1mPLEASE!"<<RSTA<<"\n"<<endl;
				continue;}}
		//---------------------------------------------------------------------------------
		
		
			// 2/2 - when your answer is NOT good 1-2 times:
			// attempts 1 - 3 and answer is no good:
			if(yourAnswerString != currentCorrectAnswerString) // if answer incorrect:
				{
				//increment attempts
				attempts_test = attempts_test + 1; 
				obj.mP_attemptCounter_singleSession_setterFn_V5(1);
				// minus one life
				//life_updater_var--;
				obj.mP_lifes_setterFn_V5(- 1);
				obj.mP_lifesLost_inLastSession_setterFn_V5(); // each time it's invoked adds 1 more to total updates AllTime too
				//reset G.A.Streak
				obj.mP_goodAnswerStreek_initialiserFn_V5(0);
				//update playerStatus
				mPlayersVector[mP_i] = obj;
				
				//-------------------
				if(attempts_test >3 && obj.mP_lifes_displayFn_V5() == 0){
					
					cout<<RSTA<<"\n"
						<<setw(15)<<" "<<FRED_BWHITE<<"Oops... Nooooo! Well, this didn't go well! :)\n"<<RSTA
						<<endl;
						cout<<"                           "<<cD.tryagain_color<<"*** NO LIFES LEFT! ***"<<RSTA<<endl;
					sleep(1);
					cout<<RSTA;
					cout<<"\n"<<"                      "<<cD.menu_color1<<"The answer is:"<<RSTA<<" "<<cD.equation_color1<<rn1<<RSTA<<" "<<cD.operation_color<<operation<<RSTA<<" "<<cD.equation_color2<<rn2<<RSTA<<" "<<cD.operation_color<<"="<<RSTA<<" "<<cD.youranswer_color<<currentCanswer_display<<RSTA<<endl;
					cout<<endl;
					sleep(2);
					cout<<setw(17)<<FWHITEBOLD<<cD.itsnotanumber_color<<" But don't be sad! You got This! Just KEEP PRACTICING!"<<RSTA
						<<endl;
					cout<<endl;
					
					while(name_without_padding.back() == ' '){
						name_without_padding.pop_back();
						}
					cout<<setw(14)<<name_without_padding<<RSTA
						<<"\33[0m, your total score from this session is: "
						<<"\33[2;30;47m"
						<<obj.mP_totalScoreInThisSession_displayFn_V5()
						<<RSTA<<"\n"
						<<endl;
				sleep(5);
				//for test Stop:
				cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
				cin.get();
				//cin.get();
				system("clear");
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<setw(35)<<" *** "<<FREDBOLD<<"\33[5mGAME OVER!\33[0m"<<RSTA<<" ***\n"
							<<"\n" //test message 36sp
							<<"                                    "<<cD.menu_color1<<"FOR"<<RSTA<<" "<<cD.menu_color1<<"YOU,"<<RSTA<<"\n\n"
							<<"                                    "<<cD.menu_color2<<obj.mP_name_displayFn_V5()<<RSTA<<"\n"<<endl;
						sleep(1);
						cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						
						correct = true;
						//update vars
						//Just for test display asign obj ot testUserArra[0]
						obj.mP_goodAnswerStreek_initialiserFn_V5(0);
						obj.mP_newHighScoreInOneSession_setterFn_V5(obj.mP_totalScoreInThisSession_displayFn_V5());
						
						//update playerStatus
						mPlayersVector[mP_i] = obj;
						//obj.lifes_test_initialiserFn(0);
						whileInGameLoop = false;
						
						break;
					}
			//---------------------------------------------------------------------------------------------
				else{
					
					//----------------------------------------------------------------------------	
					if(obj.mP_lifes_displayFn_V5() <= 0){
						
						cout<<"\n                "<<cD.itsnotanumber_color<<"You are out of lifes...."<<RSTA<<"\n"<<endl;
						//cout<<"           "<<BRIGHT<<i<<RSTA<<"\n"<<endl;
						sleep(2);	
						cout<<setw(17)<<cD.menu_color2<<" But don't be sad! You got This! Just KEEP PRACTICING!"<<RSTA
							<<endl;
						cout<<endl;
						
						while(name_without_padding.back() == ' '){
							name_without_padding.pop_back();
							}			
						cout<<setw(14)<<BRIGHT<<obj.mP_name_displayFn_V5()<<RSTA
							<<"\33[0m, your total score from this session is: "
							<<"\33[2;30;47m"
							<<obj.mP_totalScoreInThisSession_displayFn_V5()
							<<RSTA          
							<<endl;
							for(int i = 0; i > 2; i++){
						cout<<".";
						fflush(stdout);
						sleep(1);}
						
					system("clear");
					
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<setw(35)<<" *** "<<FREDBOLD<<"\33[5mGAME OVER!\33[0m"<<RSTA<<" ***\n"
							<<"\n" //test message
							<<"                                    "<<cD.menu_color1<<"FOR"<<RSTA<<" "<<cD.menu_color1<<"YOU,"<<RSTA<<"\n\n"
							<<"                                    "<<cD.menu_color2<<obj.mP_name_displayFn_V5()
							<<RSTA<<"\n"<<endl;
				sleep(1);
						//for test Stop:
						cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						
								
							 
						correct = true;
						whileInGameLoop = false;
						obj.mP_currentRound_setterFn_V5(-1);
						//obj.sP_allTimeScore_setterFn_V5();
						
						//obj.sP_lifesLost_allTime_setterFn_V5();
						obj.mP_newHighScoreInOneSession_setterFn_V5(obj.mP_totalScoreInThisSession_displayFn_V5());
						
						//update playerStatus
						mPlayersVector[mP_i] = obj;
						system("clear");
						break;
						}	
						
					cout<<RSTA<<"\n"
						<<setw(20)<<" "<<cD.tryagain_color<<"Oops... Nooooo! Please try again!"<<RSTA<<"\n"<<RSTA
						<<endl;
					sleep(1);
					
					
					//clear screen and reload equation with updated life display
					system("clear");
					//--------------------------------------------------------------
			cout<<"           "<<RSTA<<cD.menu_color1<<"Level: "<<RSTA<<difficulty_message<<RSTA
			<<"   "<<cD.menu_color1<<"AUTO-ROUND: "<<RSTA<<auto_turn_stateFn_V5()<<RSTA
			<<"   "<<cD.menu_color1<<"AUTO-TURN: "<<RSTA<<auto_round_stateFn_V5()<<RSTA<<endl;
		if(mp_auto_round){
		cout<<"           "<<ITALIC<<"(Enter \'\33[1mq\33[0m\' or \'\33[1mQ\33[0m\' if you want to stop/exit...)"<<RSTA<<endl;}
		cout<<"           "<<cD.keret_color<<"****************************************************"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"                                                  "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"      "<<ULINE<<"NOTE:"<<RSTA<<" "<<cD.menu_color1<<"If there is a division equation,"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.menu_color1<<"please round up your answer to 2 decimals!"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"      (\33[3m"<<cD.menu_color2<<"Unless the result is whole number."<<RSTA<<")        "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<RSTA<<"           "<<cD.keret_color<<"*"<<RSTA<<"                                                  "<<cD.keret_color<<"*"<<RSTA<<"\n"
			//<<"           "<<cD.keret_color<<"*"<<RSTA<<"   "<<cD.menu_color1<<"Enter"<<RSTA<<" \33[1m'q'\33[0m "<<cD.menu_color1<<"or"<<RSTA<<" \33[1m'Q'\33[0m "<<cD.menu_color1<<"as an answer if you'd like"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			//<<"           "<<cD.keret_color<<"*"<<RSTA<<"                      "<<cD.menu_color1<<"to"<<RSTA<<" "<<cD.menu_color2<<"QUIT."<<RSTA<<"                    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"   "<<cD.menu_color1<<"Enter"<<RSTA<<" "<<BRIGHT<<"'s'"<<RSTA<<" "<<cD.menu_color1<<"or"<<RSTA<<" "<<BRIGHT<<"'S'"
			<<RSTA<<" "<<cD.menu_color1<<"as an answer if you'd like"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"                 "<<cD.menu_color1<<"to"<<RSTA<<" "<<cD.menu_color2<<"SKIP"<<RSTA<<" "<<cD.menu_color1<<"the equation."<<RSTA<<"            "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"     (\33[1mG.A.S.\33[0m -> "<<cD.menu_color1<<"stands for good answer streak"<<RSTA<<")    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"                                                  "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"****************************************************"<<RSTA<<"\n"
		<<endl;
		//----------------------------------------------------------------------------------------------
		cout<<"           "<<cD.menu_color1<<"PLAYER:"<<RSTA<<" "<<cD.menu_color2<<obj.mP_name_displayFn_V5()<<RSTA
			<<"     "<<cD.menu_color1<<"YOUR TOTAL SCORE:"<<RSTA<<" "<<cD.menu_color2<<obj.mP_totalScoreInThisSession_displayFn_V5()<<RSTA
			<<"       "<<cD.menu_color1<<"ROUND:"<<RSTA<<" "<<BRIGHT<<cD.menu_color2<<obj.mP_currentRound_displayFn_V5()<<RSTA<<"\n"<<endl;
		cout<<"           "<<cD.menu_color1<<"LIFE LEFT:"<<RSTA<<" "<<cD.menu_color2<<obj.mP_lifes_displayFn_V5()<<RSTA; // load from save file if > 3
		cout<<"       "<<cD.menu_color1<<"G.A.S.:"<<RSTA<<" "<<cD.menu_color2<<obj.mP_goodAnswerStreek_dispalyFn_V5()<<RSTA
			<<"       "<<cD.menu_color1<<"SKIPS left:"<<RSTA<<" "<<cD.menu_color2<<obj.mP_skip_displayFn_V5()<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"--------------------------------------------------------------------"<<RSTA<<"\n"
				<<endl;	
		cout<<setw(26)<<cD.equattionText_color<<"EQUATION:"<<RSTA<<" "<<cD.equation_color1<<rn1<<RSTA<<" "<<cD.operation_color<<operation<<RSTA<<" "<<cD.equation_color2<<rn2<<RSTA<<" "<<cD.operation_color<<"="<<RSTA<<" ";
		
					continue;
					}	
				
				}
		//-----------------------------------------------------------------------------
			// 1/2 - if your Answer is good:
			else if(yourAnswerString == currentCorrectAnswerString) 
			{
				//set Answered time point:
				time_t answered_time_point = time(0);
				//get the passed seconds
				double minutesPassed_V5 = difftime(answered_time_point, starter_timePoint_V5);
				//add these secs to the total secs, then divide total secs with total rounds to get the statistic
				obj.mP_updeate_Total_secsPassed(minutesPassed_V5);
			
			cout<<endl;
			cout<<"     "<<cD.keret_color<<"--------------------------------------------------------------------"<<RSTA<<"\n"
				<<endl;
			cout<<"          "<<cD.smily_color<<":)"<<RSTA<<"  "<<cD.yes_color<<"YES"<<RSTA
				<<"     "<<BRIGHT<<"The answer is:"<<RSTA<<" "<<cD.equation_color1<<rn1<<RSTA<<" "<<cD.operation_color<<operation<<RSTA<<" "<<cD.equation_color2<<rn2<<RSTA<<" "<<cD.operation_color<<"="<<RSTA<<" "<<cD.youranswer_color<<yourAnswerString<<RSTA
				<<"     "<<cD.yes_color<<"YES"<<RSTA<<"  "<<cD.smily_color<<":)"<<RSTA
				<<"\n"<<endl;
			cout<<"                             Answered in "<<BRIGHT<<minutesPassed_V5<<RSTA<<"s\n"<<endl;
			sleep(1);
			//update good answer streak
			gAnsInRowCounter++;
			obj.mP_goodAnswerStreek_setterFn_V5();
			obj.mP_attemptCounter_singleSession_setterFn_V5(1);
			obj.mP_sessionGoodAnswerCounter_V5_setterFn(); // invoke when good answer...
			//-----------------------------------------------------------------------
			
			
			//add an extra life after every 3 G.Answer in a row
			//Milestone Fns:  *** ADD HERE ALL ***
		// 1;
		if(obj.mP_goodAnswerStreek_dispalyFn_V5() == 3 && milestone_extraLifeFor_3inRow){
		milestone_extraLifeFor_3inRowFn(obj.mP_goodAnswerStreek_dispalyFn_V5());
		//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
		// adds physiquly + 1 life
		obj.mP_lifes_setterFn_V5(+1); // works with +1
		// updates obj.
		
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		
		// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() >= 5){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() >= 10){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+2);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}
		
	}
		//-----------------------------------------
		// 2;    After 5 in a row correct answers: Message pop up, plus 1 extra life.
		if(obj.mP_goodAnswerStreek_dispalyFn_V5() == 5 && milestone_extraLifeFor_5inRow){
		milestone_extraLifeFor_5inRowFn(obj.mP_goodAnswerStreek_dispalyFn_V5());
		//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
		// adds physiquly + 1 life
		obj.mP_lifes_setterFn_V5(+1); // works with +1
		
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		
		// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() >= 5){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() >= 10){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+2);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}
		
	}
		//------------------------------------------------------------------------------------
		
		// 3; 10 in a row G.A.S.
		if(obj.mP_goodAnswerStreek_dispalyFn_V5() == 10 && milestone_extraLifeFor_10inRow){
		milestone_extraLifeFor_10inRowFn(obj.mP_goodAnswerStreek_dispalyFn_V5());
		//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			// adds physiquly + 2 life
			obj.mP_lifes_setterFn_V5(+2);
			
			cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
			cin.get();
		//------------------------------
			// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() >= 5 && obj.mP_lifes_displayFn_V5() <= 6){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1);cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() >= 10 && obj.mP_lifes_displayFn_V5() <= 11){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+2);cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}
		//--------------------------------------------------------------
		} //end of 10 ina row
		//-------------------------------------------------------------------------------
		// 13; 50 G.A.S. that's 50 in a row
		
		if(obj.mP_goodAnswerStreek_dispalyFn_V5() == 50 && milestone_extraLifeFor_50inRow){
		milestone_extraLifeFor_50inRowFn(obj.mP_goodAnswerStreek_dispalyFn_V5());
		// count & sets the amount of milestones are unlocked
		//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
		// adds physiquly + 3 life
		obj.mP_lifes_setterFn_V5(+3);
		
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		
		// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() >= 5 && obj.mP_lifes_displayFn_V5() <= 7){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() >= 10 && obj.mP_lifes_displayFn_V5() <= 12){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+2);cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}	
		
		}
		//-------------------------------------------------------------------------------
		//===============================================================================
	
			correct = true;
			//inGame = true;
			whileInGameLoop = true;
		
			fflush(stdin); //does Not clear the "Enter" input...
			
			break;
			}
		//--------------------------------------------------------------	
        
		fflush(stdin); //does Not clear the "Enter" input...
		
	}while(!correct);//END of EVALUATION

	
	if(yourAnswerString == "s" || yourAnswerString == "S" || yourAnswerString =="q" ||yourAnswerString =="Q"){
		roundScore_V5 = 0;
		obj.mP_totalScoreInThisSession_setterFn_V5(roundScore_V5);
		//sPlayersVector[sP_userSelected] = obj;
		//update playerStatus
			mPlayersVector[mP_i] = obj;
		}
		
	else if(yourAnswerString != "s" || yourAnswerString != "S" || attempts_test <= 3)
			{
	//-------------------------------------------------------------------------------
	//--------------------SCORING-----------------------------------
				if(mP_Level == 1){roundScore_V5= 5;} //EASY
				if(mP_Level == 2){roundScore_V5= 10;} //Normal
				if(mP_Level == 3){roundScore_V5= 30;} //Expert
				if(mP_Level == 4){roundScore_V5= 50;} //Master
				
				
		// Score deduced after each attempt
		
		if(attempts_test == 1 && obj.mP_lifes_displayFn_V5() > 0)
				{
				obj.mP_totalScoreInThisSession_setterFn_V5(roundScore_V5);
				//obj.sP_allTimeScore_setterFn_V5();
				//obj.sP_attemptCounter_singleSession_setterFn_V5(1);
				
			while(name_without_padding.back() == ' '){
				name_without_padding.pop_back();
			}
				cout<<endl
					<<setw(20)<<BRIGHT<<name_without_padding<<RSTA<<", "
					<<"\33[0myour total score is : "
					<<"\33[2;30;47m"
					<<obj.mP_totalScoreInThisSession_displayFn_V5()
					<<RSTA
					<<endl;
					sleep(2);
					//Milestone message pop up if score reach milestone....
				// 4; Reaching 100 score in one session: Message Pop Up, plus 1 extra life.
				if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 100 && milestone_reaching_100_ScoreInSingleSession){
					milestone_reaching100ScoreInSingleSessionFn(obj.mP_totalScoreInThisSession_displayFn_V5());
					// adds physiquly + 1 life
					obj.mP_lifes_setterFn_V5(+1); // works with +1
				
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		
					// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() == 5){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() == 10){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+2);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}	
		
				}
			//-----------------------------------------------------
			// 7; Reaching 1000 score in a single session milestone
			if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 1000 && milestone_reaching1000_ScoreInSingleSession){
					milestone_reaching1000_ScoreInSingleSessionFn(obj.mP_totalScoreInThisSession_displayFn_V5());
				
					obj.mP_lifes_setterFn_V5(+3);
					cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
					cin.get();
				//Add the life related achivements here too...
				// Milestone displayed if achived:
					// 5; If you reach 5 lifes 
					if((obj.mP_lifes_displayFn_V5() >= 5 && obj.mP_lifes_displayFn_V5() <=7) && milestone_reaching5_lifes){
						
								milestone_reaching5_lifesFn(5);
								// adds physiquly + 1 life
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1); // works with +1
				
							cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
							cin.get();
							}
										
					//-----------------------------------------------------------------------------------------------------
					// 6; Reaching 10 lifes
						if((obj.mP_lifes_displayFn_V5() >= 10 && obj.mP_lifes_displayFn_V5() <=12) && milestone_reaching10_lifes){
						
								milestone_reaching10_lifesFn(10);
								// adds physiquly + 2 life
								obj.mP_lifes_setterFn_V5(+2); 
				
						cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
							}
					//-----------------------------------------------------
	
			} //end of 1000 score
					
			//-----------------------------------------------------
			// 8; Reaching 5000 score in a single session...
						if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 5000 && milestone_reaching5000_ScoreInSingleSession){ // reset bool var before session starts
							milestone_reaching5000_ScoreInSingleSessionFn(obj.mP_totalScoreInThisSession_displayFn_V5());
							// adds physiquly + 5 life
							obj.mP_lifes_setterFn_V5(+5); //
				
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() >= 6 && obj.mP_lifes_displayFn_V5() <= 9){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								obj.mP_lifes_setterFn_V5(+1);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");
								}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() >= 10 && obj.mP_lifes_displayFn_V5() <= 14){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								obj.mP_lifes_setterFn_V5(+2);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");
								}	
					}
			//---------------------------------------------------------------------------------------------------------		
			//12; Challenge Inpossible: 1000 Score in 100 rounds. add extra 3 lifes (Answerstreak 100)
			if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 1000 &&
				obj.mP_totalRoundsPlayed_displayFn_V5() <= 100 && milestone_reaching_1000Score_in100Rounds){
				milestone_reaching_1000Score_in100RoundsFn(obj.mP_totalScoreInThisSession_displayFn_V5(), obj.mP_totalRoundsPlayed_displayFn_V5());
				// add + 3 lifes
				obj.mP_lifes_setterFn_V5(+3);
				
				// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() >= 5 && obj.mP_lifes_displayFn_V5() <= 7){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() >= 10 && obj.mP_lifes_displayFn_V5() <= 12){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+2);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}	
				
			}
			//-----------------------------------------------------------------------------------------
			//17; Challenge impossible 2: 10000(ten tousend) Score in a single session
					if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 10000 && milestone_reaching10000_ScoreInSingleSession){ // reset bool var before session starts
							milestone_reaching10000_ScoreInSingleSessionFn(obj.mP_totalScoreInThisSession_displayFn_V5());
							// adds physiquly + 5 life
							obj.mP_lifes_setterFn_V5(+5); //
				
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() >= 6 && obj.mP_lifes_displayFn_V5() <= 9){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() >= 10 && obj.mP_lifes_displayFn_V5() <= 14){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+2);cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}	
					}
					
			//-----------------------------------------------------------------------------
			
			//update playerStatus
			mPlayersVector[mP_i] = obj;
			
			correct = true;
			whileInGameLoop = false;
		} //end of attemt 1 
			//------------------------------------------------------------------------------	
		if(attempts_test == 2 && obj.mP_lifes_displayFn_V5() > 0)
				{
				if(mP_Level == 1){roundScore_V5= 4;} //EASY
				if(mP_Level == 2){roundScore_V5= 8;} //Normal
				if(mP_Level == 3){roundScore_V5= 24;} //Expert
				if(mP_Level == 4){roundScore_V5= 40;} //Master
				obj.mP_totalScoreInThisSession_setterFn_V5(roundScore_V5);
				//obj.sP_allTimeScore_setterFn_V5();
				//obj.sP_attemptCounter_singleSession_setterFn_V5(2);
			
				while(name_without_padding.back() == ' '){
				name_without_padding.pop_back();
				}
			
			cout<<endl
				<<setw(20)<<BRIGHT<<name_without_padding<<RSTA<<", "
				<<"\33[0myour total score is : "
				<<"\33[2;30;47m"
				<<obj.mP_totalScoreInThisSession_displayFn_V5()
				<<RSTA
				<<endl;
				sleep(2);
				//Milestone message pop up if score reach milestone....
				// 4; Reaching 100 score in one session: Message Pop Up, plus 1 extra life.
				if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 100 && milestone_reaching_100_ScoreInSingleSession){
					milestone_reaching100ScoreInSingleSessionFn(obj.mP_totalScoreInThisSession_displayFn_V5());
					// adds physiquly + 1 life
					obj.mP_lifes_setterFn_V5(+1); // works with +1
					
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				
				//Add the life related achivements here too...
				// Milestone displayed if achived:
					// 5; If you reach 5 lifes 
					if((obj.mP_lifes_displayFn_V5() == 5) && milestone_reaching5_lifes){
								
								
								milestone_reaching5_lifesFn(5);
								// adds physiquly + 1 life
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1); // works with +1
					
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
										
					//-----------------------------------------------------------------------------------------------------
					// 6; Reaching 10 lifes
						if((obj.mP_lifes_displayFn_V5() == 10 ) && milestone_reaching10_lifes){
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
						// updates obj.
						//sPlayersVector[sP_userSelected] = obj;
								milestone_reaching10_lifesFn(10);
								// adds physiquly + 2 life
								obj.mP_lifes_setterFn_V5(+2); 
					
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
				
		
				} // end of raching 100 score
			//-----------------------------------------------------
			// 7; Reaching 1000 score in a single session milestone
			if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 1000 && milestone_reaching1000_ScoreInSingleSession){
					milestone_reaching1000_ScoreInSingleSessionFn(obj.mP_totalScoreInThisSession_displayFn_V5());
					
					//get the 3 for 1000 score too
								obj.mP_lifes_setterFn_V5(+3);
					
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				//Add the life related achivements here too...
				// Milestone displayed if achived:
					// 5; If you reach 5 lifes 
					if((obj.mP_lifes_displayFn_V5() >= 5 && obj.mP_lifes_displayFn_V5() <=7) && milestone_reaching5_lifes){
								
								
								milestone_reaching5_lifesFn(5);
								// adds physiquly + 1 life
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1); // works with +1
					
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
										
					//-----------------------------------------------------------------------------------------------------
					// 6; Reaching 10 lifes
						if((obj.mP_lifes_displayFn_V5() >= 10 && obj.mP_lifes_displayFn_V5() <=12) && milestone_reaching10_lifes){
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
						// updates obj.
						//sPlayersVector[sP_userSelected] = obj;
								milestone_reaching10_lifesFn(10);
								// adds physiquly + 2 life
								obj.mP_lifes_setterFn_V5(+2); 
					
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
					//-----------------------------------------------------
				} //end of reaching 1000 score
			//-----------------------------------------------------
			// 8; Reaching 5000 score in a single session...
						if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 5000 && milestone_reaching5000_ScoreInSingleSession){ // reset bool var before session starts
							milestone_reaching5000_ScoreInSingleSessionFn(obj.mP_totalScoreInThisSession_displayFn_V5());
							// adds physiquly + 5 life
							obj.mP_lifes_setterFn_V5(+5); //
				
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(obj.mP_lifes_displayFn_V5() >= 6 && obj.mP_lifes_displayFn_V5() <= 9){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.mP_lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");
									}
								//----------------------------------------------------------------
								if(obj.mP_lifes_displayFn_V5() >= 11 && obj.mP_lifes_displayFn_V5() <= 14){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.mP_lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");
									}	
					}
				
			//---------------------------------------------------------------------------------------------------------		
			//12; Challenge Inpossible: 1000 Score in 100 rounds. add extra 3 lifes (Answerstreak 100)
			if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 1000 &&
				obj.mP_totalRoundsPlayed_displayFn_V5() <= 100 && milestone_reaching_1000Score_in100Rounds){
				milestone_reaching_1000Score_in100RoundsFn(obj.mP_totalScoreInThisSession_displayFn_V5(), obj.mP_totalRoundsPlayed_displayFn_V5());
				// add + 3 lifes
				obj.mP_lifes_setterFn_V5(+3);
				//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
				// updates obj.
				//sPlayersVector[sP_userSelected] = obj;
			}
			//-----------------------------------------------------------------------------------------
			//17; Challenge impossible 2: 10000(ten tousend) Score in a single session
					if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 10000 && milestone_reaching10000_ScoreInSingleSession){ // reset bool var before session starts
							milestone_reaching10000_ScoreInSingleSessionFn(obj.mP_totalScoreInThisSession_displayFn_V5());
							// adds physiquly + 5 life
							obj.mP_lifes_setterFn_V5(+5); //
				
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() >= 6 && obj.mP_lifes_displayFn_V5() <= 9){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() >= 11 && obj.mP_lifes_displayFn_V5() <= 14){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+2);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}	
					}
			//-----------------------------------------------------------------------------------------------------
			//---------------------------------------------------------------------------------------------------------
			
			//update playerStatus
			mPlayersVector[mP_i] = obj;
						
			correct = true;
			whileInGameLoop = false;
			} // end of attempt 2			 
			//---------------------------------------------------------------------------------------	
		else if(attempts_test == 3 && obj.mP_lifes_displayFn_V5() > 0)
				{	
				if(mP_Level == 1){roundScore_V5= 3;} //EASY
				if(mP_Level == 2){roundScore_V5= 6;} //Normal
				if(mP_Level == 3){roundScore_V5= 18;} //Expert
				if(mP_Level == 4){roundScore_V5= 30;} //Master
				obj.mP_totalScoreInThisSession_setterFn_V5(roundScore_V5);
				//obj.sP_allTimeScore_setterFn_V5();
				//obj.sP_attemptCounter_singleSession_setterFn_V5(3);
			
				while(name_without_padding.back() == ' '){
				name_without_padding.pop_back();
			}
			
			cout<<endl
				
				<<setw(20)<<BRIGHT<<name_without_padding<<RSTA<<", "
				<<"\33[0myour total score is : "
				<<"\33[2;30;47m"
				<<obj.mP_totalScoreInThisSession_displayFn_V5()
				<<RSTA
				<<endl;
				sleep(1);
		//------------------------------------------------------------------------------------------		
				//Milestone message pop up if score reach milestone....
				// 4; Reaching 100 score in one session: Message Pop Up, plus 1 extra life.
				if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 100 && milestone_reaching_100_ScoreInSingleSession){
					milestone_reaching100ScoreInSingleSessionFn(obj.mP_totalScoreInThisSession_displayFn_V5());
					// adds physiquly + 1 life
					obj.mP_lifes_setterFn_V5(+1); // works with +1
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				}
			//-----------------------------------------------------
			// 7; Reaching 1000 score in a single session milestone
			if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 1000 && milestone_reaching1000_ScoreInSingleSession){
					milestone_reaching1000_ScoreInSingleSessionFn(obj.mP_totalScoreInThisSession_displayFn_V5());
					
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				//Add the life related achivements here too...
				// Milestone displayed if achived:
					// 5; If you reach 5 lifes 
					if((obj.mP_lifes_displayFn_V5() >= 2 && obj.mP_lifes_displayFn_V5() <=7) && milestone_reaching5_lifes){
						obj.mP_lifes_setterFn_V5(+3);
								milestone_reaching5_lifesFn(5);
								// adds physiquly + 1 life
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1); // works with +1
					
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
										
					//-----------------------------------------------------------------------------------------------------
					// 6; Reaching 10 lifes
						if((obj.mP_lifes_displayFn_V5() >= 2 && obj.mP_lifes_displayFn_V5() <=7) && milestone_reaching10_lifes){
							obj.mP_lifes_setterFn_V5(+3);
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
						// updates obj.
						//sPlayersVector[sP_userSelected] = obj;
								milestone_reaching10_lifesFn(10);
								// adds physiquly + 2 life
								obj.mP_lifes_setterFn_V5(+2); 
					
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
					//-----------------------------------------------------
				// adds physiquly + 3 life
				else{	obj.mP_lifes_setterFn_V5(+3);}
				
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				}
			//-----------------------------------------------------
			// 8; Reaching 5000 score in a single session...
						if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 5000 && milestone_reaching5000_ScoreInSingleSession){ // reset bool var before session starts
							milestone_reaching5000_ScoreInSingleSessionFn(obj.mP_totalScoreInThisSession_displayFn_V5());
							// adds physiquly + 5 life
							obj.mP_lifes_setterFn_V5(+5); //
				
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() >= 6 && obj.mP_lifes_displayFn_V5() <= 9){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								obj.mP_lifes_setterFn_V5(+1);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");
								}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() >= 11 && obj.mP_lifes_displayFn_V5() <= 14){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								obj.mP_lifes_setterFn_V5(+2);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");
								}	
					}
			//---------------------------------------------------------------------------------------------------------		
			//12; Challenge Inpossible: 1000 Score in 100 rounds. add extra 3 lifes (Answerstreak 100)
			if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 1000 &&
				obj.mP_totalRoundsPlayed_displayFn_V5() <= 100 && milestone_reaching_1000Score_in100Rounds){
				milestone_reaching_1000Score_in100RoundsFn(obj.mP_totalScoreInThisSession_displayFn_V5(), obj.mP_totalRoundsPlayed_displayFn_V5());
				// add + 3 lifes
				obj.mP_lifes_setterFn_V5(+3);
				//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
				// updates obj.
				//sPlayersVector[sP_userSelected] = obj;
			}
			//-----------------------------------------------------------------------------------------
			//17; Challenge impossible 2: 10000(ten tousend) Score in a single session
					if(obj.mP_totalScoreInThisSession_displayFn_V5() >= 10000 && milestone_reaching10000_ScoreInSingleSession){ // reset bool var before session starts
							milestone_reaching10000_ScoreInSingleSessionFn(obj.mP_totalScoreInThisSession_displayFn_V5());
							// adds physiquly + 5 life
							obj.mP_lifes_setterFn_V5(+5); //
				
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.mP_lifes_displayFn_V5() >= 6 && obj.mP_lifes_displayFn_V5() <= 9){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+1);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}
							//----------------------------------------------------------------
							if(obj.mP_lifes_displayFn_V5() >= 11 && obj.mP_lifes_displayFn_V5() <= 14){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.mP_lifes_setterFn_V5(+2);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");}	
					}
					
					
	//-----------------------------------------------------------------------------------------------------
	//-----------------------------------------------------------------------------------------------------------------
		
		//update playerStatus
		mPlayersVector[mP_i] = obj;
		
		cout<<RSTA;	
		correct = true;
		whileInGameLoop = false; // so it exits even if you answered correct and the other player's turn...
		
		} //end of attemt 3
		
		//-------------------------------------------------------------------
		// Milestone displayed if achived:
		// 5; If you reach 5 lifes 
		
		if(obj.mP_lifes_displayFn_V5() == 5 && milestone_reaching5_lifes){
					milestone_reaching5_lifesFn(obj.mP_lifes_displayFn_V5());
					// adds physiquly + 1 life
					obj.mP_lifes_setterFn_V5(+1); // works with +1
			
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				}
		//--------------------------------------------------------------
		// 6; Reaching 10 lifes
			if(obj.mP_lifes_displayFn_V5() == 10 && milestone_reaching10_lifes){
				
			// updates obj.
			//sPlayersVector[sP_userSelected] = obj;
					milestone_reaching10_lifesFn(obj.mP_lifes_displayFn_V5());
					// adds physiquly + 2 life
					obj.mP_lifes_setterFn_V5(+2); 
					// updates obj.
					//sPlayersVector[sP_userSelected] = obj;
		
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				}
		//-----------------------------------------------------
		
		attempts_test = 1;
		
		
			
				
			} //else if answer loop end
		
		} // else (when the actual game equation starts) ...
				
	}	//end of while in game loop
	
	//update data... before the next user's turn...
	mPlayersVector[mP_i] = obj;
	
}	// end of GameLoopFn
//================================END OF MULTIPLAYER GAME LOOP=====================================

//------------------------------------------------------------------
//Random equation loop:
//seed	
void seedrnd(void)
{
	srand((unsigned)time(NULL));
}
//random num 1
int rnd1(int range)
{
	int r;
	r=rand()%range;return(r);
}
//random num 2
int rnd2(int range)
{
	int r;
	r=rand()%range;
	return(r);
	}
//Select a rnd operation Fn:
//----------------------------------------------------------------------
char selectRndOperationFn(){
	const char plus = '+';
	const char minus = '-';
	const char divv = '/';
	const char mull = '*';
	
	char operationSign;
	int selector;
	
	do{
	
	selector = (rand()%4)+1; // +1 so it's never zero
	
	if(selector == 1){
		operationSign = plus;}
	if(selector == 2){
		operationSign = minus;}
	if(selector == 3){
		operationSign = divv;}
	if(selector == 4){
		operationSign = mull;}
	}while(selector > 4); // > 4 reruns the loop if selector = 5 
	return operationSign;
	}
//----------------------------------------------------------------------
//Correct Answer Fn:
string correctAnswerInStringFn(int n1, int n2, char op){

	
	int answerInt = 0;
	float answerFloat = 0.2;
	float roundedAnswerFloat = 0.2;
	string stringCorrectAnswer = " ";
	string unformatedStringAnswer = " "; 
	string formatedAnswer = " ";
	
	if(op == '/'){
		
		if(n2 == 0){n2 = n2 + 1;}
		float fN1=(float)n1;
		float fN2=(float)n2;
		answerFloat = fN1 / fN2;
		
		//Rounding to 2 decimals
		roundedAnswerFloat = roundf(answerFloat * 100)/100;
		if(static_cast<int>(answerFloat) == answerFloat){
			unformatedStringAnswer = to_string(static_cast<int>(answerFloat));}
			
		else{ unformatedStringAnswer = to_string(roundedAnswerFloat); //convert to string
		
				//Formating string output:
				//Rid of the trailing 4 zeros from the displaying number
				while(!unformatedStringAnswer.empty() && 
					isdigit(unformatedStringAnswer.back()) && unformatedStringAnswer.back()
					== '0') {unformatedStringAnswer.pop_back();}
				//unformated becomed formated....
				
		}
		pFloatCorrectAnswer = &roundedAnswerFloat; //saving into float variable
		if(n1==0){stringCorrectAnswer = "0";} // So you dont need to write "0." (dot after ZERO) when answering
		if(n1 == 91 && n2 == 5){stringCorrectAnswer = "18.2";} // somehow this result by the program is 18.200001
		else {stringCorrectAnswer = unformatedStringAnswer;} //returning formated string type
		}
		
	if(op == '+'){
		answerInt = n1 + n2;
		pIntCorrectAnswer = &answerInt;
		stringCorrectAnswer = to_string(answerInt);
		}
	if(op == '-'){
		answerInt = n1 - n2;
		pIntCorrectAnswer = &answerInt;
		stringCorrectAnswer = to_string(answerInt);
		}
	if(op == '*'){
		answerInt = n1 * n2;
		pIntCorrectAnswer = &answerInt;
		stringCorrectAnswer = to_string(answerInt);
		}
	return stringCorrectAnswer;
	}
//---------------------------------------------------------------------------------
//save your choosen colortheme
void colorThemeLoadFn(SplayerClass obj){ // invoke on selected player (once selected) save data in color options
	
	if(obj.sP_choosen_colorScheme_displayFn_V5() == 0){
		// Set colorTheme to default
		cD.default_colorsFn();}
	if(obj.sP_choosen_colorScheme_displayFn_V5() == 1){
		// Set colorTheme to Spring
		cD.spring_colorsFn();}
	if(obj.sP_choosen_colorScheme_displayFn_V5() == 2){
		// Set colorTheme to Summer
		cD.summer_colorsFn();}
	if(obj.sP_choosen_colorScheme_displayFn_V5() == 3){
		// Set colorTheme to Autumn
		cD.autumn_colorsFn();}
	if(obj.sP_choosen_colorScheme_displayFn_V5() == 4){
		// Set colorTheme to Winter
		cD.winter_colorsFn();}
		}
//----------------------------------------------------------------------
//Statistics function:
void statistic_outsideFn(SplayerClass obb){
	
	//1st make the nessecery maths:
	obb.sP_avgScorePerRound_lastSession_setterFn_V5();
	
	cout<<endl;
	cout<<"     *** STATISTICS ***\n"<<endl;
			cout<<BBLACK<<"Player's name: \t"<<obb.name_displayFn_V5()<<endl;
			cout<<RSTA<<"Player's ID: \t"<<obb.idNum_displayFn_V5()<<endl;
			cout<<RSTA<<"Lifes you got: "<<obb.lifes_displayFn_V5()<<endl;
			cout<<BBLACK<<"Total rounds played last session: \t"<<obb.totalRoundsPlayed_displayFn_V5()<<"\n"
				<<RSTA<<"Total score made during last session: \t"<<obb.totalScoreInThisSession_displayFn_V5()<<"\n"
				<<BBLACK"Longest good answer streak you've had last session: \t"<<obb.longestGoodAnswerStreak_displayFn_V5()<<"\n"
				<<"Average Score per Round: "<<roundf(obb.sP_avgScorePerRound_lastSession_displayFn_V5() * 100)/100<<"\n"
				<<RSTA<<endl;
	}
//------------------------------------------------------------------------------
SplayerClass userSelectorFn_V5(int i){
		//use the catch, try thing here.... or size
		/* For static array:
		size_t size = sizeof(testUserArray) / sizeof(testUserArray[0]);
		* elements in array = size
		* ----------------------------
		* For vector array:
		* testArray.size()
		*/
		int a = sPlayersVector.size();
		if(i > a ){
			cout<<FWHITE_BDARK<<"\nSorry, not found! Please try again"<<RSTA<<endl;
			cout<<"OR register..."<<endl;
			}
		else{ 
			//test display selected user.
			//cout<<"\nWELCOME "<<sPlayersVector[i].name_displayFn_V5()<<endl;
			return sPlayersVector[i];
			}
	}
//----------------------------------------------------------------------
// mPlayerClass user selectorFn:
MplayerClass mP_userSelectorFn_V5(int i){
		int a = mPlayersVector.size();
		if(i > a ){
			cout<<FWHITE_BDARK<<"\nSorry, not found! Please try again"<<RSTA<<endl;
			cout<<"OR register..."<<endl;
			}
		else{ 
			//test display selected user.
			//cout<<"\nWELCOME "<<sPlayersVector[i].name_displayFn_V5()<<endl;
			return mPlayersVector[i];
			}
	}
//----------------------------------------------------------------------
void exitLoop(void)
{
	int x; /*here is the 'x' decleard as a variable inside this function*/
	
		
	for(x=3;x>0;x--)
		{	
			cout<<"\n"
				<<endl;
		    cout<<"           	\033[;31;40mTHIS PROGRAM TERMINATES IN: -\033[1;37m"<<x<<"\033[;31;40m-\033[0m\n"; // to display a falling 'bomb'
		    fflush(stdout); // fflush(stdout) needs to make cout to display during looping, as cout is buffered function
		    // use this (cout) method if you need to progress horizintaly
		    // use puts if you need to advance verticlly(as puts contains new line in it's function)
		    sleep(1);//to do it sec by sec//
		    system("clear");
		}
		
    }
//----------------------------------------------------------------------

//----------------------------------------------------------------------
//TodayFn Method 2 (no need <time.h>) -> we return only date
// !!! This does NOT update after the program is compiled..... !!!!!!!!!!!!!!
string toDayFn_v2_V5(){
	string d = __DATE__;	// Month Day Year -> (Feb 11 2025)
	//string t = __TIME__;
	//string dt = d + " | " + t;
	return d;}
//----------------------------------------------------------------------


//======================================================================================
//					***		SINGLEPLAYER GAME LOOP		***
//======================================================================================


void gameLoopFn_V5(SplayerClass obj){	// each session 
	
	//assign user to obj...
	//mP_userSelectorFn_V5(mP_userSelected) = obj;
			
	
	//Reset session:
	// Session score to ZERO - reset for each time you play a new session.
	obj.sP_shortest_time_goodAnswerGiven_lastSession_V5_initializerFN(0);
	obj.sP_longest_time_goodAnswerGiven_lastSession_V5_initializerFN(0);
	obj.totalScoreInThisSession_initialiserFn_V5(0);
	obj.totalRoundsPlayed_initialiserFn_V5(0);
	obj.sP_sessionGoodAnswerCounter_V5_initializerFn();
	obj.goodAnswerStreek_initialiserFn_V5(0);
	obj.longestGoodAnswerStreak_initialiserFn_V5(0);
	obj.sP_attemptCounter_singleSession_initializerFn_V5();
	obj.sP_lifesLost_inLastSession_initializerFn_V5(); // initialize (invoke) at program start to ZERO
	//obj.sP_milestonesUnlocked_counter_setterFn_V5(0); // Load from file if have saved data !!!
	obj.sP_secsPassedPerGa_singleSessionData_resetFn_V5(); //resets session time collector
	//milestones unlocked initialize so not counting alredy unlocked ones.
	milestone_1_h = obj.sp_milestone_1_V5;
	milestone_2_h = obj.sp_milestone_2_V5;
	milestone_3_h = obj.sp_milestone_3_V5;
	milestone_4_h = obj.sp_milestone_4_V5;
	milestone_5_h = obj.sp_milestone_5_V5;
	milestone_6_h = obj.sp_milestone_6_V5;
	milestone_7_h = obj.sp_milestone_7_V5;
	milestone_8_h = obj.sp_milestone_8_V5;
	milestone_9_h = obj.sp_milestone_9_V5;
	milestone_10_h = obj.sp_milestone_10_V5;
	milestone_11_h = obj.sp_milestone_11_V5;
	milestone_12_h = obj.sp_milestone_12_V5;
	milestone_13_h = obj.sp_milestone_13_V5;
	milestone_14_h = obj.sp_milestone_14_V5;
	milestone_15_h = obj.sp_milestone_15_V5;
	milestone_16_h = obj.sp_milestone_16_V5;
	milestone_17_h = obj.sp_milestone_17_V5;
	milestone_17andHalf_h = obj.sp_milestone_17andHalf_V5;
	milestone_18_h = obj.sp_milestone_18_V5;
	masterSwitch_h = obj.sP_masterlevel_unlocked;
	allMilestonesProgress_inDotH = obj.sP_milestonesUnlocked_counter_displayFn_V5();
	milestone_5sec_easy_dotH = obj.milestone_5sec_easy_V5;
	milestone_5sec_normal_dotH = obj.milestone_5sec_normal_V5;
	milestone_5sec_expert_dotH = obj.milestone_5sec_expert_V5;
	milestone_5sec_master_dotH = obj.milestone_5sec_master_V5;
	milestone_3sec_easy_dotH = obj.milestone_3sec_easy_V5;
	milestone_3sec_normal_dotH = obj.milestone_3sec_normal_V5;
	milestone_3sec_expert_dotH = obj.milestone_3sec_expert_V5;
	milestone_3sec_master_dotH = obj.milestone_3sec_master_V5;
	milestone_1sec_easy_dotH = obj.milestone_1sec_easy_V5;
	milestone_1sec_normal_dotH = obj.milestone_1sec_normal_V5;
	milestone_1sec_expert_dotH = obj.milestone_1sec_expert_V5;
	milestone_1sec_master_dotH = obj.milestone_1sec_master_V5;
	// Current round to ONE
	rounds = 0;
	//Set life to 3 or more if you have more from saved...
	if(userSelectorFn_V5(sP_userSelected).lifes_displayFn_V5() > 3){
		obj.sP_lifes_V5_initialiserFn(userSelectorFn_V5(sP_userSelected).lifes_displayFn_V5());}
	else {obj.sP_lifes_V5_initialiserFn(3);}
	
	
	//--------------------------------------------------------------------------------------------------
	//Session awards
			// 14; reaching 10 session (all-time reward)
			// note session counter must be saved (& loaded back before this point)
			if( userSelectorFn_V5(sP_userSelected).sP_sessionCounter_displayFn_V5()== 10 && milestone_reaching10_sessions){
				milestone_reaching10_sessionsFn(10);
				//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
		// adds physiquly + 1 life
		obj.lifes_setterFn_V5(+1); // works with +1
		// updates obj.
		sPlayersVector[sP_userSelected] = obj;
		
		// 5; If you reach 5 lifes 
			if((obj.lifes_displayFn_V5() == 5 || obj.lifes_displayFn_V5() == 6) && milestone_reaching5_lifes){
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			// updates obj.
			sPlayersVector[sP_userSelected] = obj;
					milestone_reaching5_lifesFn(5);
					// adds physiquly + 1 life
					obj.lifes_setterFn_V5(+1); // works with +1
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					/*
					//test:
					// display if update done:
					cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
					cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
					cout<<"Press ENTER to continue..."<<endl;
					cin.get();
					*/
					cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
					cin.get(); 
				}
			//----------------------------
			// 6; Reaching 10 lifes
			if((obj.lifes_displayFn_V5() == 10 || obj.lifes_displayFn_V5() == 11) && milestone_reaching10_lifes){
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			// updates obj.
			sPlayersVector[sP_userSelected] = obj;
					milestone_reaching10_lifesFn(10);
					// adds physiquly + 2 life
					obj.lifes_setterFn_V5(+2); 
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					/*
					//test:
					// display if update done:
					cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
					cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
					cout<<"Press ENTER to continue..."<<endl;
					cin.get();
					*/
					cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
					cin.get();
				}
		//--------------------------------------------------------------
		/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
	}
		//-----------------------------------------------------------------------------------------------------------
		
		// 15; 50 session mark: Motivational speach... + extra 3 life
		if( userSelectorFn_V5(sP_userSelected).sP_sessionCounter_displayFn_V5()== 50 && milestone_reaching50_sessions){
				milestone_reaching50_sessionsFn(50);
				//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
		// adds physiquly + 3 life
		obj.lifes_setterFn_V5(+3);
		// updates obj.
		sPlayersVector[sP_userSelected] = obj;
		
		// 5; If you reach 5 lifes 
			if((obj.lifes_displayFn_V5() >= 5 && obj.lifes_displayFn_V5() <= 7) && milestone_reaching5_lifes){
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			// updates obj.
			sPlayersVector[sP_userSelected] = obj;
					milestone_reaching5_lifesFn(5);
					// adds physiquly + 1 life
					obj.lifes_setterFn_V5(+1); // works with +1
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					/*
					//test:
					// display if update done:
					cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
					cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
					cout<<"Press ENTER to continue..."<<endl;
					cin.get();
					*/
					cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
					cin.get(); 
				}
			//----------------------------
			// 6; Reaching 10 lifes
			if((obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 12) && milestone_reaching10_lifes){
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			// updates obj.
			sPlayersVector[sP_userSelected] = obj;
					milestone_reaching10_lifesFn(10);
					// adds physiquly + 2 life
					obj.lifes_setterFn_V5(+2); 
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					/*
					//test:
					// display if update done:
					cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
					cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
					cout<<"Press ENTER to continue..."<<endl;
					cin.get();
					*/
					cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
					cin.get();
				}
		//--------------------------------------------------------------
		/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
	}
		//---------------------------------------------------------------------------------------------------------------
		
		// 16; 100 session mark -> Message: Mate, you are ADDICTED! I guess :)
		if( userSelectorFn_V5(sP_userSelected).sP_sessionCounter_displayFn_V5()== 100 && milestone_reaching100_sessions){
				milestone_reaching100_sessionsFn(100);
				//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
		// adds physiquly + 5 life
		obj.lifes_setterFn_V5(+5);
		// updates obj.
		sPlayersVector[sP_userSelected] = obj;
		
		// 5; If you reach 5 lifes 
			if((obj.lifes_displayFn_V5() >= 5 && obj.lifes_displayFn_V5() <= 9) && milestone_reaching5_lifes){
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			// updates obj.
			sPlayersVector[sP_userSelected] = obj;
					milestone_reaching5_lifesFn(5);
					// adds physiquly + 1 life
					obj.lifes_setterFn_V5(+1); // works with +1
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					/*
					//test:
					// display if update done:
					cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
					cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
					cout<<"Press ENTER to continue..."<<endl;
					cin.get();
					*/
					cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
					cin.get(); 
				}
			//----------------------------
			// 6; Reaching 10 lifes
			if((obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 14) && milestone_reaching10_lifes){
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			// updates obj.
			sPlayersVector[sP_userSelected] = obj;
					milestone_reaching10_lifesFn(10);
					// adds physiquly + 2 life
					obj.lifes_setterFn_V5(+2); 
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					/*
					//test:
					// display if update done:
					cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
					cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
					cout<<"Press ENTER to continue..."<<endl;
					cin.get();
					*/
					cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
					cin.get();
				}
		//--------------------------------------------------------------
		/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
	}
		//---------------------------------------------------------------------------------------------------------------
	
		
	//give you 3 lifes to start with, unless you have more saved!!!!!!
	while(whileInGameLoop){
		
		system("clear");
		
			//update previous life monitor
			int prev_lives_V5 = 0;
			prev_lives_V5 = obj.lifes_displayFn_V5();
		
		
		
		//dificulty determin range (both off == default level) both On never happens
		if(obj.sP_chosen_level_displayFn_V5() == 1){range = 10;}
		if(obj.sP_chosen_level_displayFn_V5() == 2){range = 100;}
		if(obj.sP_chosen_level_displayFn_V5() == 3){range = 1000;}
		if(obj.sP_chosen_level_displayFn_V5() == 4){range = 10000;}
		seedrnd();
		int rn1 = rnd1(range);
		int rn2 = rnd2(range);
		char operation = selectRndOperationFn();
		if(operation == '/' && rn2 == 0){rn2 = rn2 + 1;}
		rounds = rounds + 1;
		obj.totalRoundsPlayed_InThisSession_setterFn_V5(1);
		obj.sP_lifes_V5_initialiserFn(obj.lifes_displayFn_V5());
		//reset attempts
		attempts_test = 1;
		//Equation and Answer Fn:
		//Correct current answer (in string):
		string currentCorrectAnswerString = correctAnswerInStringFn(rn1,rn2,operation);
		currentCanswer_display = currentCorrectAnswerString;
		//-----------------------------------------------------------------------------
		// THIS MOVED TO THE END OF GAME LOOP -->
		// See if you need at the beggining too... don't think so yet...
		// Altho I'm deeply in LOVE with HOPE Elliot right now, so that might effect on my "CLEAR" thinking... :) 21.01.2025
		
		/*obj.oBachivementsCounter = achivementsCounter;
		
		if(obj.oBachivementsCounter == 19){
			obj.oBallAchivementsAreUnlocked = true;
			allMilestonesUnlockedFn(19, obj.name_displayFn_V5());
			} //Display the "final message" GAME COMPLATED!...
		*/
		//----------------------------------------------------------------------------	
		// If u didn't quit or skip you are entiteled to have a "round award"
		
		// 9; 10 rounds played in a row (in one session) milestone
		if(obj.totalRoundsPlayed_displayFn_V5() == 10 && milestone_reaching_10RoundsInSession){
			milestone_reaching_10RoundsInSessionFn(obj.totalRoundsPlayed_displayFn_V5());
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			//Phisiquly add + 1 life
			obj.lifes_setterFn_V5(+1);
			// updates obj.
			sPlayersVector[sP_userSelected] = obj;
			//for test Stop:
						cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");
		}
		//---------------------------------------------------------------------------------
		// 10; 50 rounds played in a row (in one session) milestone
		if(obj.totalRoundsPlayed_displayFn_V5() == 50 && milestone_reaching_50RoundsInSession){
			milestone_reaching_50RoundsInSessionFn(obj.totalRoundsPlayed_displayFn_V5());
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			//Phisiquly add + 2 life
			obj.lifes_setterFn_V5(+2);
			// updates obj.
			sPlayersVector[sP_userSelected] = obj;
			//for test Stop:
						cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");
		}
		//------------------------------------------------------------------------------------
		// 11; 100 rounds played in a row (in one session) milestone
		if(obj.totalRoundsPlayed_displayFn_V5() == 100 && milestone_reaching_100RoundsInSession){
			milestone_reaching_100RoundsInSessionFn(obj.totalRoundsPlayed_displayFn_V5());
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			//Phisiquly add + 3 life
			obj.lifes_setterFn_V5(+3);
			// updates obj.
			sPlayersVector[sP_userSelected] = obj;
			//for test Stop:
						cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						system("clear");
		}
		//------------------------------------------------------------------------------------
		
		if(obj.lifes_displayFn_V5() <= 0){
			
			cout<<"\n"
				<<"                    You are out of lifes....\n"<<RSTA<<endl;
						//cout<<"           "<<BRIGHT<<i<<RSTA<<"\n"<<endl;
			sleep(2);	
			cout<<setw(14)<<cD.tryagain_color<<" But don't be sad! You got This! Just KEEP PRACTICING!"<<RSTA
				<<endl;
			cout<<endl;
			cout<<setw(14)<<cD.menu_color2<<obj.name_displayFn_V5()<<RSTA
				<<cD.whiteBold_color<<"\33[0m, your total score from this session is: "
				<<RSTA
				<<cD.youranswer_color<<obj.totalScoreInThisSession_displayFn_V5()
				<<RSTA          
				<<endl;
					for(int i = 0; i > 2; i++){
						cout<<".";
						fflush(stdout);
						sleep(1);}
						
					system("clear");
					
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<setw(35)<<" *** "<<FREDBOLD<<"\33[5mGAME OVER!"<<RSTA<<" ***"<<endl;
				sleep(3);
				//for test Stop:
				cout<<"\n\n"
					<<setw(37)<<"Press \33[1mENTER\33[0m to continue..."<<endl;
				cin.get();

				 
			correct = true;
			whileInGameLoop = false;
			obj.totalRoundsPlayed_InThisSession_setterFn_V5(-1);
			//ADDED-------------------------------------------------------------------------------------------------------
			// I don't think this part is needed, but in there is a "game over" section too so it might need to update from here too...
			
						obj.sP_newHighScoreInOneSession_setterFn_V5(obj.totalScoreInThisSession_displayFn_V5());
						obj.sP_allTimeScore_setterFn_V5(obj.totalScoreInThisSession_displayFn_V5());
						if(obj.sP_chosen_level_displayFn_V5() == 1){ 
							obj.sP_allTime_easy_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
							obj.sP_allTime_rounds_easy_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
						if(obj.sP_chosen_level_displayFn_V5() == 2){ 
							obj.sP_allTime_normal_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
							obj.sP_allTime_rounds_normal_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
						if(obj.sP_chosen_level_displayFn_V5() == 3){
							 obj.sP_allTime_expert_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
							 obj.sP_allTime_rounds_expert_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
						if(obj.sP_chosen_level_displayFn_V5() == 4){
							 obj.sP_allTime_master_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
							 obj.sP_allTime_rounds_master_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
						obj.sP_longestPlayEver_setterFn_V5(obj.totalRoundsPlayed_displayFn_V5()); // updates longest session record
						obj.sP_longestGoodAnswerStreakEver_setterFn_V5(obj.goodAnswerStreek_dispalyFn_V5());
						obj.sP_allTime_totalRoundsPlayed_setterFn_V5(obj.totalRoundsPlayed_displayFn_V5());
						obj.sP_anyGoodAnswerGiven_allTimeFn_setter_V5(obj.sP_sessionGoodAnswerCounter_V5_displayFn()); // i = anyGoodAnswerGiven_lastSession_V5
						obj.sP_lifesLost_allTime_setterFn_V5(obj.sP_lifesLost_inLastSession_displayFn_V5()); // ()lost life in session
						obj.sP_attemptCounter_AllTime_setterFn_V5(obj.sP_attemptCounter_singleSession_displayFn_V5()); // i = attempts_counterForStatistic_singleSession_V5
						obj.sP_sessionCounter_setterFn_V5(+1);
						//milestones update
						obj.sp_milestone_1_V5 = milestone_1_h;
						obj.sp_milestone_2_V5 = milestone_2_h;
						obj.sp_milestone_3_V5 = milestone_3_h;
						obj.sp_milestone_4_V5 = milestone_4_h;
						obj.sp_milestone_5_V5 = milestone_5_h;
						obj.sp_milestone_6_V5 = milestone_6_h;
						obj.sp_milestone_7_V5 = milestone_7_h;
						obj.sp_milestone_8_V5 = milestone_8_h;
						obj.sp_milestone_9_V5 = milestone_9_h;
						obj.sp_milestone_10_V5 = milestone_10_h;
						obj.sp_milestone_11_V5 = milestone_11_h;
						obj.sp_milestone_12_V5 = milestone_12_h;
						obj.sp_milestone_13_V5 = milestone_13_h;
						obj.sp_milestone_14_V5 = milestone_14_h;
						obj.sp_milestone_15_V5 = milestone_15_h;
						obj.sp_milestone_16_V5 = milestone_16_h;
						obj.sp_milestone_17_V5 = milestone_17_h;
						obj.sp_milestone_17andHalf_V5 = milestone_17andHalf_h;
						obj.sp_milestone_18_V5 = milestone_18_h;
						obj.sP_masterlevel_unlocked = masterSwitch_h;
						obj.milestone_5sec_easy_V5 = milestone_5sec_easy_dotH;
						obj.milestone_5sec_normal_V5 = milestone_5sec_normal_dotH;
						obj.milestone_5sec_expert_V5 = milestone_5sec_expert_dotH;
						obj.milestone_5sec_master_V5 = milestone_5sec_master_dotH;
						obj.milestone_3sec_easy_V5 = milestone_3sec_easy_dotH;
						obj.milestone_3sec_normal_V5 = milestone_3sec_normal_dotH;
						obj.milestone_3sec_expert_V5 = milestone_3sec_expert_dotH;
						obj.milestone_3sec_master_V5 = milestone_3sec_master_dotH;
						obj.milestone_1sec_easy_V5 = milestone_1sec_easy_dotH;
						obj.milestone_1sec_normal_V5 = milestone_1sec_normal_dotH;
						obj.milestone_1sec_expert_V5 = milestone_1sec_expert_dotH;
						obj.milestone_1sec_master_V5 = milestone_1sec_master_dotH;
						//To able to display statistics asign obj to PlayerObject
						//userSelectorFn_V5(sP_userSelected) = obj;
			//ADDED END---------------------------------------------------------------------------------------------------------
			//To able to display statistics asign obj to PlayerObject
				userSelectorFn_V5(sP_userSelected) = obj;
				
			//obj.goodAnswerStreek_initialiserFn_V5(0);
			//obj.sP_lifes_V5_initialiserFn(3);
			//inGame = false;
			system("clear");
			break;
			}	
		//--------------------------------------------------------------
		//Display -> *** NEEDS a rework for Multi Player Sync!!! ***
		else{
		cout<<endl;
		cout<<"           "<<RSTA<<cD.menu_color1<<"Level: "<<RSTA<<difficulty_message<<RSTA<<endl;
		cout<<"           "<<cD.keret_color<<"****************************************************"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"                                                  "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"      "<<ULINE<<"NOTE:"<<RSTA<<" "<<cD.menu_color1<<"If there is a division equation,"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.menu_color1<<"please round up your answer to 2 decimals!"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"      (\33[3m"<<cD.menu_color2<<"Unless the result is whole number."<<RSTA<<")        "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<RSTA<<"           "<<cD.keret_color<<"*"<<RSTA<<"                                                  "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"   "<<cD.menu_color1<<"Enter"<<RSTA<<" \33[1m'q'\33[0m "<<cD.menu_color1<<"or"<<RSTA<<" \33[1m'Q'\33[0m "<<cD.menu_color1<<"as an answer if you'd like"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"                      "<<cD.menu_color1<<"to"<<RSTA<<" "<<cD.menu_color2<<"QUIT."<<RSTA<<"                    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"   "<<cD.menu_color1<<"Enter"<<RSTA<<" "<<BRIGHT<<"'s'"<<RSTA<<" "<<cD.menu_color1<<"or"<<RSTA<<" "<<BRIGHT<<"'S'"
			<<RSTA<<" "<<cD.menu_color1<<"as an answer if you'd like"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"                 "<<cD.menu_color1<<"to"<<RSTA<<" "<<cD.menu_color2<<"SKIP"<<RSTA<<" "<<cD.menu_color1<<"the equation."<<RSTA<<"            "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"     (\33[1mG.A.S.\33[0m -> "<<cD.menu_color1<<"stands for good answer streak"<<RSTA<<")    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"****************************************************"<<RSTA<<"\n"
		<<endl;
		//----------------------------------------------------------------------------------------------
		cout<<"           "<<cD.menu_color1<<"PLAYER:"<<RSTA<<" "<<cD.menu_color2<<obj.name_displayFn_V5()<<RSTA
			<<"     "<<cD.menu_color1<<"SESSION'S SCORE:"<<RSTA<<" "<<cD.menu_color2<<obj.totalScoreInThisSession_displayFn_V5()<<RSTA
			<<"       "<<cD.menu_color1<<"ROUND:"<<RSTA<<" "<<BRIGHT<<cD.menu_color2<<obj.totalRoundsPlayed_displayFn_V5()<<RSTA<<"\n"<<endl;
		cout<<"           "<<cD.menu_color1<<"LIFE LEFT:"<<RSTA<<" "<<cD.menu_color2<<obj.lifes_displayFn_V5()<<RSTA; // load from save file if > 3
		cout<<"       "<<cD.menu_color1<<"G.A.S.:"<<RSTA<<" "<<cD.menu_color2<<obj.goodAnswerStreek_dispalyFn_V5()<<RSTA
			<<"       "<<cD.menu_color1<<"SKIPS left:"<<RSTA<<" "<<cD.menu_color2<<skipp<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"--------------------------------------------------------------------"<<RSTA<<"\n"
				<<endl;		
		cout<<setw(26)<<cD.equattionText_color<<"EQUATION:"<<RSTA<<" "<<cD.equation_color1<<rn1<<RSTA<<" "<<cD.operation_color<<operation<<RSTA<<" "<<cD.equation_color2<<rn2<<RSTA<<" "<<cD.operation_color<<"="<<RSTA<<" ";
		
		//STOP
		//cin.get();
		//cin.get();
		//--------------------------------------------------------------
		//Answer Loop:
		
		correct = false;
		//clear buffers...
		fflush(stdin);
		fflush(stdout);
		cin.clear();
		
		//time starts now:
		time_t sp_now = time(0);
		time_t timer_startThinking = sp_now;
	
	do{ //while not correct
		
	//Ask for answer string
	cin>>yourAnswerString;
	cin.get();
	//-------------------EVALUATING ANSWER--------------------------
	//If it is Number But not the right ANSWER:
	
		//OPTINONS:
		//Stop playing: (stop playing, goes back 1 sub menu.)
			if(yourAnswerString == "q" || yourAnswerString == "Q")
				{
						cout<<endl;
						cout<<setw(20)<<" "<<cD.menu_color2<<"Let's close this session then!"
							<<RSTA<<endl;
						sleep(1);
						
					//roundScore_V5 = 0;
					//obj.totalScoreInThisSession_setterFn_V5(roundScore_V5);
					//obj.goodAnswerStreek_initialiserFn_V5(0);
			cout<<"\n"
				<<"                  "<<cD.tryagain_color<<"Your total score from this session"<<RSTA<<" "
				<<BRIGHT<<obj.name_displayFn_V5()<<RSTA<<" is "
				<<cD.youranswer_color
				<<obj.totalScoreInThisSession_displayFn_V5()
				<<RSTA
				<<endl;
				
				//update...
				obj.totalRoundsPlayed_InThisSession_setterFn_V5(-1); // because we dont count the round you aborted!
				obj.totalRoundsPlayed_displayFn_V5();
				
				//obj.sP_lifesLost_allTime_setterFn_V5();
				//obj.sP_allTimeScore_setterFn_V5();
				//obj.sP_allTime_totalRoundsPlayed_setterFn_V5(obj.totalRoundsPlayed_displayFn_V5());
				obj.sP_newHighScoreInOneSession_setterFn_V5(obj.totalScoreInThisSession_displayFn_V5());
				obj.sP_longestPlayEver_setterFn_V5(obj.totalRoundsPlayed_displayFn_V5() ); // updates longest session record
				obj.sP_longestGoodAnswerStreakEver_setterFn_V5(obj.goodAnswerStreek_dispalyFn_V5());
				obj.sP_allTime_totalRoundsPlayed_setterFn_V5(obj.totalRoundsPlayed_displayFn_V5());
				obj.sP_allTimeScore_setterFn_V5(obj.totalScoreInThisSession_displayFn_V5());
				if(obj.sP_chosen_level_displayFn_V5() == 1){
					 obj.sP_allTime_easy_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
					 obj.sP_allTime_rounds_easy_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
				if(obj.sP_chosen_level_displayFn_V5() == 2){
					 obj.sP_allTime_normal_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
					 obj.sP_allTime_rounds_normal_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
				if(obj.sP_chosen_level_displayFn_V5() == 3){
					 obj.sP_allTime_expert_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
					 obj.sP_allTime_rounds_expert_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
				if(obj.sP_chosen_level_displayFn_V5() == 4){
					 obj.sP_allTime_master_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
					 obj.sP_allTime_rounds_master_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
				obj.sP_anyGoodAnswerGiven_allTimeFn_setter_V5(obj.sP_sessionGoodAnswerCounter_V5_displayFn()); // i = anyGoodAnswerGiven_lastSession_V5
				//obj.sP_longestGoodAnswerStreakEver_setterFn_V5(obj.goodAnswerStreek_dispalyFn_V5());
				obj.sP_lifesLost_allTime_setterFn_V5(obj.sP_lifesLost_inLastSession_displayFn_V5());
				obj.sP_attemptCounter_AllTime_setterFn_V5(obj.sP_attemptCounter_singleSession_displayFn_V5());
				obj.sP_sessionCounter_setterFn_V5(+1);
				//milestones update
						obj.sp_milestone_1_V5 = milestone_1_h;
						obj.sp_milestone_2_V5 = milestone_2_h;
						obj.sp_milestone_3_V5 = milestone_3_h;
						obj.sp_milestone_4_V5 = milestone_4_h;
						obj.sp_milestone_5_V5 = milestone_5_h;
						obj.sp_milestone_6_V5 = milestone_6_h;
						obj.sp_milestone_7_V5 = milestone_7_h;
						obj.sp_milestone_8_V5 = milestone_8_h;
						obj.sp_milestone_9_V5 = milestone_9_h;
						obj.sp_milestone_10_V5 = milestone_10_h;
						obj.sp_milestone_11_V5 = milestone_11_h;
						obj.sp_milestone_12_V5 = milestone_12_h;
						obj.sp_milestone_13_V5 = milestone_13_h;
						obj.sp_milestone_14_V5 = milestone_14_h;
						obj.sp_milestone_15_V5 = milestone_15_h;
						obj.sp_milestone_16_V5 = milestone_16_h;
						obj.sp_milestone_17_V5 = milestone_17_h;
						obj.sp_milestone_17andHalf_V5 = milestone_17andHalf_h;
						obj.sp_milestone_18_V5 = milestone_18_h;
						obj.sP_masterlevel_unlocked = masterSwitch_h;
						obj.milestone_5sec_easy_V5 = milestone_5sec_easy_dotH;
						obj.milestone_5sec_normal_V5 = milestone_5sec_normal_dotH;
						obj.milestone_5sec_expert_V5 = milestone_5sec_expert_dotH;
						obj.milestone_5sec_master_V5 = milestone_5sec_master_dotH;
						obj.milestone_3sec_easy_V5 = milestone_3sec_easy_dotH;
						obj.milestone_3sec_normal_V5 = milestone_3sec_normal_dotH;
						obj.milestone_3sec_expert_V5 = milestone_3sec_expert_dotH;
						obj.milestone_3sec_master_V5 = milestone_3sec_master_dotH;
						obj.milestone_1sec_easy_V5 = milestone_1sec_easy_dotH;
						obj.milestone_1sec_normal_V5 = milestone_1sec_normal_dotH;
						obj.milestone_1sec_expert_V5 = milestone_1sec_expert_dotH;
						obj.milestone_1sec_master_V5 = milestone_1sec_master_dotH;
				//To able to display statistics asign obj to PlayerObject
				sPlayersVector[sP_userSelected] = obj;
					whileInGameLoop = false;
					correct = true;
					break;
					}
		//--------------------------------------------------------------------------------
		// If SKIP:
		if(yourAnswerString == "s" || yourAnswerString == "S"){
			if(skipp  > 0){
			skipp = skipp -1;
			correct = true;
			break;}
			else{
				cout<<endl;
				cout<<"                     "<<cD.tryagain_color<<"NO MORE SKIPPING..."<<RSTA<<"\n\n"
					<<"              "<<"\33[1;32mANSWER\33[0m or \33[1;31mQUIT\33[0m, \33[1mPLEASE!"<<RSTA<<"\n"<<endl;
				continue;}}
		//---------------------------------------------------------------------------------
		
		
			// 2/2 - when your answer is NOT good 1-2 times:
			// attempts 1 - 3 and answer is no good:
			if(yourAnswerString != currentCorrectAnswerString) // if answer incorrect:
				{
				//increment attempts
				attempts_test = attempts_test + 1; 
				obj.sP_attemptCounter_singleSession_setterFn_V5(1);
				// minus one life
				//life_updater_var--;
				obj.lifes_setterFn_V5(- 1);
				obj.sP_lifesLost_inLastSession_setterFn_V5(); // each time it's invoked adds 1 more to total updates AllTime too
				//reset G.A.Streak
				obj.goodAnswerStreek_initialiserFn_V5(0);
				
				//-------------------
				if(attempts_test >3 && obj.lifes_displayFn_V5() == 0){
					
					cout<<RSTA<<"\n"
						<<setw(15)<<" "<<FRED_BWHITE<<"Oops... Nooooo! Well, this didn't go well! :)\n"<<RSTA
						<<endl;
						cout<<"                           "<<cD.tryagain_color<<"*** NO LIFES LEFT! ***"<<RSTA<<endl;
					sleep(1);
					cout<<RSTA;
					cout<<"\n"<<"                      "<<cD.menu_color1<<"The answer is:"<<RSTA<<" "<<cD.equation_color1<<rn1<<RSTA<<" "<<cD.operation_color<<operation<<RSTA<<" "<<cD.equation_color2<<rn2<<RSTA<<" "<<cD.operation_color<<"="<<RSTA<<" "<<cD.youranswer_color<<currentCanswer_display<<RSTA<<endl;
					cout<<endl;
					sleep(2);
					cout<<setw(17)<<FWHITEBOLD<<cD.itsnotanumber_color<<" But don't be sad! You got This! Just KEEP PRACTICING!"<<RSTA
						<<endl;
					cout<<endl;
					cout<<setw(14)<<BRIGHT<<obj.name_displayFn_V5()<<RSTA
						<<"\33[0m, your total score from this session is: "
						<<"\33[2;30;47m"
						<<obj.totalScoreInThisSession_displayFn_V5()
						<<RSTA<<"\n"
						<<endl;
				sleep(5);
				//for test Stop:
				cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
				cin.get();
				//cin.get();
				system("clear");
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<setw(35)<<" *** "<<FREDBOLD<<"\33[5mGAME OVER!\33[0m"<<RSTA<<" ***"<<endl;
						sleep(3);	 
						correct = true;
						//update vars
						//Just for test display asign obj ot testUserArra[0]
						obj.goodAnswerStreek_initialiserFn_V5(0);
						obj.sP_newHighScoreInOneSession_setterFn_V5(obj.totalScoreInThisSession_displayFn_V5());
						obj.sP_longestPlayEver_setterFn_V5(obj.totalRoundsPlayed_displayFn_V5()); // updates longest session record
						obj.sP_longestGoodAnswerStreakEver_setterFn_V5(obj.goodAnswerStreek_dispalyFn_V5());
						obj.sP_allTime_totalRoundsPlayed_setterFn_V5(obj.totalRoundsPlayed_displayFn_V5());
						obj.sP_allTimeScore_setterFn_V5(obj.totalScoreInThisSession_displayFn_V5());
						if(obj.sP_chosen_level_displayFn_V5() == 1){
							 obj.sP_allTime_easy_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
							 obj.sP_allTime_rounds_easy_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
						if(obj.sP_chosen_level_displayFn_V5() == 2){
							 obj.sP_allTime_normal_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
							 obj.sP_allTime_rounds_normal_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
						if(obj.sP_chosen_level_displayFn_V5() == 3){
							 obj.sP_allTime_expert_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
							 obj.sP_allTime_rounds_expert_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
						if(obj.sP_chosen_level_displayFn_V5() == 4){
							 obj.sP_allTime_master_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
							 obj.sP_allTime_rounds_master_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
						obj.sP_anyGoodAnswerGiven_allTimeFn_setter_V5(obj.sP_sessionGoodAnswerCounter_V5_displayFn()); // i = anyGoodAnswerGiven_lastSession_V5
						//obj.sP_longestGoodAnswerStreakEver_setterFn_V5(obj.goodAnswerStreek_dispalyFn_V5());
						obj.sP_lifesLost_allTime_setterFn_V5(obj.sP_lifesLost_inLastSession_displayFn_V5());
						obj.sP_attemptCounter_AllTime_setterFn_V5(obj.sP_attemptCounter_singleSession_displayFn_V5());
						obj.sP_sessionCounter_setterFn_V5(+1);
						//milestones update
						obj.sp_milestone_1_V5 = milestone_1_h;
						obj.sp_milestone_2_V5 = milestone_2_h;
						obj.sp_milestone_3_V5 = milestone_3_h;
						obj.sp_milestone_4_V5 = milestone_4_h;
						obj.sp_milestone_5_V5 = milestone_5_h;
						obj.sp_milestone_6_V5 = milestone_6_h;
						obj.sp_milestone_7_V5 = milestone_7_h;
						obj.sp_milestone_8_V5 = milestone_8_h;
						obj.sp_milestone_9_V5 = milestone_9_h;
						obj.sp_milestone_10_V5 = milestone_10_h;
						obj.sp_milestone_11_V5 = milestone_11_h;
						obj.sp_milestone_12_V5 = milestone_12_h;
						obj.sp_milestone_13_V5 = milestone_13_h;
						obj.sp_milestone_14_V5 = milestone_14_h;
						obj.sp_milestone_15_V5 = milestone_15_h;
						obj.sp_milestone_16_V5 = milestone_16_h;
						obj.sp_milestone_17_V5 = milestone_17_h;
						obj.sp_milestone_17andHalf_V5 = milestone_17andHalf_h;
						obj.sp_milestone_18_V5 = milestone_18_h;
						obj.sP_masterlevel_unlocked = masterSwitch_h;
						obj.milestone_5sec_easy_V5 = milestone_5sec_easy_dotH;
						obj.milestone_5sec_normal_V5 = milestone_5sec_normal_dotH;
						obj.milestone_5sec_expert_V5 = milestone_5sec_expert_dotH;
						obj.milestone_5sec_master_V5 = milestone_5sec_master_dotH;
						obj.milestone_3sec_easy_V5 = milestone_3sec_easy_dotH;
						obj.milestone_3sec_normal_V5 = milestone_3sec_normal_dotH;
						obj.milestone_3sec_expert_V5 = milestone_3sec_expert_dotH;
						obj.milestone_3sec_master_V5 = milestone_3sec_master_dotH;
						obj.milestone_1sec_easy_V5 = milestone_1sec_easy_dotH;
						obj.milestone_1sec_normal_V5 = milestone_1sec_normal_dotH;
						obj.milestone_1sec_expert_V5 = milestone_1sec_expert_dotH;
						obj.milestone_1sec_master_V5 = milestone_1sec_master_dotH;
						sPlayersVector[sP_userSelected] = obj;
							//obj.sP_lifesLost_allTime_setterFn_V5();
							//obj.sP_allTimeScore_setterFn_V5();
							//obj.sP_allTime_totalRoundsPlayed_setterFn_V5(obj.totalRoundsPlayed_displayFn_V5());
						
						
						//obj.lifes_test_initialiserFn(0);
						whileInGameLoop = false;
						
						break;
					}
			//---------------------------------------------------------------------------------------------
				else{
					
					//----------------------------------------------------------------------------	
					if(obj.lifes_displayFn_V5() <= 0){
						
						cout<<"\n                "<<cD.itsnotanumber_color<<"You are out of lifes...."<<RSTA<<"\n"<<endl;
						//cout<<"           "<<BRIGHT<<i<<RSTA<<"\n"<<endl;
						sleep(2);	
						cout<<setw(17)<<cD.menu_color2<<" But don't be sad! You got This! Just KEEP PRACTICING!"<<RSTA
							<<endl;
						cout<<endl;
						cout<<setw(14)<<BRIGHT<<obj.name_displayFn_V5()<<RSTA
							<<"\33[0m, your total score from this session is: "
							<<"\33[2;30;47m"
							<<obj.totalScoreInThisSession_displayFn_V5()
							<<RSTA          
							<<endl;
							for(int i = 0; i > 2; i++){
						cout<<".";
						fflush(stdout);
						sleep(1);}
						
					system("clear");
					
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<endl;
						cout<<setw(35)<<" *** "<<FREDBOLD<<"\33[5mGAME OVER!\33[0m"<<RSTA<<" ***"<<endl;
				sleep(3);
						//for test Stop:
						cout<<"(Press \33[1mENTER\33[0m to continue..."<<endl;
						cin.get();
						
								
							 
						correct = true;
						whileInGameLoop = false;
						obj.totalRoundsPlayed_InThisSession_setterFn_V5(-1);
						//obj.sP_allTimeScore_setterFn_V5();
						
						//obj.sP_lifesLost_allTime_setterFn_V5();
						obj.sP_newHighScoreInOneSession_setterFn_V5(obj.totalScoreInThisSession_displayFn_V5());
						obj.sP_allTimeScore_setterFn_V5(obj.totalScoreInThisSession_displayFn_V5());
						if(obj.sP_chosen_level_displayFn_V5() == 1){
							 obj.sP_allTime_easy_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
							 obj.sP_allTime_rounds_easy_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
						if(obj.sP_chosen_level_displayFn_V5() == 2){
							 obj.sP_allTime_normal_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
							 obj.sP_allTime_rounds_normal_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
						if(obj.sP_chosen_level_displayFn_V5() == 3){
							 obj.sP_allTime_expert_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
							 obj.sP_allTime_rounds_expert_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
						if(obj.sP_chosen_level_displayFn_V5() == 4){ 
							obj.sP_allTime_master_score_updateFn_V5(obj.totalScoreInThisSession_displayFn_V5());
							obj.sP_allTime_rounds_master_updateFn_V5(obj.totalRoundsPlayed_displayFn_V5());}
						obj.sP_longestPlayEver_setterFn_V5(obj.totalRoundsPlayed_displayFn_V5()); // updates longest session record
						obj.sP_longestGoodAnswerStreakEver_setterFn_V5(obj.goodAnswerStreek_dispalyFn_V5());
						obj.sP_allTime_totalRoundsPlayed_setterFn_V5(obj.totalRoundsPlayed_displayFn_V5());
						obj.sP_anyGoodAnswerGiven_allTimeFn_setter_V5(obj.sP_sessionGoodAnswerCounter_V5_displayFn()); // i = anyGoodAnswerGiven_lastSession_V5
						obj.sP_lifesLost_allTime_setterFn_V5(obj.sP_lifesLost_inLastSession_displayFn_V5()); // ()lost life in session
						obj.sP_attemptCounter_AllTime_setterFn_V5(obj.sP_attemptCounter_singleSession_displayFn_V5()); // i = attempts_counterForStatistic_singleSession_V5
						obj.sP_sessionCounter_setterFn_V5(+1);
						//milestones update
						obj.sp_milestone_1_V5 = milestone_1_h;
						obj.sp_milestone_2_V5 = milestone_2_h;
						obj.sp_milestone_3_V5 = milestone_3_h;
						obj.sp_milestone_4_V5 = milestone_4_h;
						obj.sp_milestone_5_V5 = milestone_5_h;
						obj.sp_milestone_6_V5 = milestone_6_h;
						obj.sp_milestone_7_V5 = milestone_7_h;
						obj.sp_milestone_8_V5 = milestone_8_h;
						obj.sp_milestone_9_V5 = milestone_9_h;
						obj.sp_milestone_10_V5 = milestone_10_h;
						obj.sp_milestone_11_V5 = milestone_11_h;
						obj.sp_milestone_12_V5 = milestone_12_h;
						obj.sp_milestone_13_V5 = milestone_13_h;
						obj.sp_milestone_14_V5 = milestone_14_h;
						obj.sp_milestone_15_V5 = milestone_15_h;
						obj.sp_milestone_16_V5 = milestone_16_h;
						obj.sp_milestone_17_V5 = milestone_17_h;
						obj.sp_milestone_17andHalf_V5 = milestone_17andHalf_h;
						obj.sp_milestone_18_V5 = milestone_18_h;
						obj.sP_masterlevel_unlocked = masterSwitch_h;
						obj.milestone_5sec_easy_V5 = milestone_5sec_easy_dotH;
						obj.milestone_5sec_normal_V5 = milestone_5sec_normal_dotH;
						obj.milestone_5sec_expert_V5 = milestone_5sec_expert_dotH;
						obj.milestone_5sec_master_V5 = milestone_5sec_master_dotH;
						obj.milestone_3sec_easy_V5 = milestone_3sec_easy_dotH;
						obj.milestone_3sec_normal_V5 = milestone_3sec_normal_dotH;
						obj.milestone_3sec_expert_V5 = milestone_3sec_expert_dotH;
						obj.milestone_3sec_master_V5 = milestone_3sec_master_dotH;
						obj.milestone_1sec_easy_V5 = milestone_1sec_easy_dotH;
						obj.milestone_1sec_normal_V5 = milestone_1sec_normal_dotH;
						obj.milestone_1sec_expert_V5 = milestone_1sec_expert_dotH;
						obj.milestone_1sec_master_V5 = milestone_1sec_master_dotH;
						//To able to display statistics asign obj to PlayerObject
						userSelectorFn_V5(sP_userSelected) = obj;
							
						//obj.goodAnswerStreek_initialiserFn_V5(0);
						//obj.sP_lifes_V5_initialiserFn(3);
						//inGame = false;
						system("clear");
						break;
						}	
					cout<<RSTA<<"\n"
						<<setw(20)<<" "<<cD.tryagain_color<<"Oops... Nooooo! Please try again!"<<RSTA<<"\n"<<RSTA
						<<endl;
					sleep(1);
					
					
					//clear screen and reload equation with updated life display
					system("clear");
					//--------------------------------------------------------------
		cout<<endl;			
		cout<<"           "<<RSTA<<cD.menu_color1<<"Level: "<<RSTA<<difficulty_message<<RSTA<<endl;
		cout<<"           "<<cD.keret_color<<"****************************************************"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"                                                    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"      "<<ULINE<<"NOTE:"<<RSTA<<" "<<cD.menu_color1<<"If there is a division equation,"<<RSTA<<"      "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"    "<<cD.menu_color1<<"please round up your answer to 2 decimals!"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"      (\33[3m"<<cD.menu_color2<<"Unless the result is whole number."<<RSTA<<")        "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<RSTA<<"           "<<cD.keret_color<<"*"<<RSTA<<"                                                  "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"   "<<cD.menu_color1<<"Enter"<<RSTA<<" \33[1m'q'\33[0m "<<cD.menu_color1<<"or"<<RSTA<<" \33[1m'Q'\33[0m "<<cD.menu_color1<<"as an answer if you'd like"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"                      "<<cD.menu_color1<<"to"<<RSTA<<" "<<cD.menu_color2<<"QUIT."<<RSTA<<"                    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"   "<<cD.menu_color1<<"Enter"<<RSTA<<" "<<BRIGHT<<"'s'"<<RSTA<<" "<<cD.menu_color1<<"or"<<RSTA<<" "<<BRIGHT<<"'S'"
			<<RSTA<<" "<<cD.menu_color1<<"as an answer if you'd like"<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"                 "<<cD.menu_color1<<"to"<<RSTA<<" "<<cD.menu_color2<<"SKIP"<<RSTA<<" "<<cD.menu_color1<<"the equation."<<RSTA<<"            "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"*"<<RSTA<<"     (\33[1mG.A.S.\33[0m -> "<<cD.menu_color1<<"stands for good answer streak"<<RSTA<<")    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"           "<<cD.keret_color<<"****************************************************"<<RSTA<<"\n"
		<<endl;
		//----------------------------------------------------------------------------------------------
		cout<<"           "<<cD.menu_color1<<"PLAYER:"<<RSTA<<" "<<cD.menu_color2<<obj.name_displayFn_V5()<<RSTA
			<<"     "<<cD.menu_color1<<"SESSION'S SCORE:"<<RSTA<<" "<<cD.menu_color2<<obj.totalScoreInThisSession_displayFn_V5()<<RSTA
			<<"       "<<cD.menu_color1<<"ROUND:"<<RSTA<<" "<<BRIGHT<<cD.menu_color2<<obj.totalRoundsPlayed_displayFn_V5()<<RSTA<<"\n"<<endl;
		cout<<"           "<<cD.menu_color1<<"LIFE LEFT:"<<RSTA<<" "<<cD.menu_color2<<obj.lifes_displayFn_V5()<<RSTA; // load from save file if > 3
		cout<<"       "<<cD.menu_color1<<"G.A.S.:"<<RSTA<<" "<<cD.menu_color2<<obj.goodAnswerStreek_dispalyFn_V5()<<RSTA
			<<"       "<<cD.menu_color1<<"SKIPS left:"<<RSTA<<" "<<cD.menu_color2<<skipp<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"--------------------------------------------------------------------"<<RSTA<<"\n"
				<<endl;	
		cout<<setw(26)<<cD.equattionText_color<<"EQUATION:"<<RSTA<<" "<<cD.equation_color1<<rn1<<RSTA<<" "<<cD.operation_color<<operation<<RSTA<<" "<<cD.equation_color2<<rn2<<RSTA<<" "<<cD.operation_color<<"="<<RSTA<<" ";
		
					continue;
					}	
				
				}
		//-----------------------------------------------------------------------------
			// 1/2 - if your Answer is good:
			else if(yourAnswerString == currentCorrectAnswerString) 
			{
				//timer stop point // answered
				time_t sp_answerTimer_endPoint = time(0);
				//Calculate passed seconds: (now_timePoint - past_timePoint)
				double secsPassed = difftime(sp_answerTimer_endPoint, timer_startThinking = sp_now); // bigger - smaller
				//save value
				obj.sp_updatePassedTimeVarsFn_V5(secsPassed);
				obj.check_time_spent_to_give_goodAnswer_quickestAndSlowestFn_V5(secsPassed);
			
			cout<<endl;
			cout<<"     "<<cD.keret_color<<"--------------------------------------------------------------------"<<RSTA<<"\n"
				<<endl;
			cout<<"          "<<cD.smily_color<<":)"<<RSTA<<"  "<<cD.yes_color<<"YES"<<RSTA
				<<"     "<<BRIGHT<<"The answer is:"<<RSTA<<" "<<cD.equation_color1<<rn1<<RSTA<<" "<<cD.operation_color<<operation<<RSTA<<" "<<cD.equation_color2<<rn2<<RSTA<<" "<<cD.operation_color<<"="<<RSTA<<" "<<cD.youranswer_color<<yourAnswerString<<RSTA
				<<"     "<<cD.yes_color<<"YES"<<RSTA<<"  "<<cD.smily_color<<":)"<<RSTA
				<<"\n"<<endl;
			cout<<"                         Answerd in: "<<BRIGHT<<secsPassed<<"s\n"<<endl;
			sleep(2);
			//update good answer streak
			gAnsInRowCounter++;
			obj.goodAnswerStreek_setterFn_V5();
			obj.sP_attemptCounter_singleSession_setterFn_V5(1);
			obj.sP_sessionGoodAnswerCounter_setterFn_V5(); // invoke when good answer...
			//-----------------------------------------------------------------------
			
			if(obj.sP_chosen_level_displayFn_V5() == 1){
			//if you answered in less or = to 5 sec | On EASY diff
			if(secsPassed <= 5){
				
				// <= 1 sec
				if(!obj.milestone_1sec_easy_V5){milestone_givingGood_Ans_in_less_then_1_easy_Fn(secsPassed);}
				// < =3 sec
				if(!obj.milestone_3sec_easy_V5){milestone_givingGood_Ans_in_less_then_3_easy_Fn(secsPassed);}
				// <= 5 sec
				if(!obj.milestone_5sec_easy_V5){milestone_givingGood_Ans_in_less_then_5_easy_Fn(secsPassed);}
				
				//check: Does it play all 3 if you answer in less then a sec? (and the others still locked too)

				}
			}
			//--------------------------------------------------------------------------------------
			
			if(obj.sP_chosen_level_displayFn_V5() == 2){
			//if you answered in less or = to 5 sec | On NORMAL diff
			if(secsPassed <= 5){
				
				// <= 1 sec
				if(!obj.milestone_1sec_normal_V5){milestone_givingGood_Ans_in_less_then_1_normal_Fn(secsPassed);}
				// < =3 sec
				if(!obj.milestone_3sec_normal_V5){milestone_givingGood_Ans_in_less_then_3_normal_Fn(secsPassed);}
				// <= 5 sec
				if(!obj.milestone_5sec_normal_V5){milestone_givingGood_Ans_in_less_then_5_normal_Fn(secsPassed);}
				
				//check: Does it play all 3 if you answer in less then a sec? (and the others still locked too)

				}
			}
			//--------------------------------------------------------------------------------------
			
			if(obj.sP_chosen_level_displayFn_V5() == 3){
			//if you answered in less or = to 5 sec | On EXPERT diff
			if(secsPassed <= 5){
				
				// <= 1 sec
				if(!obj.milestone_1sec_expert_V5){milestone_givingGood_Ans_in_less_then_1_expert_Fn(secsPassed);}
				// < =3 sec
				if(!obj.milestone_3sec_expert_V5){milestone_givingGood_Ans_in_less_then_3_expert_Fn(secsPassed);}
				// <= 5 sec
				if(!obj.milestone_5sec_expert_V5){milestone_givingGood_Ans_in_less_then_5_expert_Fn(secsPassed);}
				
				//check: Does it play all 3 if you answer in less then a sec? (and the others still locked too)

				}
			}
			//--------------------------------------------------------------------------------------
			
			if(obj.sP_chosen_level_displayFn_V5() == 4){
			//if you answered in less or = to 5 sec | On MASTER diff
			if(secsPassed <= 5){
				
				// <= 1 sec
				if(!obj.milestone_1sec_master_V5){milestone_givingGood_Ans_in_less_then_1_master_Fn(secsPassed);}
				// < =3 sec
				if(!obj.milestone_3sec_master_V5){milestone_givingGood_Ans_in_less_then_3_master_Fn(secsPassed);}
				// <= 5 sec
				if(!obj.milestone_5sec_master_V5){milestone_givingGood_Ans_in_less_then_5_master_Fn(secsPassed);}
				
				//check: Does it play all 3 if you answer in less then a sec? (and the others still locked too)

				}
			}
			//--------------------------------------------------------------------------------------

				
				
			//add an extra life after every 3 G.Answer in a row
			//Milestone Fns:  *** ADD HERE ALL ***
		// 1;
		if(obj.goodAnswerStreek_dispalyFn_V5() == 3 && milestone_extraLifeFor_3inRow){
		milestone_extraLifeFor_3inRowFn(obj.goodAnswerStreek_dispalyFn_V5());
		//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
		// adds physiquly + 1 life
		obj.lifes_setterFn_V5(+1); // works with +1
		// updates obj.
		sPlayersVector[sP_userSelected] = obj;
		/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		
		// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(prev_lives_V5 == 4 && obj.lifes_displayFn_V5() == 5){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(prev_lives_V5 == 9 && obj.lifes_displayFn_V5() == 10){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
		
	}
		//-----------------------------------------
		// 2;    After 5 in a row correct answers: Message pop up, plus 1 extra life.
		if(obj.goodAnswerStreek_dispalyFn_V5() == 5 && milestone_extraLifeFor_5inRow){
		milestone_extraLifeFor_5inRowFn(obj.goodAnswerStreek_dispalyFn_V5());
		//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
		// adds physiquly + 1 life
		obj.lifes_setterFn_V5(+1); // works with +1
		// updates obj.
		sPlayersVector[sP_userSelected] = obj;
		/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		
		// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(prev_lives_V5 == 4 && obj.lifes_displayFn_V5() == 5){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(prev_lives_V5 == 9 && obj.lifes_displayFn_V5() == 10){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
	}
		//------------------------------------------------------------------------------------
		
		// 3; 10 in a row G.A.S.
		if(obj.goodAnswerStreek_dispalyFn_V5() == 10 && milestone_extraLifeFor_10inRow){
		milestone_extraLifeFor_10inRowFn(obj.goodAnswerStreek_dispalyFn_V5());
		//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
		obj.lifes_setterFn_V5(+2); // "else" so it doesn't add an other 2 lifes after one of the if was invoked...
		// updates obj.
		sPlayersVector[sP_userSelected] = obj;
		//------------------------------
			// Milestone displayed if achived:
			// 5; If you reach 5 lifes 
			if((obj.lifes_displayFn_V5() == 5 || obj.lifes_displayFn_V5() == 6) && milestone_reaching5_lifes){
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			// updates obj.
			sPlayersVector[sP_userSelected] = obj;
					milestone_reaching5_lifesFn(5);
					// adds physiquly + 1 life
					obj.lifes_setterFn_V5(+1); // works with +1
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					/*
					//test:
					// display if update done:
					cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
					cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
					cout<<"Press ENTER to continue..."<<endl;
					cin.get();
					*/
					cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
					cin.get(); 
				}
			//----------------------------
			// 6; Reaching 10 lifes
			if((obj.lifes_displayFn_V5() == 10 || obj.lifes_displayFn_V5() == 11) && milestone_reaching10_lifes){
			//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
			// updates obj.
			sPlayersVector[sP_userSelected] = obj;
					milestone_reaching10_lifesFn(10);
					// adds physiquly + 2 life
					obj.lifes_setterFn_V5(+2); 
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					/*
					//test:
					// display if update done:
					cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
					cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
					cout<<"Press ENTER to continue..."<<endl;
					cin.get();
					*/
					cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
					cin.get();
				}
		//--------------------------------------------------------------
		// adds physiquly + 2 life
		
		/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/ 
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		}
		//-------------------------------------------------------------------------------
		// 13; 50 G.A.S. that's 50 in a row
		
		if(obj.goodAnswerStreek_dispalyFn_V5() == 50 && milestone_extraLifeFor_50inRow){
		milestone_extraLifeFor_50inRowFn(obj.goodAnswerStreek_dispalyFn_V5());
		// count & sets the amount of milestones are unlocked
		//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
		// adds physiquly + 3 life
		obj.lifes_setterFn_V5(+3);
		// updates obj.
		sPlayersVector[sP_userSelected] = obj;
		
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		
		//Add the life related achivements here too...
				// Milestone displayed if achived:
					// 5; If you reach 5 lifes 
					if((obj.lifes_displayFn_V5() >= 5 && obj.lifes_displayFn_V5() <=7) && milestone_reaching5_lifes){
								
								
								milestone_reaching5_lifesFn(5);
								// adds physiquly + 1 life
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.lifes_setterFn_V5(+1); // works with +1
								// updates obj.
								sPlayersVector[sP_userSelected] = obj;
								/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
										
					//-----------------------------------------------------------------------------------------------------
					// 6; Reaching 10 lifes
						if((obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <=12) && milestone_reaching10_lifes){
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
						// updates obj.
								milestone_reaching10_lifesFn(10);
								// adds physiquly + 2 life
								obj.lifes_setterFn_V5(+2); 
								// updates obj.
								sPlayersVector[sP_userSelected] = obj;
								/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
		
		}
		//-------------------------------------------------------------------------------
		
			
			
			correct = true;
			//inGame = true;
			whileInGameLoop = true;
		
			fflush(stdin); //does Not clear the "Enter" input...
			
			break;
			}
		//--------------------------------------------------------------	
        
		fflush(stdin); //does Not clear the "Enter" input...
		
	}while(!correct);//END of EVALUATION

	
	if(yourAnswerString == "q" || yourAnswerString == "Q" || yourAnswerString == "s" || yourAnswerString == "S"){roundScore_V5 = 0;
		obj.totalScoreInThisSession_setterFn_V5(roundScore_V5);
		sPlayersVector[sP_userSelected] = obj;}
		
	else if(yourAnswerString!= "q" || yourAnswerString != "Q" || yourAnswerString != "s" || yourAnswerString != "S" || attempts_test <= 3)
			{
	//-------------------------------------------------------------------------------
	//--------------------SCORING-----------------------------------
				if(obj.sP_chosen_level_displayFn_V5() == 1){roundScore_V5= 10;}
				if(obj.sP_chosen_level_displayFn_V5() == 2){roundScore_V5= 20;}
				if(obj.sP_chosen_level_displayFn_V5() == 3){roundScore_V5= 30;}
				if(obj.sP_chosen_level_displayFn_V5() == 4){roundScore_V5= 100;}
				
				
		// If you had a good answer attempt doesn't count.
		// Score deduced after each attempt
		
		if(attempts_test == 1 && obj.lifes_displayFn_V5() > 0)
				{
				obj.totalScoreInThisSession_setterFn_V5(roundScore_V5);
				//obj.sP_allTimeScore_setterFn_V5();
				//obj.sP_attemptCounter_singleSession_setterFn_V5(1);
								
				cout<<endl
					<<"\n"
					<<setw(20)<<BRIGHT<<obj.name_displayFn_V5()<<RSTA<<", "
					<<"\33[0myour total score is : "
					<<"\33[2;30;47m"
					<<obj.totalScoreInThisSession_displayFn_V5()
					<<RSTA
					<<endl;
					//Milestone message pop up if score reach milestone....
				// 4; Reaching 100 score in one session: Message Pop Up, plus 1 extra life.
				if(obj.totalScoreInThisSession_displayFn_V5() >= 100 && milestone_reaching_100_ScoreInSingleSession){
					milestone_reaching100ScoreInSingleSessionFn(obj.totalScoreInThisSession_displayFn_V5());
					// adds physiquly + 1 life
					obj.lifes_setterFn_V5(+1); // works with +1
					//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					
					/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		
		
					//Add the life related achivements here too...
				// Milestone displayed if achived:
					// 5; If you reach 5 lifes 
					if((obj.lifes_displayFn_V5() == 5) && prev_lives_V5 == 4 && milestone_reaching5_lifes){
								
								
								milestone_reaching5_lifesFn(5);
								// adds physiquly + 1 life
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.lifes_setterFn_V5(+1); // works with +1
								// updates obj.
								sPlayersVector[sP_userSelected] = obj;
								/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
										
					//-----------------------------------------------------------------------------------------------------
					// 6; Reaching 10 lifes
						if((obj.lifes_displayFn_V5() == 10) && prev_lives_V5 == 9 && milestone_reaching10_lifes){
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
						// updates obj.
								milestone_reaching10_lifesFn(10);
								// adds physiquly + 2 life
								obj.lifes_setterFn_V5(+2); 
								// updates obj.
								sPlayersVector[sP_userSelected] = obj;
								/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
		
		
				}
			//-----------------------------------------------------
			// 7; Reaching 1000 score in a single session milestone
			if(obj.totalScoreInThisSession_displayFn_V5() >= 1000 && milestone_reaching1000_ScoreInSingleSession){
					milestone_reaching1000_ScoreInSingleSessionFn(obj.totalScoreInThisSession_displayFn_V5());
					//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
					// updates obj.
					
					obj.lifes_setterFn_V5(+3);
					sPlayersVector[sP_userSelected] = obj;
					/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				//Add the life related achivements here too...
				// Milestone displayed if achived:
					// 5; If you reach 5 lifes 
					if((obj.lifes_displayFn_V5() >= 5 && obj.lifes_displayFn_V5() <=7) && milestone_reaching5_lifes){
								
								
								milestone_reaching5_lifesFn(5);
								// adds physiquly + 1 life
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.lifes_setterFn_V5(+1); // works with +1
								// updates obj.
								sPlayersVector[sP_userSelected] = obj;
								/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
										
					//-----------------------------------------------------------------------------------------------------
					// 6; Reaching 10 lifes
						if((obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <=12) && milestone_reaching10_lifes){
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
						// updates obj.
								milestone_reaching10_lifesFn(10);
								// adds physiquly + 2 life
								obj.lifes_setterFn_V5(+2); 
								// updates obj.
								sPlayersVector[sP_userSelected] = obj;
								/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
					//-----------------------------------------------------
				
				// else ?
				
				/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				}
			//-----------------------------------------------------
			// 8; Reaching 5000 score in a single session...
						if(obj.totalScoreInThisSession_displayFn_V5() >= 5000 && milestone_reaching5000_ScoreInSingleSession){ // reset bool var before session starts
							milestone_reaching5000_ScoreInSingleSessionFn(obj.totalScoreInThisSession_displayFn_V5());
							// adds physiquly + 5 life
							obj.lifes_setterFn_V5(+5); //
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
							// updates obj.
							sPlayersVector[sP_userSelected] = obj;
							/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.lifes_displayFn_V5() >= 6 && obj.lifes_displayFn_V5() <= 9){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								obj.lifes_setterFn_V5(+1);
								sPlayersVector[sP_userSelected] = obj;
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								}
							//----------------------------------------------------------------
							if(obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 14){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								obj.lifes_setterFn_V5(+2);
								sPlayersVector[sP_userSelected] = obj;
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								}	
					}
			//---------------------------------------------------------------------------------------------------------		
			//12; Challenge Inpossible: 1000 Score in 100 rounds. add extra 3 lifes (Answerstreak 100)
			if(obj.totalScoreInThisSession_displayFn_V5() >= 1000 &&
				obj.totalRoundsPlayed_displayFn_V5() <= 100 && milestone_reaching_1000Score_in100Rounds){
				milestone_reaching_1000Score_in100RoundsFn(obj.totalScoreInThisSession_displayFn_V5(), obj.totalRoundsPlayed_displayFn_V5());
				// add + 3 lifes
				obj.lifes_setterFn_V5(+3);
				//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
				// updates obj.
				sPlayersVector[sP_userSelected] = obj;
				
				// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.lifes_displayFn_V5() >= 5 && obj.lifes_displayFn_V5() <= 7){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								obj.lifes_setterFn_V5(+1);
								sPlayersVector[sP_userSelected] = obj;
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								}
							//----------------------------------------------------------------
							if(obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 12){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								obj.lifes_setterFn_V5(+2);
								sPlayersVector[sP_userSelected] = obj;
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								}	
				
			}
			//-----------------------------------------------------------------------------------------
			//17; Challenge impossible 2: 10000(ten tousend) Score in a single session
					if(obj.totalScoreInThisSession_displayFn_V5() >= 10000 && milestone_reaching10000_ScoreInSingleSession){ // reset bool var before session starts
							milestone_reaching10000_ScoreInSingleSessionFn(obj.totalScoreInThisSession_displayFn_V5());
							// adds physiquly + 5 life
							obj.lifes_setterFn_V5(+5); //
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
							// updates obj.
							sPlayersVector[sP_userSelected] = obj;
							/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.lifes_displayFn_V5() >= 6 && obj.lifes_displayFn_V5() <= 9){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								obj.lifes_setterFn_V5(+1);
								sPlayersVector[sP_userSelected] = obj;
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								}
							//----------------------------------------------------------------
							if(obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 14){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								obj.lifes_setterFn_V5(+2);
								sPlayersVector[sP_userSelected] = obj;
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								}	
					}
					
					
					//-----------------------------------------------------------------------------------------------------
			// 17.5 reach 100 000 score all time (+7 lifes) 
					if((obj.sP_allTimeScore_displayFn_V5() + obj.totalScoreInThisSession_displayFn_V5()) >= 100000 && milestone_reaching100000_AllTimeScore){ // reset session bool var(not Alltime) before session starts
							milestone_reaching100000_AllTimeScoreFn(100000);
							//milestone count updater:
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
							// adds physiquly + 7 life
							obj.lifes_setterFn_V5(+7); //
							// updates obj.
							sPlayersVector[sP_userSelected] = obj;
							/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.lifes_displayFn_V5() >= 8 && obj.lifes_displayFn_V5() <= 11){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								obj.lifes_setterFn_V5(+1);
								sPlayersVector[sP_userSelected] = obj;
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								}
							//----------------------------------------------------------------
							if(obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 16){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								obj.lifes_setterFn_V5(+2);
								sPlayersVector[sP_userSelected] = obj;
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								}	
						}		
					//--------------------------------------------------------------------------------------------
			//18; mission impossible: If you reach 1 000 000 *** !!! -AllTimescore- !!! *** (+10 lifes)
					if((obj.sP_allTimeScore_displayFn_V5() + obj.totalScoreInThisSession_displayFn_V5()) >= 1000000 && milestone_reaching1000000_AllTimeScore){ // reset bool var before session starts
							milestone_reaching1000000_AllTimeScoreFn(1000000);
							//milestone count updater:
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
							// adds physiquly + 5 life
							obj.lifes_setterFn_V5(+10); //
							// updates obj.
							sPlayersVector[sP_userSelected] = obj;
							/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
							if(obj.lifes_displayFn_V5() >= 11 && obj.lifes_displayFn_V5() <= 14){
								// means you reached 5 lifes milestone too...
								milestone_reaching5_lifesFn(5);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.lifes_setterFn_V5(+1);
								sPlayersVector[sP_userSelected] = obj;
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								}
							//----------------------------------------------------------------
							if(obj.lifes_displayFn_V5() >= 11 && obj.lifes_displayFn_V5() <= 19){
								// means you reacged 10 life milestone too...
								milestone_reaching10_lifesFn(10);
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.lifes_setterFn_V5(+2);
								sPlayersVector[sP_userSelected] = obj;
								cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
								cin.get();
								}	
								
					}
				//-----------------------------------------------------------------------------------------------------	
				//for test Stop:
				/*
						cout<<"attempt 1 invoked (Press ENTER TO CONTINUE)"<<endl;
						cin.get();
						cin.get();
						*/
				}
			//------------------------------------------------------------------------------	
		if(attempts_test == 2 && obj.lifes_displayFn_V5() > 0)
				{
				if(easySwitch){roundScore_V5= 3;}
				if(expertSwitch){roundScore_V5= 16;}
				else{roundScore_V5= 8;}
				obj.totalScoreInThisSession_setterFn_V5(roundScore_V5);
				//obj.sP_allTimeScore_setterFn_V5();
				//obj.sP_attemptCounter_singleSession_setterFn_V5(2);
			cout<<endl
				<<"\n"
				<<setw(20)<<BRIGHT<<obj.name_displayFn_V5()<<RSTA<<", "
				<<"\33[0myour total score is : "
				<<"\33[2;30;47m"
				<<obj.totalScoreInThisSession_displayFn_V5()
				<<RSTA
				<<endl;
				//Milestone message pop up if score reach milestone....
				// 4; Reaching 100 score in one session: Message Pop Up, plus 1 extra life.
				if(obj.totalScoreInThisSession_displayFn_V5() >= 100 && milestone_reaching_100_ScoreInSingleSession){
					milestone_reaching100ScoreInSingleSessionFn(obj.totalScoreInThisSession_displayFn_V5());
					// adds physiquly + 1 life
					obj.lifes_setterFn_V5(+1); // works with +1
					//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		
					//Add the life related achivements here too...
				// Milestone displayed if achived:
					// 5; If you reach 5 lifes 
					if((obj.lifes_displayFn_V5() == 5) && milestone_reaching5_lifes){
								
								milestone_reaching5_lifesFn(5);
								// adds physiquly + 1 life
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.lifes_setterFn_V5(+1); // works with +1
								// updates obj.
								sPlayersVector[sP_userSelected] = obj;
								/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
										
					//-----------------------------------------------------------------------------------------------------
					// 6; Reaching 10 lifes
						if((obj.lifes_displayFn_V5() == 10) && milestone_reaching10_lifes){
							
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
						// updates obj.
						sPlayersVector[sP_userSelected] = obj;
								milestone_reaching10_lifesFn(10);
								// adds physiquly + 2 life
								obj.lifes_setterFn_V5(+2); 
								// updates obj.
								sPlayersVector[sP_userSelected] = obj;
								/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
		
				}
			//-----------------------------------------------------
			// 7; Reaching 1000 score in a single session milestone
			if(obj.totalScoreInThisSession_displayFn_V5() >= 1000 && milestone_reaching1000_ScoreInSingleSession){
					milestone_reaching1000_ScoreInSingleSessionFn(obj.totalScoreInThisSession_displayFn_V5());
					//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
					// updates obj.
					obj.lifes_setterFn_V5(+3);
					sPlayersVector[sP_userSelected] = obj;
					/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				//Add the life related achivements here too...
				// Milestone displayed if achived:
					// 5; If you reach 5 lifes 
					if((obj.lifes_displayFn_V5() >= 5 && obj.lifes_displayFn_V5() <=7) && milestone_reaching5_lifes){
								
								milestone_reaching5_lifesFn(5);
								// adds physiquly + 1 life
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.lifes_setterFn_V5(+1); // works with +1
								// updates obj.
								sPlayersVector[sP_userSelected] = obj;
								/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
										
					//-----------------------------------------------------------------------------------------------------
					// 6; Reaching 10 lifes
						if((obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <=12) && milestone_reaching10_lifes){
							
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
						// updates obj.
						sPlayersVector[sP_userSelected] = obj;
								milestone_reaching10_lifesFn(10);
								// adds physiquly + 2 life
								obj.lifes_setterFn_V5(+2); 
								// updates obj.
								sPlayersVector[sP_userSelected] = obj;
								/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
					//-----------------------------------------------------
				
				//else ?
				
				/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				}
			//-----------------------------------------------------
			// 8; Reaching 5000 score in a single session...
						if(obj.totalScoreInThisSession_displayFn_V5() >= 5000 && milestone_reaching5000_ScoreInSingleSession){ // reset bool var before session starts
							milestone_reaching5000_ScoreInSingleSessionFn(obj.totalScoreInThisSession_displayFn_V5());
							// adds physiquly + 5 life
							obj.lifes_setterFn_V5(+5); //
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
							// updates obj.
							sPlayersVector[sP_userSelected] = obj;
							/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(obj.lifes_displayFn_V5() >= 6 && obj.lifes_displayFn_V5() <= 9){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 14){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}	
					}
				
			//---------------------------------------------------------------------------------------------------------		
			//12; Challenge Inpossible: 1000 Score in 100 rounds. add extra 3 lifes (Answerstreak 100)
			if(obj.totalScoreInThisSession_displayFn_V5() >= 1000 &&
				obj.totalRoundsPlayed_displayFn_V5() <= 100 && milestone_reaching_1000Score_in100Rounds){
				milestone_reaching_1000Score_in100RoundsFn(obj.totalScoreInThisSession_displayFn_V5(), obj.totalRoundsPlayed_displayFn_V5());
				// add + 3 lifes
				obj.lifes_setterFn_V5(+3);
				//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
				// updates obj.
				sPlayersVector[sP_userSelected] = obj;
					
					// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(obj.lifes_displayFn_V5() >= 5 && obj.lifes_displayFn_V5() <= 7){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 12){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
			
			
			}
			//-----------------------------------------------------------------------------------------
			//17; Challenge impossible 2: 10000(ten tousend) Score in a single session
					if(obj.totalScoreInThisSession_displayFn_V5() >= 10000 && milestone_reaching10000_ScoreInSingleSession){ // reset bool var before session starts
							milestone_reaching10000_ScoreInSingleSessionFn(obj.totalScoreInThisSession_displayFn_V5());
							// adds physiquly + 5 life
							obj.lifes_setterFn_V5(+5); //
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
							// updates obj.
							sPlayersVector[sP_userSelected] = obj;
							/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(obj.lifes_displayFn_V5() >= 6 && obj.lifes_displayFn_V5() <= 9){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 14){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
					}
					
					
					//-----------------------------------------------------------------------------------------------------
			// 17.5 reach 100 000 score all time (+7 lifes) 
					if((obj.sP_allTimeScore_displayFn_V5() + obj.totalScoreInThisSession_displayFn_V5()) >= 100000 && milestone_reaching100000_AllTimeScore){ // reset session bool var(not Alltime) before session starts
							milestone_reaching100000_AllTimeScoreFn(100000);
							//milestone count updater:
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
							// adds physiquly + 7 life
							obj.lifes_setterFn_V5(+7); //
							// updates obj.
							sPlayersVector[sP_userSelected] = obj;
							/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(obj.lifes_displayFn_V5() >= 8 && obj.lifes_displayFn_V5() <= 11){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 16){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
						}		
					//--------------------------------------------------------------------------------------------
			//18; mission impossible: If you reach 1 000 000 *** !!! -AllTimescore- !!! *** (+10 lifes)
					if((obj.sP_allTimeScore_displayFn_V5() + obj.totalScoreInThisSession_displayFn_V5()) >= 1000000 && milestone_reaching1000000_AllTimeScore){ // reset bool var before session starts
							milestone_reaching1000000_AllTimeScoreFn(1000000);
							//milestone count updater:
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
							// adds physiquly + 5 life
							obj.lifes_setterFn_V5(+10); //
							// updates obj.
							sPlayersVector[sP_userSelected] = obj;
							/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(obj.lifes_displayFn_V5() >= 11 && obj.lifes_displayFn_V5() <= 14){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(obj.lifes_displayFn_V5() >= 11 && obj.lifes_displayFn_V5() <= 19){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
					
				}
				//-----------------------------------------------------------------------------------------------------	
				//for test Stop:
				/*
						cout<<"attempt 2 invoked (Press ENTER TO CONTINUE)"<<endl;
						cin.get();
						cin.get();
						*/
				}
			//---------------------------------------------------------------------------------------	
		else if(attempts_test == 3 && obj.lifes_displayFn_V5() > 0)
				{	
				if(easySwitch){roundScore_V5= 3;}
				if(expertSwitch){roundScore_V5= 12;}
				else{roundScore_V5= 6;}
				obj.totalScoreInThisSession_setterFn_V5(roundScore_V5);
				//obj.sP_allTimeScore_setterFn_V5();
				//obj.sP_attemptCounter_singleSession_setterFn_V5(3);
			cout<<endl
				<<"\n"
				<<setw(20)<<BRIGHT<<obj.name_displayFn_V5()<<RSTA<<", "
				<<"\33[0myour total score is : "
				<<"\33[2;30;47m"
				<<obj.totalScoreInThisSession_displayFn_V5()
				<<RSTA
				<<endl;
				//Milestone message pop up if score reach milestone....
				// 4; Reaching 100 score in one session: Message Pop Up, plus 1 extra life.
				if(obj.totalScoreInThisSession_displayFn_V5() >= 100 && milestone_reaching_100_ScoreInSingleSession){
					milestone_reaching100ScoreInSingleSessionFn(obj.totalScoreInThisSession_displayFn_V5());
					// adds physiquly + 1 life
					obj.lifes_setterFn_V5(+1); // works with +1
					//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							
							// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(obj.lifes_displayFn_V5() == 5){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(obj.lifes_displayFn_V5() == 10){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
		
				}
			//-----------------------------------------------------
			// 7; Reaching 1000 score in a single session milestone
			if(obj.totalScoreInThisSession_displayFn_V5() >= 1000 && milestone_reaching1000_ScoreInSingleSession){
					milestone_reaching1000_ScoreInSingleSessionFn(obj.totalScoreInThisSession_displayFn_V5());
					//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
					// updates obj.
					// 3 for reaching 1000
					obj.lifes_setterFn_V5(+3);
					sPlayersVector[sP_userSelected] = obj;
					/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				//Add the life related achivements here too...
				// Milestone displayed if achived:
					// 5; If you reach 5 lifes 
					if((obj.lifes_displayFn_V5() >= 2 && obj.lifes_displayFn_V5() <=7) && milestone_reaching5_lifes){
						
								milestone_reaching5_lifesFn(5);
								// adds physiquly + 1 life
								//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
								obj.lifes_setterFn_V5(+1); // works with +1
								// updates obj.
								sPlayersVector[sP_userSelected] = obj;
								/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
										
					//-----------------------------------------------------------------------------------------------------
					// 6; Reaching 10 lifes
						if((obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <=12) && milestone_reaching10_lifes){
							//obj.lifes_setterFn_V5(+3);
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
						// updates obj.
						sPlayersVector[sP_userSelected] = obj;
								milestone_reaching10_lifesFn(10);
								// adds physiquly + 2 life
								obj.lifes_setterFn_V5(+2); 
								// updates obj.
								sPlayersVector[sP_userSelected] = obj;
								/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
							}
					//-----------------------------------------------------
				
				// else ?

				/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				}
			//-----------------------------------------------------
			// 8; Reaching 5000 score in a single session...
						if(obj.totalScoreInThisSession_displayFn_V5() >= 5000 && milestone_reaching5000_ScoreInSingleSession){ // reset bool var before session starts
							milestone_reaching5000_ScoreInSingleSessionFn(obj.totalScoreInThisSession_displayFn_V5());
							// adds physiquly + 5 life
							obj.lifes_setterFn_V5(+5); //
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
							// updates obj.
							sPlayersVector[sP_userSelected] = obj;
							/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(obj.lifes_displayFn_V5() >= 6 && obj.lifes_displayFn_V5() <= 9){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 14){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
					}
			//---------------------------------------------------------------------------------------------------------		
			//12; Challenge Inpossible: 1000 Score in 100 rounds. add extra 3 lifes (Answerstreak 100)
			if(obj.totalScoreInThisSession_displayFn_V5() >= 1000 &&
				obj.totalRoundsPlayed_displayFn_V5() <= 100 && milestone_reaching_1000Score_in100Rounds){
				milestone_reaching_1000Score_in100RoundsFn(obj.totalScoreInThisSession_displayFn_V5(), obj.totalRoundsPlayed_displayFn_V5());
				// add + 3 lifes
				obj.lifes_setterFn_V5(+3);
				//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
				// updates obj.
				sPlayersVector[sP_userSelected] = obj;
				
				// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(obj.lifes_displayFn_V5() >= 5 && obj.lifes_displayFn_V5() <= 7){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 12){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
				
			}
			//-----------------------------------------------------------------------------------------
			//17; Challenge impossible 2: 10000(ten tousend) Score in a single session
					if(obj.totalScoreInThisSession_displayFn_V5() >= 10000 && milestone_reaching10000_ScoreInSingleSession){ // reset bool var before session starts
							milestone_reaching10000_ScoreInSingleSessionFn(obj.totalScoreInThisSession_displayFn_V5());
							// adds physiquly + 5 life
							obj.lifes_setterFn_V5(+5); //
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
							// updates obj.
							sPlayersVector[sP_userSelected] = obj;
							/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(obj.lifes_displayFn_V5() >= 6 && obj.lifes_displayFn_V5() <= 9){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 14){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}	
					}
					
					
					//-----------------------------------------------------------------------------------------------------
			// 17.5 reach 100 000 score all time (+7 lifes) 
					if((obj.sP_allTimeScore_displayFn_V5() + obj.totalScoreInThisSession_displayFn_V5()) >= 100000 && milestone_reaching100000_AllTimeScore){ // reset session bool var(not Alltime) before session starts
							milestone_reaching100000_AllTimeScoreFn(100000);
							//milestone count updater:
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
							// adds physiquly + 7 life
							obj.lifes_setterFn_V5(+7); //
							// updates obj.
							sPlayersVector[sP_userSelected] = obj;
							/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(obj.lifes_displayFn_V5() >= 8 && obj.lifes_displayFn_V5() <= 11){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(obj.lifes_displayFn_V5() >= 10 && obj.lifes_displayFn_V5() <= 16){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
						}		
					//--------------------------------------------------------------------------------------------
			//18; mission impossible: If you reach 1 000 000 *** !!! -AllTimescore- !!! *** (+10 lifes)
					if((obj.sP_allTimeScore_displayFn_V5() + obj.totalScoreInThisSession_displayFn_V5()) >= 1000000 && milestone_reaching1000000_AllTimeScore){ // reset bool var before session starts
							milestone_reaching1000000_AllTimeScoreFn(1000000);
							//milestone count updater:
							//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
							// adds physiquly + 5 life
							obj.lifes_setterFn_V5(+10); //
							// updates obj.
							sPlayersVector[sP_userSelected] = obj;
							/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
						// this also mean that yo can have 5 or 10 lifes because this so if this will activate too...
								if(obj.lifes_displayFn_V5() >= 11 && obj.lifes_displayFn_V5() <= 14){
									// means you reached 5 lifes milestone too...
									milestone_reaching5_lifesFn(5);
									obj.lifes_setterFn_V5(+1);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}
								//----------------------------------------------------------------
								if(obj.lifes_displayFn_V5() >= 11 && obj.lifes_displayFn_V5() <= 19){
									// means you reacged 10 life milestone too...
									milestone_reaching10_lifesFn(10);
									obj.lifes_setterFn_V5(+2);
									//obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress);
									sPlayersVector[sP_userSelected] = obj;
									cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
									cin.get();
									}	
					
				//-----------------------------------------------------------------------------------------------------	
				//for test Stop:
				/*
						cout<<"attempt 3 invoked (Press ENTER TO CONTINUE)"<<endl;
						cin.get();
						cin.get();
						*/
						
				}
			}
		//-------------------------------------------------------------------
		// Milestone displayed if achived:
		// 5; If you reach 5 lifes 
		
		if(obj.lifes_displayFn_V5() == 5 && (prev_lives_V5 == 4 || prev_lives_V5 == 3) && milestone_reaching5_lifes){
					milestone_reaching5_lifesFn(obj.lifes_displayFn_V5());
					// adds physiquly + 1 life
					obj.lifes_setterFn_V5(+1); // works with +1
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				}
		//--------------------------------------------------------------
		// 6; Reaching 10 lifes
			if(obj.lifes_displayFn_V5() == 10 && (prev_lives_V5 == 9 || prev_lives_V5 == 8) && milestone_reaching10_lifes){
				
			// updates obj.
			sPlayersVector[sP_userSelected] = obj;
					milestone_reaching10_lifesFn(obj.lifes_displayFn_V5());
					// adds physiquly + 2 life
					obj.lifes_setterFn_V5(+2); 
					// updates obj.
					sPlayersVector[sP_userSelected] = obj;
					/*
		//test:
		// display if update done:
		cout<<"Lifes: "<<obj.lifes_displayFn_V5()<<endl;
		cout<<"Milestones unlocked "<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<endl;
		cout<<"Press ENTER to continue..."<<endl;
		cin.get();
		*/
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
				}
		//-----------------------------------------------------
		
			//update player data:
		//obj.sP_attemptCounter_AllTime_setterFn_V5();
		//obj.sP_attemptCounter_singleSession_setterFn_V5(attempts_test); // updates All-Time record too
		// Reset attempts and current score:
		attempts_test = 1;
		
		//-------------------------------------------------------
		//milestones update
						obj.sp_milestone_1_V5 = milestone_1_h;
						obj.sp_milestone_2_V5 = milestone_2_h;
						obj.sp_milestone_3_V5 = milestone_3_h;
						obj.sp_milestone_4_V5 = milestone_4_h;
						obj.sp_milestone_5_V5 = milestone_5_h;
						obj.sp_milestone_6_V5 = milestone_6_h;
						obj.sp_milestone_7_V5 = milestone_7_h;
						obj.sp_milestone_8_V5 = milestone_8_h;
						obj.sp_milestone_9_V5 = milestone_9_h;
						obj.sp_milestone_10_V5 = milestone_10_h;
						obj.sp_milestone_11_V5 = milestone_11_h;
						obj.sp_milestone_12_V5 = milestone_12_h;
						obj.sp_milestone_13_V5 = milestone_13_h;
						obj.sp_milestone_14_V5 = milestone_14_h;
						obj.sp_milestone_15_V5 = milestone_15_h;
						obj.sp_milestone_16_V5 = milestone_16_h;
						obj.sp_milestone_17_V5 = milestone_17_h;
						obj.sp_milestone_17andHalf_V5 = milestone_17andHalf_h;
						obj.sp_milestone_18_V5 = milestone_18_h;
						obj.sP_masterlevel_unlocked = masterSwitch_h;
						obj.milestone_5sec_easy_V5 = milestone_5sec_easy_dotH;
						obj.milestone_5sec_normal_V5 = milestone_5sec_normal_dotH;
						obj.milestone_5sec_expert_V5 = milestone_5sec_expert_dotH;
						obj.milestone_5sec_master_V5 = milestone_5sec_master_dotH;
						obj.milestone_3sec_easy_V5 = milestone_3sec_easy_dotH;
						obj.milestone_3sec_normal_V5 = milestone_3sec_normal_dotH;
						obj.milestone_3sec_expert_V5 = milestone_3sec_expert_dotH;
						obj.milestone_3sec_master_V5 = milestone_3sec_master_dotH;
						obj.milestone_1sec_easy_V5 = milestone_1sec_easy_dotH;
						obj.milestone_1sec_normal_V5 = milestone_1sec_normal_dotH;
						obj.milestone_1sec_expert_V5 = milestone_1sec_expert_dotH;
						obj.milestone_1sec_master_V5 = milestone_1sec_master_dotH;
		//-------------------------------------------------------
		//To able to display statistics asign obj to PlayerObject
		sPlayersVector[sP_userSelected] = obj;
		//roundScore = 10;
		//inGame = true;	
		cout<<RSTA;	
			}
		} //else
		
		//for test Stop:
				/*
						cout<<" beyond scoring options... invoked (Press ENTER TO CONTINUE)"<<endl;
						cin.get();
						cin.get();
						*/
	
	//-----------------------------------------------------------------------------
		//obj.oBachivementsCounter = achivementsCounter;
		//Use only this to determine all unlocked milestones count and to save to user
		obj.sP_milestonesUnlocked_counter_setterFn_V5(allMilestonesProgress_inDotH);
		
		if(obj.sP_milestonesUnlocked_counter_displayFn_V5() == 22){
			obj.oBallAchivementsAreUnlocked = true;
			allMilestonesUnlockedFn(22, obj.name_displayFn_V5());
			obj.sP_allMilestonesUnlocked = true;
			} //Display the "final message" GAME COMPLATED!...
		
	//----------------------------------------------------------------------------	
						
	}	//end of while in game loop
}	// end of GameLoopFn

//------------------------------------------------------------------

//======================================================================================
//test mP_gameLoopFn:
void test_mP_gameLoop(MplayerClass& obj){
	
	cout<<"Hello "<<obj.mP_name_displayFn_V5()<<"!\n"<<endl;
	cout<<"Scored so far: "<<obj.mP_totalScoreInThisSession_displayFn_V5()<<" \t"<<"Lifes left: "<<obj.mP_lifes_displayFn_V5()<<endl;
	cout<<"\nWhat is 5 + 5? Your answer is: ";
	int a;
	int score = 10;
	int lifes = 3;
	cin>>a;
	if(a == 10){
		cout<<"Lifes left: "<<lifes<<endl;
		cout<<"Scored: "<<score<<endl;
		//update score
		obj.mP_totalScoreInThisSession_setterFn_V5(score);
		cout<<"good, next player now..."<<endl;
		cout<<"Press Enter to continue..."<<endl;
		cin.get();
		}
	else{
		cout<<"NoooPe....."<<endl;
		//update life
		obj.mP_lifes_setterFn_V5(-1); // minus one life
		cout<<"Lifes left: "<<obj.mP_lifes_displayFn_V5()<<endl;
		cout<<"Press Enter to continue..."<<endl;
		cin.get();
		}
	}
//----------------------------------------------------------------------
//If One player left in Mplayer mode -> Victory message
void mP_victoryMessage_displayFn_V5(MplayerClass& obj){
	
	{
			
			
			system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		
		cout
			
			<<RSTA<<"               "<<cD.keret_color<<"****************************************"<<RSTA<<"\n"
			<<"               "<<cD.keret_color<<"*"<<RSTA<<"          "<<cD.smily_color<<":)"<<RSTA<<" "<<cD.menu_color1<<"V I C T O R Y"<<RSTA<<" "<<cD.smily_color<<":)"<<RSTA<<"         "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"               "<<cD.keret_color<<"*"<<RSTA<<"                                      "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"               "<<cD.keret_color<<"*"<<RSTA<<"      "<<cD.menu_color2<<"CONGRATULATION to "<<cD.operation_color<<obj.mP_name_displayFn_V5()<<RSTA<<"    "<<cD.keret_color<<"*"<<RSTA<<"\n"
			<<"               "<<cD.keret_color<<"****************************************"<<RSTA<<"\n"
			<<"               \n"
			<<"            "<<BRIGHT<<"You won this session with a total of "<<cD.youranswer_color<<obj.mP_totalScoreInThisSession_displayFn_V5()<<RSTA<<BRIGHT<<" score!"<<RSTA<<"\n"
			<<"\n"
			<<"                             "<<cD.menu_color1<<"Well done! "<<FGREENBOLD<<":)"<<RSTA<<"\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		
		}
	cout<<"Press \33[1mENTER\33[0m to continue...";
	cout<<endl;
	cin.get();
			
}
//----------------------------------------------------------------------
//If One player left in Mplayer mode -> Victory message
void mP_noneMadeIt_Message_displayFn_V5(){
	
	{
			
			
			system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<BRIGHT<<"\n                  There is no Winner this time.....\n\n"
					<<"                        only Loooooooosers......"<<RSTA<<endl;
					
		cout<<"               \33[1;31m***\33[0m \33[1;32mN\33[0m \33[1mO\33[0m "<<BRIGHT<<"\33[5;31mN\33[0m \33[1;33mE\33[0m  "<<BRIGHT<<"\33[5;31mO\33[0m \33[1;35mF\33[0m  \33[1;36mY\33[0m "<<BRIGHT<<"\33[5;31mO\33[0m \33[1;33mU\33[0m  \33[1;34mM\33[0m \33[1;35mA\33[0m \33[1;36mD\33[0m \33[1mE\33[0m  \33[1;33mI\33[0m \33[1;35mT\33[0m \33[1;31m***\33[0m\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		
		}
	cout<<"Press \33[1mENTER\33[0m to continue...";
	cout<<endl;
	cin.get();
			
}
//----------------------------------------------------------------------
//Time return today's date (updates itselfe at each time the program starts...
string currentTimeFn_V5(){
	time_t tt;
	struct tm* ti;
	time(&tt);
	ti=localtime(&tt);
	
	return asctime(ti);
	}
//--------------------------------------------------------------------------------------------------	
//Only Date return Fn
string cDate_returnFn_V5(){
	
	string cYear = " ";
	string cMonth = " ";
	string cDay = " ";
	string cDate = " ";
	
	time_t tt;
	struct tm* ti;
	time(&tt);
	ti=localtime(&tt);
	
	cYear = to_string(ti->tm_year + 1900); // Since it is counted from 1900...
	cMonth = to_string(ti->tm_mon + 1);    // Since it is starts from 0....
	cDay = to_string(ti->tm_mday);		   // This is set "properly" by default
	
	cDate = cDay+ "-" + cMonth + "-" + cYear;
	
	return cDate;
	
	}
//----------------------------------------------------------------------
//sort sPlayerList by name
bool sortByABC_name_sPlayerListFn_V5(SplayerClass a, SplayerClass b){
	return a.name_displayFn_V5() < b.name_displayFn_V5();}
//======================================================================
//sort by score Mplayer class objects
bool sortByDescendingScore_MplayerClassObjectsFn_V5(MplayerClass a, MplayerClass b){
	return a.mP_totalScoreInThisSession_displayFn_V5() > b.mP_totalScoreInThisSession_displayFn_V5();}
//--------------------------------------------------------------------------
//sort by score and time (if same score put first the one with less time
bool sortByHighestScore_andQuickestTime_ifScoreIs_same_MplayerFn_V5(MplayerClass a, MplayerClass b){
	// this FN to replace the old only Score sorter....
	
	//if a score = b score goes to sort via time
	if(a.mP_totalScoreInThisSession_displayFn_V5() == b.mP_totalScoreInThisSession_displayFn_V5()){
		return a.mP_total_thinkingTime_displayFn_V5() < b.mP_total_thinkingTime_displayFn_V5();
	}
	else{ return a.mP_totalScoreInThisSession_displayFn_V5() > b.mP_totalScoreInThisSession_displayFn_V5();}
	
}
//----------------------------------------------------------------------
//sort by score LeaderBoard List
bool sortByDescendingScore_LeaderBoardListFn_V5(LeaderBoardClass a, LeaderBoardClass b){
	if(a.display_lB_scoreFn_V5() == b.display_lB_scoreFn_V5()){
		return a.display_lB_secs_passed_toAnswerFn_V5() < b.display_lB_secs_passed_toAnswerFn_V5();
	}
	else{return a.display_lB_scoreFn_V5() > b.display_lB_scoreFn_V5();}
}
//return true if name match
bool nameOn_leaderboardAlreadyFn_V5(MplayerClass p, LeaderBoardClass l){
	if(p.mP_name_displayFn_V5().compare(l.display_lB_nameFn_V5()) == true){
		return true;}
	else{return false;}} // if true change score on that person if it is on the same day

//========================== KEY THING =============================================================

void updateLeaderboard_ifItsFull_oneByoneFn_V5(MplayerClass obj){ //invoke if player score > the smallest on leaderboard
	//list is full with default entry already
		sort(leaderList_V5.begin(),leaderList_V5.end(),sortByDescendingScore_LeaderBoardListFn_V5);
		leaderList_V5.pop_back();
			
		//new entry to scorboard
		leaderList_V5.push_back(LeaderBoardClass(obj.mP_name_displayFn_V5(),
												obj.mP_totalScoreInThisSession_displayFn_V5(),
												obj.mP_total_thinkingTime_displayFn_V5(),
												obj.mP_Level_InClass_displayFn_V5(),
												cDate_returnFn_V5()));
		//and resort the list
		sort(leaderList_V5.begin(),leaderList_V5.end(),sortByDescendingScore_LeaderBoardListFn_V5);
			
}
//==================================================================================================
bool return_trueIf_thereSameNameEntryOnLeaderBoardFn_v5(MplayerClass obj){
	//check if name exist on leaderboard -> if so update only score to name
		bool matchOrNo = false;
		for(auto& lobj : leaderList_V5){
			if(lobj.display_lB_nameFn_V5().compare(obj.mP_name_displayFn_V5())){
				matchOrNo = true;
				break;}
			}
		return matchOrNo;
		}
//===================================================================================================
//	*** use only this fn to update leaderboard entry.... ***		
void update_leaderboard_all_in_one(string name, string date, int time_to_a, int diff_lev, int score){
	//leaderboard update code logic
		
		if(leaderList_V5.size() > 15){
			leaderList_V5.erase(leaderList_V5.end());
		}
		
		leaderList_V5.push_back(LeaderBoardClass(name, score, time_to_a, diff_lev, date));
		
}
//==================================================================================================
//Not played more then a week message pop up

void not_played_moreThen_oneWeek_messageFn_V5(SplayerClass obj){
	
	cin.get();
	// 3 random message, 1 of them played only per call.
	// note: If statement will be placed outside, for signed in person, before sp menu!
	system("clear");
	//last_timePlayed is a timePoint saved & loaded
	// one_weekTime its a constant var, duration of one week. in resulution of days -> 7 days !!!
	//if(last_timePlayed > one_weekTime)
	//----------------------------------------------------------------------------------------------
	
	int r_num = rnd1(3);
	if(r_num == 0){r_num = r_num + 1;}
	bool displayed = false;
	
	while(!displayed){
	if(r_num == 1){
	//Message 1;
		cout<<"\n"
			<<"   "<<cD.menu_color2<<"Hey"<<RSTA<<" "<<cD.menu_color1<<obj.name_displayFn_V5()<<cD.menu_color2<<", it is great to see you again!"<<RSTA<<"\n\n"
			<<"     "<<cD.keret_color<<"================================================================"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                              "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"                "<<cD.menu_color1<<"I was thinking about you...!"<<RSTA<<"                  "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"     "<<cD.menu_color1<<"I'm not gonna lie, I felt a bit lonly without you..."<<RSTA<<"     "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"         "<<cD.menu_color1<<"I like when you are interacting with me...."<<RSTA<<"          "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"       "<<cD.menu_color1<<"Remember, when you don't use it, you'll lose it!"<<RSTA<<"       "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                              "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"     "<<cD.menu_color1<<"Please, exercise it more frequently!"<<RSTA<<" "<<cD.menu_color2<<"Thank U :)"<<RSTA<<"          "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                              "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"================================================================"<<RSTA<<"\n"
			<<endl;
			
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		fflush(stdin);
		cin.get();
		system("clear");
		fflush(stdin);
		displayed = true;
		break;
	}
	if(r_num == 2){
	//Message 2;
		cout<<"\n"
			<<"      "<<cD.menu_color1<<"Hi"<<RSTA<<" "<<cD.menu_color2<<obj.name_displayFn_V5()<<cD.menu_color2<<", how is going?"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"================================================================"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                              "<<cD.keret_color<<"|\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"           "<<cD.menu_color1<<"Well, I'm a bit disapointed, you know!"<<RSTA<<"             "<<cD.keret_color<<"|\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"          "<<cD.menu_color1<<"I tought we'r going to play more offen..."<<RSTA<<"           "<<cD.keret_color<<"|\n"
			<<" 	"<<cD.keret_color<<"|"<<RSTA<<"                    "<<cD.menu_color1<<"What's the matter?"<<RSTA<<"                        "<<cD.keret_color<<"|\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"           "<<cD.menu_color1<<"Don't you like my numbers anymore?"<<RSTA<<"                 "<<cD.keret_color<<"|\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                              "<<cD.keret_color<<"|\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"       "<<cD.menu_color1<<"Please, turn me On few times a week!"<<RSTA<<" "<<cD.menu_color2<<"Thank U :)"<<RSTA<<"        "<<cD.keret_color<<"|\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                              "<<cD.keret_color<<"|\n"
			<<"     "<<cD.keret_color<<"================================================================"<<RSTA<<"\n"
			<<endl;
			
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		fflush(stdin);
		cin.get();
		system("clear");
		fflush(stdin);
		displayed = true;
		break;
	}
	if(r_num == 3){
	//Message 3;
		cout<<"\n"
			<<"      "<<cD.menu_color1<<"Well, well, well... Look who is here! Hi"<<cD.equattionText_color<<obj.name_displayFn_V5()<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"=================================================================="<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                                "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"          "<<cD.menu_color1<<"I've  tought you already forgot about me!             "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"             "<<cD.menu_color1<<"I appreciate checking back on me!                  "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<" 	"<<cD.keret_color<<"|"<<RSTA<<"           "<<cD.menu_color1<<"Let's have a great practice session!                 "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<" "<<cD.menu_color1<<"How 'bout, you push your baunderies and make a new high score? "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                                "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"                           "<<cD.menu_color2<<"Thank U"<<RSTA<<" "<<cD.smily_color<<":)"<<RSTA<<"                           "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                                "<<cD.keret_color<<"|"<<RSTA<<"\n"
			<<"     "<<cD.keret_color<<"=================================================================="<<RSTA<<"\n"
			<<endl;
			
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		fflush(stdin);
		cin.get();
		system("clear");
		fflush(stdin);
		displayed = true;
		break;
	}
	else{
		rnd1(3);
		if(rnd1(3) == 0){r_num = 1;}}
	}
	
}
//--------------------------------------------------------------------------------------------------
//T&C fn (free ware) ... sort of licence
void current_TandC_displayFn_V5(){
	
	//... Linux / windows use it as it is or modify it to your liking....
	
cout<<"Copyright 2024-2026 (c) Andras Dobranszki\n"<<endl;

cout<<"The \"Software\" or \"SOFTWARE\" in this document refers to this program,\n"
	<<"\"Math Challenge\".\n"<<endl;

cout<<"Permission is hereby granted, free of charge,\n"
	<<"to any person obtaining a copy of this Software, (Math Challenge) and\n"
	<<"associated documentation files."<<endl;
cout<<"Permission includes without restriction, without limitation the rights\n"
	<<"to use, copy, modify, merge, publish, distribute, sublicense,\n"
	<<"and/or sell copies of this Software, and to permit persons to whom the Software\n"
	<<"is furnished to do so, subject to the following conditions:\n"<<endl;

cout<<"Press ENTER to continue reading terms and conditions..."<<endl;
cin.get();

cout<<"THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND,\n"
	<<"EXPRESS OR IMPLIED,\n"
	<<"INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR\n"
	<<"A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR\n"
	<<"COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,\n"
	<<"WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR\n"
	<<"IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.\n"<<endl;

cout<<"The above copyright notice and this permission notice shall be included\n"
	<<"in all copies or substantial portions of the Software.\n"<<endl;
}

// For future projects save T&C into txt file, such way you can update easier, then just load file
// content into this Fn....
void termsAndConDisplayFn_V5(){
	
	system("clear");
	//unused (paid services licence...) sort of... not checked via lawyer... just a hobby project
	cout<<"          *** TERMS & CONDITIONS ***\n"
		<<endl;
		
	cout<< "    Definitions\n"<<endl;
	cout<<"The following definitions shall have the same meaning regardless\n"
		<<"of whether they appear in singular or in plural, Capital or lower case.\n"<<endl;
	cout<<"For the purposes of these Terms and Conditions:\n"
		<<"\"We, Us, Our\" referes to the intelect behind this software."
		<<"\"You\" means the user, the individual accessing or using the\n"
		<<"\"Your Profile\" includes your username, password and your progress data.\n"
		<<"Software on behalf of which such individual is accessing or\n"
		<<"using the Software, as applicable.\n"
		<<"\"Content\" refers to content such as text, images, or other information\n"
		<<"that can be posted, uploaded, linked to or otherwise made available by You,\n"
		<<"regardless of the form of that content.\n"
		<<"\"Device\" means any device that can access the Service\n"
		<<"such as a computer, a cellphone or a digital tablet.\n"
		<<"\"Feedback\" means feedback, innovations or suggestions\n"
		<<"sent by You regarding the attributes,performance or features of our Software.\n"
		<<"\"Software\" refers to Math challenge, the/this software, the program,\n"
		<<"the Application.\n"
		<<"\"Terms and Conditions\" (also referred as \"Terms\") mean these\n"
		<<"Terms and Conditions that form the entire agreement between You and We\n"
		<<"regarding the use of the program.\n"<<endl;
		
	cout<<"\nAcknowledgment\n"<<endl;
	cout<<"These are the Terms and Conditions governing the use of this Service\n"
		<<"and the agreement that operates between You and I.\n"
		<<"These Terms and Conditions set out the rights and obligations of all users\n"
		<<"regarding the use of the Software. Your access to and use of the product is\n"
		<<"conditioned on Your acceptance of and compliance with these Terms and Conditions.\n"
		<<"These Terms and Conditions apply to all visitors, users and others who access or\n"
		<<"use the Software. By accessing or using the Software You agree to be bound\n"
		<<"by these Terms and Conditions. If You disagree with any part of these\n"
		<<"Terms and Conditions then You may not access the Software.\n"<<endl;
		
	cout<<"\nThe software runs offline, no internet requierd. For any leek on your\n"
		<<"user name or password We do not take responsibility. We do not collect any\n"
		<<"personal information regarding the user.\n";
		
	cout<<"    Math challenge is a piece of educational software.\n"
		<<"With it you'd able to practice basic mathematical equations.\n"
		<<"By practicing math you'll improve on your calculating abilities.\n"
		<<endl;
	cout<<"The maker of this software (math challenge) does not hold responsibilities\n"
		<<"toward your level of math. Neither can be blamed for disappointing\n"
		<<"(what is concidered disappointing to you) outcome on any field of your life.\n"
		<<endl;
	
	cout<<"If you find some wird anomaly during playing, something incorrect,\n"
		<<"You might take your time to describe the issue as clear as possible and\n"
		<<"send the report to "<<issues_emilAddres<<", please as a feedback.\n"
		<<"Your Feedback to Us\n"
		<<"You assign all rights, title and interest in any Feedback You provide to Us.\n"
		<<"You agree to grant Us a non-exclusive, perpetual, irrevocable, royalty\n"
		<<"free, worldwide right and license to use, reproduce, disclose, sub-license,\n"
		<<"distribute, modify and exploit such Feedback without restriction.\n"<<endl;
	
	cout<<"Termination\n"
		<<"We may terminate or suspend Your Account immediately, without prior\n"
		<<"notice or liability, for any reason whatsoever, including without\n"
		<<"limitation if You breach these Terms and Conditions.\n"
		<<"Upon termination, Your right to use the Service will cease immediately.\n"
		<<"If You wish to terminate Your Profile, You may simply discontinue using\n"
		<<"the Software or delete your profile or/and the Software.\n"<<endl;
	cout<<"The Software is provided to You \"AS IS\" and \"AS AVAILABLE\" \n"
		<<"and with all faults and defects without warranty of any kind.\n"<<endl;
	
	cout<<"We provide no warranty or undertaking, and makes no representation\n"
		<<"of any kind that the Service will meet Your requirements, achieve any\n"
		<<"intended results, be compatible or work with any other software, applications,\n"
		<<"systems or services, operate without interruption, meet any performance or\n"
		<<"reliability standards or be error free or that any errors or defects can\n"
		<<"or will be corrected. Without limiting the foregoing, neither We make any\n"
		<<"representation or warranty of any kind, express or implied:\n"
		<<" (1) as to the operation or availability of the Software, or the information,\n"
		<<"content, and materials or products included thereon;\n"
		<<" (2) that the Program will be uninterrupted or error-free;\n"
		<<" (3) as to the accuracy, reliability, or currency of any information\n"
		<<" or content provided through the Service; or\n"
		<<" (4) that the Software, the content, or e-mails sent from or on\n"
		<<" behalf of Us are free of viruses, scripts, trojan horses, worms,\n" 
		<<"malware, timebombs or other harmful components.\n"
		<<"Some jurisdictions do not allow the exclusion of certain types of\n"
		<<"warranties or limitations on applicable statutory rights of a consumer,\n"
		<<"so some or all of the above exclusions and limitations may not apply to You.\n"
		<<"But in such a case the exclusions and limitations set forth in this section\n"
		<<"shall be applied to the greatest extent enforceable under applicable law.\n"<<endl;
		
	cout<<"Governing Law\n"
		<<"The laws of the Country, excluding its conflicts of law rules, shall govern\n"
		<<"this Terms and Your use of the Service. Your use of the Application may\n"
		<<"also be subject to other local, state, national, or international laws.\n"
		<<"Disputes Resolution\n"
		<<"If You have any concern or dispute about the Software, You agree to first\n"
		<<"try to resolve the dispute informally by contacting Us.\n"<<endl;
	
	cout<<"Severability\n"
		<<"If any provision of these Terms is held to be unenforceable or invalid,\n"
		<<"such provision will be changed and interpreted to accomplish the objectives\n"
		<<"of such provision to the greatest extent possible under applicable\n"
		<<"law and the remaining provisions will continue in full force and effect.\n"<<endl;
	cout<<"Waiver\n"
		<<"Except as provided herein, the failure to exercise a right or to require\n"
		<<"performance of an obligation under this Terms shall not effect a party's ability\n"
		<<"to exercise such right or require such performance at any time thereafter nor\n"
		<<"shall be the waiver of a breach constitute a waiver of any subsequent breach.\n"<<endl;
	cout<<"Changes to These Terms and Conditions\n"
		<<"We reserve the right, at Our sole discretion, to modify or replace these\n"
		<<"Terms at any time. If a revision is material We will make reasonable efforts\n"
		<<"to provide at least 30 days' notice prior to any new terms taking effect.\n"
		<<"What constitutes a material change will be determined at Our sole discretion.\n"
		<<"By continuing to access or use Our Service after those revisions become effective,\n"
		<<"You agree to be bound by the revised terms. If You do not agree to the new terms,\n"
		<<"in whole or in part, please stop using the website and the Software.\n"<<endl;

	cout<<"Contact Us\n"
		<<"If you have any questions about these Terms and Conditions, You can contact us:\n"
		<<endl<<issues_emilAddres<<endl;
			
	cout<<"\nThank you! :)\n";
	cout<<endl;
}
//=================================================================================================


void manual_displayFn_V5(){
	
	cin.get();
	system("clear");
	
	cout<<BRIGHT<<"              *** P R O J E C T   M A N U A L ***\n"<<RSTA<<endl;
	
cout<<endl;	
cout<<"     "<<cD.keret_color<<"==========================================================================="<<RSTA<<"\n"
	<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                                         "<<cD.keret_color<<"|"<<RSTA<<"\n"
	<<"     "<<cD.keret_color<<"|"<<RSTA<<"                        _   _     ___  ____                              "<<cD.keret_color<<"|"<<RSTA<<"\n"
	<<"     "<<cD.keret_color<<"|"<<RSTA<<"                       //\\\\/\\\\   //_\\\\  ||  ||__||                       "<<cD.keret_color<<"|"<<RSTA<<"\n"                     
	<<"     "<<cD.keret_color<<"|"<<RSTA<<"                      //     \\\\ //   \\\\ ||  ||  ||                       "<<cD.keret_color<<"|"<<RSTA<<"\n"
	<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                                         "<<cD.keret_color<<"|"<<RSTA<<"\n"
	<<"     "<<cD.keret_color<<"|"<<RSTA<<"           ___          ___            ____          ___  ____           "<<cD.keret_color<<"|"<<RSTA<<"\n"
	<<"     "<<cD.keret_color<<"|"<<RSTA<<"          //   ||__||  //_\\\\  ||  ||  ||_   ||\\\\ || // _ ||_             "<<cD.keret_color<<"|"<<RSTA<<"\n"
	<<"     "<<cD.keret_color<<"|"<<RSTA<<"          \\\\__ ||  || //   \\\\ ||_ ||_ ||__  || \\\\|| \\\\// ||__            "<<cD.keret_color<<"|"<<RSTA<<"\n"
	<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                                         "<<cD.keret_color<<"|"<<RSTA<<"\n"
	<<"     "<<cD.keret_color<<"|"<<RSTA<<"               Written by Andras Dobranszki © 2024-2026                  "<<cD.keret_color<<"|"<<RSTA<<"\n"
	<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                                         "<<cD.keret_color<<"|"<<RSTA<<"\n"
	<<"     "<<cD.keret_color<<"|"<<RSTA<<"                                                                         "<<cD.keret_color<<"|"<<RSTA<<"\n"
	<<"     "<<cD.keret_color<<"==========================================================================="<<RSTA<<endl;

cout<<"\n"<<endl;
cout<<"                                                      "<<cD.menu_color1<<"Info and Manual"<<RSTA<<"\n\n"<<endl;
sleep(12);
system("clear");

cout<<" "<<cD.back_color<<"FOREWORD"<<RSTA<<"\n"<<endl;


	cout<<"  "<<"This program, known as Math Challenge is not just an other game of numbers.\n"
		<<"  "<<"Math Challenge is created with the purpose of giving people an interactive\n"
		<<"  "<<"way to keep on top of their math skills. Just like your physical muscles\n"
		<<"  "<<"your brain needs to be exercised too. While you exercise your brain you\n"
		<<"  "<<"develop a habit of thinking too."<<DIM<<" \33[3m(Instead of searching for\n"
		<<"  "<<"answers on your phone or asking an AI for everything.)\33[0m\n"
		<<"  "<<"In the 21st century humans populated nearly all electronics with AI assists.\n"
		<<"  "<<"Making their life more “convenient”, but in the same time\n"
		<<"  "<<"they slowly forget how to think for them selves. How to use their own brain\n"
		<<"  "<<"such way to figure out a solution to an issue, to solve a problem or matter.\n\n"<<RSTA<<endl;



cout<<"    "<<cD.menu_color1<<"Hence the saying:"<<BRIGHT<<"\33[3m \"If you don’t use it, you’ll lose it!\""<<RSTA"\n" 
	<<"                                                  "<<cD.menu_color1<<"(Master Shi Heng Yi)\n"<<endl;

cout<<cD.keret_color<<"==============================================================================\n"<<endl;
cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
cin.get();

cout<<endl;

cout<<"    "<<"\33[1mNote:\33[0m"<<" "<<cD.menu_color1<<"The original Math Challenge Program has no computer virus(es).\n" 
    <<"    "<<"But never the less please, always check your copy of the Program\n"
    <<"    "<<"with an antivirus software (not included) before you run on your\n"
    <<"    "<<"device. As your copy of the program might have been altered…\n"<<RSTA<<endl;
             

cout<<cD.back_color<<"How to run the Software?"<<RSTA<<"\n"<<endl;

cout<<"    "<<cD.menu_color1<<"Write in Linux terminal window the name of the program. Run in terminal.\n"
	<<"    "<<"    - \33[1mSample:\33[0m"<<" "<<cD.menu_color1<<"(program_folder$ ./program_name)\n"<<RSTA<<endl;

cout<<"    "<<cD.menu_color1<<"The program will create 2 “.txt” save files in it’s directory.\n" 
	<<"    "<<"One for single players, the other for leader board."<<RSTA<<endl;
cout<<"    "<<DIM<<"( saveFile_singlePlayerMode_V5.txt  "<<RSTA<<"and"<<DIM<<"  saveFile_leaderBoard_V5.txt )"<<RSTA"\n\n"<<endl;
	

cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
cin.get();

cout<<endl;

cout<<cD.back_color<<"PROGRAM STRUCTURE"<<RSTA<<"\n"<<endl;

cout<<"    "<<cD.back_color<<"MAIN MENU:"<<RSTA<<"\n"<<endl;
cout<<"        "<<cD.menu_color1<<"- Single player mode"<<RSTA<<"\n"
	<<"            "<<"-Login -> (Create a offline username and pin code)"<<RSTA<<"\n"
	<<"                "<<cD.menu_color1<<"- Play the Game! -> \33[2m(Once logged in)"<<RSTA<<"\n"
	<<"                "<<cD.menu_color1<<"- Statistics -> \33[2m(See your progress)"<<RSTA<<"\n"
	<<"                "<<cD.menu_color1<<"- Milestones status -> \33[2m(Check your locked/unlocked achievements)"<<RSTA<<"\n"
	<<"                "<<cD.menu_color1<<"- Number Matrix -15x- → \33[2m(a 15x15 timetable for reference)"<<RSTA<<"\n"
	<<"                "<<cD.menu_color1<<"- Options"<<RSTA<<"\n"
	<<"                    "<<cD.menu_color2<<"- Colour themes ->\33[2m( Select a preferred colour theme)"<<RSTA<<"\n"
	<<"                        "<<cD.menu_color1<<"- Default theme"<<RSTA<<"\n"
	<<"                        "<<cD.menu_color1<<"- Spring theme"<<RSTA<<"\n"
	<<"                        "<<cD.menu_color1<<"- Summer theme"<<RSTA<<"\n"
	<<"                        "<<cD.menu_color1<<"- Autumn theme"<<RSTA<<"\n"
	<<"                        "<<cD.menu_color1<<"- Winter theme"<<RSTA<<"\n"<<endl;

cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
cin.get();
cout<<endl;
	
cout<<"                    "<<cD.menu_color2<<"- Difficulty levels"<<RSTA<<"\n"
	<<"                        "<<cD.menu_color1<<"- \33[1;37mEASY"<<cD.menu_color1<<" -> \33[2m(Solve equations in number range \33[1;37m0-10\33[0m\33[2m)"<<RSTA<<"\n"
	<<"                        "<<cD.menu_color1<<"- \33[1;32mNORMAL"<<cD.menu_color1<<" -> \33[2m(Solve equations in number range \33[1;32m0-100\33[0m\33[2m)"<<RSTA<<"\n"
	<<"                            "<<ITALIC<<cD.back_color<<"(by default the program starts in NORMAL)"<<RSTA<<"\n"
	<<"                        "<<cD.menu_color1<<"- \33[1;33mEXPERT"<<cD.menu_color1<<" -> \33[2m(Solve equations in number range \33[1;33m0-1000\33[0m\33[2m)"<<RSTA<<"\n"
	<<"                        "<<cD.menu_color1<<"- \33[1;31mMASTER"<<cD.menu_color1<<" -> \33[2m(Solve equations in number range \33[1;31m0-10000\33[0m\33[2m)"<<RSTA<<"\n"
	<<"                            "<<DIM<<"         \33[3m(Unlockable via milestone achievement)"<<RSTA<<"\n"
	<<"                    "<<cD.menu_color2<<"- Change your name"<<RSTA<<"\n"
	<<"                    "<<cD.menu_color2<<"- Change your PIN"<<RSTA<<"\n"
	<<"                    "<<cD.menu_color2<<"- "<<"\33[2;31mDelete"<<cD.menu_color2<<" your profile -> "<<DIM<<"\33[3m(It’s what it says)"<<RSTA<<"\n"
	<<"                    "<<cD.back_color<<"- Back \33[3m(back to Single player menu)"<<RSTA<<"\n"
	<<"                "<<cD.back_color<<"- Back \33[3m(back to MAIN menu)"<<RSTA<<"\n"<<endl;

cout<<cD.keret_color<<"==============================================================================\n"<<endl;
cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
cin.get();
system("clear");
cout<<"\n"
	<<"        "<<cD.menu_color1<<"- Multiplayer mode"<<RSTA<<"\n"
	<<"            "<<cD.menu_color1<<"- Play the Game"<<RSTA<<"\n"
	<<"                "<<cD.menu_color2<<"- Enter the names of players -> \33[2m(minimum two player required)"<<RSTA<<"\n"
	<<"                "<<cD.menu_color2<<"- Enter the number of the desired rounds you wish to play"<<RSTA<<"\n"
	<<"                    "<<ITALIC"(\33[4mNote:"<<RSTA<<ITALIC<<" Enter ‘\33[1m0\33[0m’"<<ITALIC<<" Zero for infinite rounds. You’ll have the"<<RSTA<<"\n"
	<<"                           "<<"chance to terminate the game after each round…)"<<RSTA<<"\n"
	<<"                "<<cD.menu_color2<<"- Game summery ->\33[2m( a short statistic )"<<RSTA<<"\n"
	<<"            "<<cD.menu_color1<<"- Options"<<RSTA<<"\n"
	<<"                "<<cD.menu_color2<<"- Difficulty levels"<<RSTA<<"\n"
	<<"                    "<<"- \33[1;37mEASY\33[0m -> (\33[2mSolve equations in number range\33[0m \33[1;37m0-10\33[0m)"<<RSTA<<"\n"
	<<"                    "<<"- \33[1;32mNORMAL\33[0m -> (\33[2mSolve equations in number range\33[0m \33[1;32m0-100\33[0m)"<<RSTA<<"\n"
	<<"                    "<<"            "<<ITALIC<<"(\33[2mby default the program starts in \33[1;32mNORMAL\33[0m)"<<RSTA<<"\n"
	<<"                    "<<"- \33[1;33mEXPERT\33[0m -> (\33[2mSolve equations in number range\33[0m \33[1;33m0-1000\33[0m)"<<RSTA<<"\n"
	<<"                    "<<"- \33[1;31mMASTER\33[0m -> (\33[2mSolve equations in number range\33[0m \33[1;31m0-10000\33[0m)"<<RSTA<<"\n"
	<<"                    "<<ITALIC<<"            (\33[4mNote:"<<RSTA<<ITALIC<<" in multiplayer mode you can play master"<<RSTA<<"\n"
	<<"                                       "<<"level without needing to unlock it...)"<<RSTA<<"\n"<<endl;

cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
cin.get();
cout<<endl;

cout<<"                "<<cD.menu_color2<<"- Colour schemes"<<RSTA<<"\n"
	<<"                    "<<FYELLOW<<"- Default theme"<<RSTA<<"\n"
	<<"                    "<<FGREENBOLD<<"- Spring theme"<<RSTA<<"\n"
	<<"                    "<<FREDBOLD<<"- Summer theme"<<RSTA<<"\n"
	<<"                    "<<FYELLOWBOLD<<"- Autumn theme"<<RSTA<<"\n"
	<<"                    "<<FWHITEBOLD<<"- Winter theme"<<RSTA<<"\n"
	<<"                "<<cD.menu_color2<<"- Automated next player’s turn -> (\33[1;32mON\33[0m/\33[1;31mOFF"<<RSTA<<cD.menu_color2<<")"<<RSTA<<"\n"
	<<"                "<<cD.menu_color2<<"- Automated next round -> (\33[1;32mON\33[0m/\33[1;31mOFF"<<RSTA<<cD.menu_color2<<")"<<RSTA<<"\n"
	<<"            "<<cD.menu_color1<<"- Leader board -> ( \33[3mContains user name, score, diff. level and date"<<RSTA<<cD.menu_color1<<")"<<RSTA<<"\n"
	<<"            "<<cD.back_color<<"- Back (back to MAIN menu)"<<RSTA<<"\n"
	<<"        "<<cD.menu_color1<<"- Number Matrix 15x15"<<RSTA<<"\n"
	<<"        "<<cD.menu_color1<<"- Manual -> ( \33[2ma in-game reference\33[0m"<<cD.menu_color1<<" )"<<RSTA<<"\n"
	<<"        "<<"- \33[1;31mEXIT\33[0m Program"<<RSTA<<"\n"<<endl;
	
cout<<cD.keret_color<<"=============================================================================="<<RSTA<<endl;
cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
cin.get();

cout<<endl;

cout<<cD.back_color<<"How to navigate through the program?"<<RSTA<<"\n\n"
	
	<<"    "<<BRIGHT<<"\33[4mNote:"<<RSTA<<" "<<cD.menu_color1<<"The program can be played only with keyboard input."<<RSTA<<"\n"
    <<"          "<<cD.menu_color1<<"Every menu point has a number front of it. "<<RSTA<<"\n"
    <<"          "<<cD.menu_color1<<"Press the number when you asked to choose, then press enter."<<RSTA<<"\n"
    <<"          "<<cD.menu_color1<<"(You need to press \33[4mENTER\33[0m"<<cD.menu_color1<<", that’s how you confirm your input.)"<<RSTA<<"\n"
    <<"          "<<cD.menu_color1<<"Going back from a menu via selecting ("<<cD.back_color<<"back"<<RSTA<<cD.menu_color1<<") usually a ‘"<<BRIGHT<<"0"<<RSTA<<cD.menu_color1<<"’ to enter."<<RSTA<<"\n"
	<<endl;

cout<<cD.back_color<<"Can I stop/pause my game/progress?"<<RSTA<<"\n"<<endl; 

cout<<"   "<<cD.menu_color1<<"Yes. You’ll have the chance to quit playing in each round via entering ‘Q’\n"
    <<"or ‘q’ in single player mode. Your accumulated progress will be saved until\n"
    <<"that moment, including your unlocked milestones and if your lives were more\n"
    <<"then 3, you’ll get to keep the extra lives for the next session too. \n"
    <<"(\33[4mNote:\33[0m"<<cD.menu_color1<<" Session score, skips will reset after each session.)\n"<<RSTA<<endl;

cout<<"    "<<cD.menu_color1<<"In multiplayer mode you’ll have the chance to abort the game too.\n"
	<<"After each round you’ll have the option to enter \'Q\' in order to stop or\n"
	<<"during game entering \'Q\' as an answer. (Other players still will be able to\n"
	<<"finish that round. You can play through all the targeted rounds,\n"
	<<"or if you loose all of your lives, that way the game play will terminate too.\n"<<RSTA<<endl;

cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
cin.get();

cout<<endl;

cout<<cD.back_color<<"How precise answer I must give for a division equation?"<<RSTA<<"\n"<<endl;

cout<<"  "<<cD.menu_color1<<"If the equation’s answer is a whole number, enter only the whole number."<<RSTA<<"\n"<<endl;
         
cout<<"     "<<cD.menu_color2<<"Sample:"<<RSTA<<" "<<cD.equation_color1<<"5"<<RSTA<<" "<<cD.operation_color<<":"<<RSTA<<" "<<cD.equation_color2<<"5"<<RSTA<<" "<<cD.operation_color<<"="<<RSTA<<" "<<FGREENBOLD<<"1"<<RSTA<<"\n"<<endl;

cout<<"  "<<cD.menu_color1<<"If the equation’s answer is required to enter decimal numbers too, then round"<<RSTA<<"\n"
    <<"  "<<cD.menu_color1<<"your answer to the nearest. Use max two decimal digits."<<RSTA<<"\n"
    <<"  "<<cD.menu_color1<<"If your answer requires only one decimal digit, enter only that one."<<RSTA<<"\n"
    <<"  "<<ITALIC<<"(\33[1mPlease do NOT enter tailing zero(s)! As such answer won’t be accepted.)"<<RSTA<<"\n"<<endl;
	

cout<<"     "<<cD.menu_color2<<"Sample:"<<RSTA<<"  "<<cD.equation_color1<<"3"<<RSTA<<" "<<cD.operation_color<<":"<<RSTA<<" "<<cD.equation_color2<<"2"<<RSTA<<" "<<cD.operation_color<<"="<<RSTA<<" "<<FGREENBOLD<<"1.5"<<RSTA<<"   "<<cD.menu_color1<<"Do NOT enter the tailing zero"<<RSTA<<" \33[31m1.50"<<RSTA<<"\n"<<endl;

cout<<"     "<<cD.menu_color2<<"Sample:"<<RSTA<<" "<<cD.equation_color1<<"10"<<RSTA<<" "<<cD.operation_color<<":"<<RSTA<<" "<<cD.equation_color2<<"3"<<RSTA<<" "<<cD.operation_color<<"="<<RSTA<<" "<<FGREENBOLD<<"3.33"<<RSTA"    "<<cD.menu_color1<<"If the answer would be longer then two decimals,"<<RSTA<<"\n"<<endl;
cout<<"                               "<<cD.menu_color1<<"you’ll round the answer to the nearest."<<RSTA<<"\n"
	<<"                               "<<cD.menu_color1<<"(In this case, down) 2 decimal precision."<<RSTA<<"\n"<<endl;

cout<<"     "<<cD.menu_color2<<"Sample:"<<RSTA<<"  "<<cD.equation_color1<<"5"<<RSTA<<" "<<cD.operation_color<<":"<<RSTA<<" "<<cD.equation_color2<<"9"<<RSTA<<" "<<cD.operation_color<<"="<<RSTA<<" "<<FGREENBOLD<<"0.56"<<RSTA<<"  "<<cD.menu_color1<<"(As the answer is 0.5555… You’ll round up to 0.56)"<<RSTA<<"\n"<<endl;


cout<<cD.keret_color<<"==============================================================================="<<RSTA<<"\n"<<endl;


cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
cin.get();
system("clear");

cout<<endl;


cout<<cD.back_color<<"Unlockable milestones"<<RSTA<<"\n"<<endl;

cout<<" "<<FYELLOW<<"1;"<<RSTA<<" "<<cD.menu_color1<<"Give"<<RSTA<<"  "<<FGREENBOLD<<"3"<<RSTA<<" "<<cD.menu_color1<<"good answer in a row"<<RSTA<<"\n"
	<<" "<<FYELLOW<<"2;"<<RSTA<<" "<<cD.menu_color1<<"Give"<<RSTA<<"  "<<FGREENBOLD<<"5"<<RSTA<<" "<<cD.menu_color1<<"good answer in a row"<<RSTA<<"\n"
	<<" "<<FYELLOW<<"3;"<<RSTA<<" "<<cD.menu_color1<<"Give"<<RSTA<<" "<<FGREENBOLD<<"10"<<RSTA<<" "<<cD.menu_color1<<"good answer in a row"<<RSTA<<"\n"
	<<" "<<FYELLOW<<"4;"<<RSTA<<" "<<cD.menu_color1<<"Give"<<RSTA<<" "<<FGREENBOLD<<"50"<<RSTA<<" "<<cD.menu_color1<<"good answer in a row"<<RSTA<<"\n"<<endl;

cout<<" "<<FYELLOW<<"5;"<<RSTA<<" "<<cD.menu_color1<<"Reach"<<RSTA<<"   "<<FGREENBOLD<<"100"<<RSTA<<" "<<cD.menu_color1<<"score in a single session"<<RSTA<<"\n"
	<<" "<<FYELLOW<<"6;"<<RSTA<<" "<<cD.menu_color1<<"Reach"<<RSTA<<"  "<<FGREENBOLD<<"1000"<<RSTA<<" "<<cD.menu_color1<<"score in a single session  \33[3m(This milestone unlocks MASTER level)"<<RSTA<<"\n"
	<<" "<<FYELLOW<<"7;"<<RSTA<<" "<<cD.menu_color1<<"Reach"<<RSTA<<"  "<<FGREENBOLD<<"5000"<<RSTA<<" "<<cD.menu_color1<<"score in a single session"<<RSTA<<"\n"
	<<" "<<FYELLOW<<"8;"<<RSTA<<" "<<cD.menu_color1<<"Reach"<<RSTA<<" "<<FGREENBOLD<<"10000"<<RSTA<<" "<<cD.menu_color1<<"score in a single session"<<RSTA<<"\n"<<endl;

cout<<" "<<FYELLOW<<"9;"<<RSTA<<" "<<cD.menu_color1<<"Reach"<<RSTA<<"  "<<FGREENBOLD<<"5"<<RSTA<<" "<<cD.menu_color1<<"life in a single session"<<RSTA<<"\n"
		<<FYELLOW<<"10;"<<RSTA<<" "<<cD.menu_color1<<"Reach"<<RSTA<<" "<<FGREENBOLD<<"10"<<RSTA<<" "<<cD.menu_color1<<"life in a single session"<<RSTA<<"\n"<<endl;

cout<<endl;

cout<<FYELLOW<<"11;"<<RSTA<<" "<<cD.menu_color1<<"Play"<<"  "<<FGREENBOLD<<"10"<<RSTA<<" "<<cD.menu_color1<<"round in a single session"<<RSTA<<"\n"
	<<FYELLOW<<"12;"<<RSTA<<" "<<cD.menu_color1<<"Play"<<"  "<<FGREENBOLD<<"50"<<RSTA<<" "<<cD.menu_color1<<"round in a single session"<<RSTA<<"\n"
	<<FYELLOW<<"13;"<<RSTA<<" "<<cD.menu_color1<<"Play"<<" "<<FGREENBOLD<<"100"<<RSTA<<" "<<cD.menu_color1<<"round in a single session"<<RSTA<<"\n"<<endl;


cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
cin.get();
cout<<endl;
cout<<FYELLOW<<"Giving a good answer in less then 5 second\" - milestone"<<RSTA<<"\n";
cout<<FYELLOW<<"14; On \33[;37mEASY\33[0m ";
cout<<FYELLOW<<" | 15; On \33[1;32mNORMAL\33[1;37m ";
cout<<FYELLOW<<" | 16; On \33[1;33mEXPERT\33[1;37m ";
cout<<FYELLOW<<" | 17; On \33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m"<<endl;
cout<<FYELLOW<<"Giving a good answer in less then 3 second\" - milestone"<<RSTA<<"\n";
cout<<FYELLOW<<"18; On \33[;37mEASY\33[0m ";
cout<<FYELLOW<<" | 19; On \33[1;32mNORMAL\33[1;37m ";
cout<<FYELLOW<<" | 20; On \33[1;33mEXPERT\33[1;37m ";
cout<<FYELLOW<<" | 21; On \33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m"<<endl;
cout<<FYELLOW<<"Giving a good answer in less then 1 second\" - milestone"<<RSTA<<"\n";
cout<<FYELLOW<<"22; On \33[;37mEASY\33[0m ";
cout<<FYELLOW<<" | 23; On \33[1;32mNORMAL\33[1;37m ";
cout<<FYELLOW<<" | 24; On \33[1;33mEXPERT\33[1;37m ";
cout<<FYELLOW<<" | 25; On \33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m"<<endl;
cout<<endl;

cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
cin.get();
cout<<endl;

cout<<FYELLOW<<"26;"<<RSTA<<" "<<cD.menu_color1<<"Reach"<<RSTA<<" "<<FGREENBOLD<<"1000"<<RSTA<<" "<<cD.menu_color1<<"score in "<<RSTA<<FGREENBOLD<<"100"<<RSTA<<" "<<cD.menu_color1<<"round"<<RSTA<<"\n"<<endl;

cout<<FYELLOW<<"27;"<<RSTA<<" "<<cD.menu_color1<<"Play"<<"  "<<FGREENBOLD<<"10"<<RSTA<<" "<<cD.menu_color1<<"session"<<RSTA<<"\n"
	<<FYELLOW<<"28;"<<RSTA<<" "<<cD.menu_color1<<"Play"<<"  "<<FGREENBOLD<<"50"<<RSTA<<" "<<cD.menu_color1<<"session"<<RSTA<<"\n"
	<<FYELLOW<<"29;"<<RSTA<<" "<<cD.menu_color1<<"Play"<<" "<<FGREENBOLD<<"100"<<RSTA<<" "<<cD.menu_color1<<"session"<<RSTA<<"\n"<<endl;

cout<<FYELLOW<<"30;"<<RSTA<<" "<<cD.menu_color1<<"Reach all-time score:"<<RSTA<<"   "<<FGREENBOLD<<"100 000"<<RSTA<<"\n"
	<<FYELLOW<<"31;"<<RSTA<<" "<<cD.menu_color1<<"Reach all-time score:"<<RSTA<<" "<<FGREENBOLD<<"1 000 000"<<RSTA<<"\n"<<endl;


cout<<cD.keret_color<<"==============================================================================="<<RSTA<<"\n"<<endl;


cout<<cD.menu_color1<<"Have fun while you playfully practice your numbers."<<RSTA<<"\n"
	<<cD.menu_color1<<"By regularly exercising your “brain muscles” you can keep on top of your"<<RSTA<<"\n"
	<<cD.menu_color1<<"thinking, and on top of your calculation skills."<<RSTA<<"\n"<<endl;


cout<<cD.menu_color2<<"                                       "<<"Enjoy! \33[3;33m:)\33[0m  \33[3m(… or not… It’s your choice)"<<RSTA<<"\n"<<endl;
		
}
//--------------------------------------------------------------------------------------------------

//mplayer color preview fn

void mPlayerColor_previewFn(){
	
	cout<<"          "<<colorDefault.menu_color1<<"- PREVIEW DISPLAY -\n"
								<<colorDefault.keret_color<<"***************************************************"<<RSTA<<"\n"
								<<colorDefault.keret_color<<"*"<<RSTA<<colorDefault.menu_color1<<" Player's"<<RSTA<<" "<<colorDefault.menu_color2<<"Name"
								<<RSTA<<"       "<<colorDefault.menu_color1<<"Session's Total Score:"<<RSTA<<" "<<colorDefault.menu_color2
								<<"2344 "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<"                                               \n"
								<<"           "<<colorDefault.equattionText_color<<"Equation:"<<RSTA<<" "
								<<colorDefault.equation_color1<<"33"<<RSTA<<" "<<colorDefault.operation_color<<"/"<<RSTA<<" "
								<<colorDefault.equation_color2
								<<"7"<<RSTA<<" "<<colorDefault.operation_color<<"="<<RSTA"          "<<colorDefault.keret_color<<"*\n"
								<<"*"<<RSTA<<"                                                 \n"
								<<colorDefault.keret_color<<"***************************************************"<<RSTA"\n"
								<<"\n"
								<<"      "<<colorDefault.menu_color1<<"Your answer:"<<RSTA<<" "<<colorDefault.youranswer_color<<"4.71"<<RSTA"\n"
								<<"\n"
								<<RSTA"           "<<colorDefault.yes_color<<"YES"<<RSTA<<" "<<colorDefault.smily_color<<":)"<<RSTA<<"\n"
								<<"\n"
								<<"              "<<colorDefault.next_color<<"NEXT"<<colorDefault.keret_color
								<<"("<<colorDefault.next_color<<"n"
								<<colorDefault.keret_color<<")"<<RSTA
								<<"  or  "<<colorDefault.stop_color<<"STOP"<<colorDefault.keret_color
								<<"("<<colorDefault.stop_color<<"s"
								<<colorDefault.keret_color<<")"<<RSTA"\n"
								<<"                   "<<colorDefault.equation_color1<<"-->"<<RSTA
								//if your answer 'n' color same as next. if 's' color is same as stop...
								<<colorDefault.menu_color1<<" n"<<RSTA<<"\n"
								<<"\n"
								<<colorDefault.keret_color<<"*"<<RSTA<<"    "<<colorDefault.itsnotanumber_color<<"This is not a number"<<RSTA<<"             "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<"              "<<colorDefault.tryagain_color<<"Please, try again!"<<RSTA<<"      "<<colorDefault.keret_color<<"*"<<RSTA<<"\n"
								<<colorDefault.keret_color<<"****************************************************"<<RSTA<<"\n"
								<<endl;
}
//---------------------------------------------------------------------------------------------------------------------

string auto_round_stateFn_V5(){
	string state_autoRound_switch;
	if(mp_auto_round){state_autoRound_switch = "\33[1;32mON\33[0m";}
	else if(!mp_auto_round){state_autoRound_switch = "\33[1;31mOFF\33[0m";}
	return state_autoRound_switch;
}
//-------------------------------------

string auto_turn_stateFn_V5(){
	string state_autoTurn_switch;
	if(mp_auto_turn){state_autoTurn_switch = "\33[1;32mON\33[0m";}
	else if(!mp_auto_turn){state_autoTurn_switch = "\33[1;31mOFF\33[0m";}
	return state_autoTurn_switch;
}
//-----------------------------------------------------------------------------
//achived achivements display page
void unlocked_achivementsFn_V5(SplayerClass obj){
system("clear");

cout<<endl;

//colorcode as alternate lines black bground
// add green unlocked, red lock at the end of appropriate milestone
//sync with actual progress, make sure its working with save/load

cout<<"    "<<cD.keret_color<<"***"<<RSTA<<" "<<FREDBOLD_BBLACK<<"L O C K E D"<<RSTA<<" and "<<FGREEN_BDARK<<"U N L O C K E D"<<RSTA<<" "<<BRIGHT<<"M I L E S T O N E S"<<RSTA<<" "<<cD.keret_color<<"***"<<RSTA"\n"<<endl;

cout<<" "<<BRIGHT<<"1; \"Give  3 good answer in a row\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_1_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_1_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<" "<<BBLACK<<"\33[1m2; \"Give  5 good answer in a row\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_2_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_2_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<" "<<BRIGHT<<"3; \"Give 10 good answer in a row\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_3_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_3_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<" "<<BBLACK<<"\33[1m4; \"Give 50 good answer in a row\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_13_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_13_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<endl;

cout<<" "<<BRIGHT<<"5; \"Reach   100 score in a single session\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_4_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_4_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<" "<<BBLACK<<"\33[1m6; \"Reach  1000 score in a single session\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_7_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_7_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<" "<<BRIGHT<<"7; \"Reach  5000 score in a single session\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_8_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_8_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<" "<<BBLACK<<"\33[1m8; \"Reach 10000 score in a single session\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_17_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_17_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<endl;

cout<<" "<<BRIGHT<<"9; \"Reach  5 life in a single session\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_5_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_5_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<BBLACK<<"\33[1m10; \"Reach 10 life in a single session\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_6_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_6_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<endl;

cout<<BRIGHT<<"11; \"Play  10 round in a single session\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_9_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_9_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<BBLACK<<"\33[1m12; \"Play  50 round in a single session\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_10_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_10_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<BRIGHT<<"13; \"Play 100 round in a single session\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_11_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_11_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<endl;	
cout<<"              "<<"Press \33[1mENTER\33[0m to continue...\n"<<endl;
cin.get();
cin.get();

cout<<BBLACK<<"\33[1m\"Giving a good answer in less then 5 second\" - milestone"<<RSTA<<"\n";
cout<<BRIGHT<<  "14; On EASY - ";
	if(obj.milestone_5sec_easy_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA;}
	else if(!obj.milestone_5sec_easy_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA;}
cout<<BRIGHT<<" \t| 15; On \33[1;32mNORMAL\33[1;37m - ";
	if(obj.milestone_5sec_normal_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.milestone_5sec_normal_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<BRIGHT<<"16; On \33[1;33mEXPERT\33[1;37m - ";
	if(obj.milestone_5sec_expert_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA;}
	else if(!obj.milestone_5sec_expert_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA;}
cout<<BRIGHT<<" \t| 17; On \33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m"<<BRIGHT<<" - ";
	if(obj.milestone_5sec_master_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.milestone_5sec_master_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<endl;		
cout<<BBLACK<<"\33[1m\"Giving a good answer in less then 3 second\" - milestone"<<RSTA<<"\n";
	cout<<BRIGHT<<  "18; On EASY - ";
	if(obj.milestone_3sec_easy_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA;}
	else if(!obj.milestone_3sec_easy_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA;}
cout<<BRIGHT<<" \t| 19; On \33[1;32mNORMAL\33[1;37m - ";
	if(obj.milestone_3sec_normal_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.milestone_3sec_normal_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<BRIGHT<<"20; On \33[1;33mEXPERT\33[1;37m - ";
	if(obj.milestone_3sec_expert_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA;}
	else if(!obj.milestone_3sec_expert_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA;}
cout<<BRIGHT<<" \t| 21; On \33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m"<<BRIGHT<<" - ";
	if(obj.milestone_3sec_master_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.milestone_3sec_master_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<endl;	
cout<<BBLACK<<"\33[1m\"Giving a good answer in less then 1 second\" - milestone"<<RSTA<<"\n";
	cout<<BRIGHT<<  "22; On EASY - ";
	if(obj.milestone_1sec_easy_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA;}
	else if(!obj.milestone_1sec_easy_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA;}
cout<<BRIGHT<<" \t| 23; On \33[1;32mNORMAL\33[1;37m - ";
	if(obj.milestone_1sec_normal_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.milestone_1sec_normal_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<BRIGHT<<"24; On \33[1;33mEXPERT\33[1;37m - ";
	if(obj.milestone_1sec_expert_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA;}
	else if(!obj.milestone_1sec_expert_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA;}
cout<<BRIGHT<<" \t| 25; On \33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m"<<BRIGHT<<" - ";
	if(obj.milestone_1sec_master_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.milestone_1sec_master_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}

cout<<endl;
cout<<"              "<<"Press \33[1mENTER\33[0m to continue...\n"<<endl;
cin.get();	


cout<<BRIGHT<<"26; \"Reach 1000 score in 100 round\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_12_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_12_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<endl;

cout<<BBLACK<<"\33[1m27; \"Play  10 session\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_14_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_14_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<BRIGHT<<"28; \"Play  50 session\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_15_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_15_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<BBLACK<<"\33[1m29; \"Play 100 session\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_16_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_16_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<endl;

cout<<BRIGHT<<"30; \"Reach all-time score:   100 000\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_17andHalf_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_17andHalf_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<BBLACK<<"\33[1m31; \"Reach all-time score: 1 000 000\" - milestone"<<RSTA<<" - ";
	if(obj.sp_milestone_18_V5){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sp_milestone_18_V5){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;}
cout<<endl;

cout<<cD.keret_color<<"==============================================================================="<<RSTA<<"\n"<<endl;

cout<<"    "<<"\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m"<<BRIGHT<<" LEVEL"<<RSTA<<" - ";
	if(obj.sP_masterlevel_unlocked){cout<<BBLACK<<"\33[1;32mUNLOCKED"<<RSTA<<endl;}
	else if(!obj.sP_masterlevel_unlocked){cout<<BBLACK<<"\33[1;31mLOCKED"<<RSTA<<endl;} // if unlocked -> green, else: red
cout<<endl;
cout<<"    "<<BRIGHT<<"You've already unlocked "<<cD.menu_color1<<obj.sP_milestonesUnlocked_counter_displayFn_V5()<<RSTA<<BRIGHT<<" out of "<<cD.menu_color2<<"31"<<RSTA<<endl; //get the counters here x out of 19
if(obj.sp_milestone_18_V5){
	cout<<"    "<<cD.menu_color1<<"Shortcut to \"Final achievement\": "<<cD.equattionText_color<<"5110"<<RSTA<<endl;
	cout<<"    "<<cD.menu_color2<<"To go to text: Enter this code when you are in single player menu."<<RSTA<<endl;
}

cout<<"    "<<"Press \33[1mENTER\33[0m to go back to single player menu...\n"<<endl;

cin.get();

}
//==================================================================================================
