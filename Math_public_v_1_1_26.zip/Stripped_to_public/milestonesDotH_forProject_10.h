//Milestones.h file for Project_10 (Math chellenge software)
#ifndef _MILESTONES_
#define _MILESTONES_
#include <cstring> 
#include <iostream>
#include <unistd.h>
#include <iomanip>
using namespace std;
//----------------------------------------------------------------------

// add Unlocked milestones statistic menu and a breef discription as the full  display without setters
// so player can go back and see/ show achivements.... what is unlocked....
int allMilestonesProgress_inDotH = 0; // Need save/load per Player the progress!!!
bool milestone_extraLifeFor_3inRow = true;
		bool milestone_reaching_100_ScoreInSingleSession = true;
		bool milestone_extraLifeFor_5inRow = true;
		bool milestone_extraLifeFor_10inRow = true;
		bool milestone_reaching5_lifes = true;
		bool milestone_reaching10_lifes = true;
		bool milestone_reaching1000_ScoreInSingleSession = true; // it unlocks master level too...
		bool masterSwitch_h = false;
		bool milestone_reaching5000_ScoreInSingleSession = true;
		bool milestone_reaching_10RoundsInSession = true;
		bool milestone_reaching_100RoundsInSession = true;
		bool milestone_reaching_50RoundsInSession = true;
		bool milestone_reaching_1000Score_in100Rounds = true;
		bool milestone_extraLifeFor_50inRow = true;
		bool milestone_reaching10_sessions = true;
		bool milestone_reaching50_sessions = true;
		bool milestone_reaching100_sessions = true;
		bool milestone_reaching10000_ScoreInSingleSession = true;
		bool milestone_reaching100000_AllTimeScore = true; //hundred tousend
		bool milestone_reaching1000000_AllTimeScore = true; // one million
		
		bool allMilestonesUnlocked = false; // unlocked/ true if "allMilestonesProgress" hits 18 (unlocked all Milestones)
		
		bool milestone_1_h = false;
		bool milestone_2_h = false;
		bool milestone_3_h = false;
		bool milestone_4_h = false;
		bool milestone_5_h = false;
		bool milestone_6_h = false;
		bool milestone_7_h = false;
		bool milestone_8_h = false;
		bool milestone_9_h = false;
		bool milestone_10_h = false;
		bool milestone_11_h = false;
		bool milestone_12_h = false;
		bool milestone_13_h = false;
		bool milestone_14_h = false;
		bool milestone_15_h = false;
		bool milestone_16_h = false;
		bool milestone_17_h = false;
		bool milestone_17andHalf_h = false;
		bool milestone_18_h = false;
		bool milestone_5sec_easy_dotH = false;
		bool milestone_3sec_easy_dotH = false;
		bool milestone_1sec_easy_dotH = false;
		bool milestone_5sec_normal_dotH = false;
		bool milestone_3sec_normal_dotH = false;
		bool milestone_1sec_normal_dotH = false;
		bool milestone_5sec_expert_dotH = false;
		bool milestone_3sec_expert_dotH = false;
		bool milestone_1sec_expert_dotH = false;
		bool milestone_5sec_master_dotH = false;
		bool milestone_3sec_master_dotH = false;
		bool milestone_1sec_master_dotH = false;
//--------------------------------------------------------------------------------

//--------------------------------------------------------------------------------
//message Fns

//20,21,22; Giving a good answer in 5, 3 or 1 sec | On EASY diff // ! only once per profile appears!
void milestone_givingGood_Ans_in_less_then_5_easy_Fn(double i){
	if(i <= 5 && i > 3){
		
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"                          \33[1mWAO! U R QUICK!\33[0m\n";
		cout<<"               **************************************\n"
			<<"               *          + 1 EXTRA LIFE :)         *\n"
			<<"               *     For giving a good answer in    *\n"
			<<"               *        less then \33[1m5\33[0m second!         *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_5sec_easy_dotH){
			allMilestonesProgress_inDotH++;
			milestone_5sec_easy_dotH = true;
			
			cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
			cin.get();
			} // so it doesnt triggered more then Once!
	}
}
//---------------------------------------------------------------------------
void milestone_givingGood_Ans_in_less_then_3_easy_Fn(double i){
	if(i <= 3 && i > 1){
		
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"                    \33[1mWAO! U R GETTING VERY QUICK\33[0m\n";
		cout<<"               **************************************\n"
			<<"               *          + 2 EXTRA LIFE :)         *\n"
			<<"               *     For giving a good answer in    *\n"
			<<"               *        less then \33[1m3\33[0m second!         *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_3sec_easy_dotH){
			allMilestonesProgress_inDotH++;
			milestone_3sec_easy_dotH = true;
			
			cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
			cin.get();
			} // so it doesnt triggered more then Once!
	}
}
//-------------------------------------------------------------------------------
void milestone_givingGood_Ans_in_less_then_1_easy_Fn(double i){
	if(i <= 1 && i > 0){
		
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"                   WAO! IS YOUR NICKNAME \"FLASH\"?\n";
		cout<<"               **************************************\n"
			<<"               *          + 3 EXTRA LIFE :)         *\n"
			<<"               *     For giving a good answer in    *\n"
			<<"               *        less then \33[1m1\33[0m second!         *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_1sec_easy_dotH){
			allMilestonesProgress_inDotH++;
			milestone_1sec_easy_dotH = true;
		
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		} // so it doesnt triggered more then Once!
	}
}

//------------------------------------NORMAL--------------------------------------------------------

//23,24,25; Giving a good answer in 5, 3 or 1 sec | On EASY diff // ! only once per profile appears!
void milestone_givingGood_Ans_in_less_then_5_normal_Fn(double i){
	if(i <= 5 && i > 3){
		
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"                          \33[1mWAO! U R QUICK!\33[0m\n";
		cout<<"               **************************************\n"
			<<"               *          + 1 EXTRA LIFE :)         *\n"
			<<"               *     For giving a good answer in    *\n"
			<<"               *        less then \33[1m5\33[0m second!         *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_5sec_normal_dotH){
			allMilestonesProgress_inDotH++;
			milestone_5sec_normal_dotH = true;
			
			cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
			cin.get();
			} // so it doesnt triggered more then Once!
	}
}
//---------------------------------------------------------------------------
void milestone_givingGood_Ans_in_less_then_3_normal_Fn(double i){
	if(i <= 3 && i > 1){
		
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"                    \33[1mWAO! U R GETTING VERY QUICK\33[0m\n";
		cout<<"               **************************************\n"
			<<"               *          + 2 EXTRA LIFE :)         *\n"
			<<"               *     For giving a good answer in    *\n"
			<<"               *        less then \33[1m3\33[0m second!         *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_3sec_normal_dotH){
			allMilestonesProgress_inDotH++;
			milestone_3sec_normal_dotH = true;
			
			cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
			cin.get();
			} // so it doesnt triggered more then Once!
	}
}
//-------------------------------------------------------------------------------
void milestone_givingGood_Ans_in_less_then_1_normal_Fn(double i){
	if(i <= 1 && i > 0){
		
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"                   WAO! IS YOUR NICKNAME \"FLASH\"?\n";
		cout<<"               **************************************\n"
			<<"               *          + 3 EXTRA LIFE :)         *\n"
			<<"               *     For giving a good answer in    *\n"
			<<"               *        less then \33[1m1\33[0m second!         *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_1sec_normal_dotH){
			allMilestonesProgress_inDotH++;
			milestone_1sec_normal_dotH = true;
		
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		} // so it doesnt triggered more then Once!
	}
}
//--------------------------------------EXPERT------------------------------------------------------
//26,27,28; Giving a good answer in 5, 3 or 1 sec | On EASY diff // ! only once per profile appears!
void milestone_givingGood_Ans_in_less_then_5_expert_Fn(double i){
	if(i <= 5 && i > 3){
		
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"                          \33[1mWAO! U R QUICK!\33[0m\n";
		cout<<"               **************************************\n"
			<<"               *          + 1 EXTRA LIFE :)         *\n"
			<<"               *     For giving a good answer in    *\n"
			<<"               *        less then \33[1m5\33[0m second!         *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_5sec_expert_dotH){
			allMilestonesProgress_inDotH++;
			milestone_5sec_expert_dotH = true;
			
			cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
			cin.get();
			} // so it doesnt triggered more then Once!
	}
}
//---------------------------------------------------------------------------
void milestone_givingGood_Ans_in_less_then_3_expert_Fn(double i){
	if(i <= 3 && i > 1){
		
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"                    \33[1mWAO! U R GETTING VERY QUICK\33[0m\n";
		cout<<"               **************************************\n"
			<<"               *          + 2 EXTRA LIFE :)         *\n"
			<<"               *     For giving a good answer in    *\n"
			<<"               *        less then \33[1m3\33[0m second!         *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_3sec_expert_dotH){
			allMilestonesProgress_inDotH++;
			milestone_3sec_expert_dotH = true;
			
			cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
			cin.get();
			} // so it doesnt triggered more then Once!
	}
}
//-------------------------------------------------------------------------------
void milestone_givingGood_Ans_in_less_then_1_expert_Fn(double i){
	if(i <= 1 && i > 0){
		
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"                   WAO! IS YOUR NICKNAME \"FLASH\"?\n";
		cout<<"               **************************************\n"
			<<"               *          + 3 EXTRA LIFE :)         *\n"
			<<"               *     For giving a good answer in    *\n"
			<<"               *        less then \33[1m1\33[0m second!         *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_1sec_expert_dotH){
			allMilestonesProgress_inDotH++;
			milestone_1sec_expert_dotH = true;
		
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		} // so it doesnt triggered more then Once!
	}
}
//-----------------------------------MASTER---------------------------------------------------------
//29,30,31; Giving a good answer in 5, 3 or 1 sec | On EXPERT diff // ! only once per profile appears!
void milestone_givingGood_Ans_in_less_then_5_master_Fn(double i){
	if(i <= 5 && i > 3){
		
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"                          \33[1mWAO! U R QUICK!\33[0m\n";
		cout<<"               **************************************\n"
			<<"               *          + 1 EXTRA LIFE :)         *\n"
			<<"               *     For giving a good answer in    *\n"
			<<"               *        less then \33[1m5\33[0m second!         *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_5sec_master_dotH){
			allMilestonesProgress_inDotH++;
			milestone_5sec_master_dotH = true;
			
			cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
			cin.get();
			} // so it doesnt triggered more then Once!
	}
}
//---------------------------------------------------------------------------
void milestone_givingGood_Ans_in_less_then_3_master_Fn(double i){
	if(i <= 3 && i > 1){
		
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"                    \33[1mWAO! U R GETTING VERY QUICK\33[0m\n";
		cout<<"               **************************************\n"
			<<"               *          + 2 EXTRA LIFE :)         *\n"
			<<"               *     For giving a good answer in    *\n"
			<<"               *        less then \33[1m3\33[0m second!         *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_3sec_master_dotH){
			allMilestonesProgress_inDotH++;
			milestone_3sec_master_dotH = true;
			
			cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
			cin.get();
			} // so it doesnt triggered more then Once!
	}
}
//-------------------------------------------------------------------------------
void milestone_givingGood_Ans_in_less_then_1_master_Fn(double i){
	if(i <= 1 && i > 0){
		
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"                   WAO! IS YOUR NICKNAME \"FLASH\"?\n";
		cout<<"               **************************************\n"
			<<"               *          + 3 EXTRA LIFE :)         *\n"
			<<"               *     For giving a good answer in    *\n"
			<<"               *        less then \33[1m1\33[0m second!         *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_1sec_master_dotH){
			allMilestonesProgress_inDotH++;
			milestone_1sec_master_dotH = true;
		
		cout<<"Press \33[1mENTER\33[0m to continue..."<<endl;
		cin.get();
		} // so it doesnt triggered more then Once!
	}
}
//--------------------------------------------------------------------------------------------------
//==================================================================================================

// 1; After every 3 correct answer in a row you'll get an extra life.
void milestone_extraLifeFor_3inRowFn(int i){
	if(i == 3 && milestone_extraLifeFor_3inRow){ // i reset if you give a false answer
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		cout<<"               **************************************\n"
			<<"               *          + 1 EXTRA LIFE :)         *\n"
			<<"               * for giving 3 good answer in a row! *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_1_h){
			allMilestonesProgress_inDotH++;
			milestone_1_h = true;} // so it doesnt triggered more then Once!
		
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
//--------------------------------------------------------------------------------------------------	
// 2; After 5 in a row correct answers: Message pop up, plus 1 extra life.
void milestone_extraLifeFor_5inRowFn(int i){
	if(i == 5 && milestone_extraLifeFor_5inRow){ // i reset if you give a false answer
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"               **************************************\n"
			<<"               *          + 1 EXTRA LIFE :)         *\n"
			<<"               * for giving 5 good answer in a row! *\n"
			<<"               *           WELL DONE YOU!           *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_2_h){
			allMilestonesProgress_inDotH++;
			milestone_2_h = true;} // so it doesnt triggered more then Once!
		}
		//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
/* 3; 10 in a row: Message: Mate, you are a Legend, I'm proud of you!
	You are using your brain! Well done! Keep going, I like the 
	commitment! + extra 2 lifes.
*/
void milestone_extraLifeFor_10inRowFn(int i){
	if(i == 10 && milestone_extraLifeFor_10inRow){ // i reset if you give a false answer
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"               *********************************************\n"
			<<"               * Mate, you are a Legend! I'm proud of you! *\n"
			<<"               * You  are  using  your  brain!  Well done! *\n"
			<<"               * Keep going!  I like the fact that you are *\n"
			<<"               * using   your   brain,  great  effort  and *\n"
			<<"               *          - c o m m i t m e n t ! -        *\n"
			<<"               *                                           *\n"
			<<"               *             + 2 EXTRA LIFE :)             *\n"
			<<"               * for  giving  10  good  answer  in a row ! *\n"
			<<"               *              WELL DONE YOU!               *\n"
			<<"               *********************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_3_h){
			allMilestonesProgress_inDotH++;
			milestone_3_h = true;} // so it doesnt triggered more then Once!
		// Also if you are standing at 4 lifes you recieve automaticly the 
		// Five life milestone too (as this gives you 2 extra lifes)
		
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
// 4; Reaching 100 score in one session: Message Pop Up, plus 1 extra life.
void milestone_reaching100ScoreInSingleSessionFn(int i){
	if(i >= 100 && milestone_reaching_100_ScoreInSingleSession){
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"               **************************************\n"
			<<"               *   \"If u don't use it, lose it...\"  *\n"
			<<"               *       *** Keep practicing! ***     *\n"
			<<"               *                                    *\n"
			<<"               *            WELL DONE YOU!          *\n"
			<<"               *  That's 100 score in this session! *\n"
			<<"               *          + 1 EXTRA LIFE :)         *\n"
			<<"               **************************************\n"
			<<endl;
		milestone_reaching_100_ScoreInSingleSession = false; // only once per session so you wont see it again
		//														if score growes from 103 to 113 for exsample.
		sleep(1);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_4_h){
			allMilestonesProgress_inDotH++;
			milestone_4_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}


// 5; If you reach 5 lifes (you start with 3) Message: Mate, you r 
//    natural! :) + add extra 1 life.
void milestone_reaching5_lifesFn(int i){
	if(i == 5 && milestone_reaching5_lifes){ // as many times you reach 5 life this triggered
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"               **************************************\n"
			<<"               *         Mate, you r natural!       *\n"
			<<"               *   You're making LIFES! Reached: 5  *\n"
			<<"               *   So let me give you One more! :)  *\n"
			<<"               *          + 1 EXTRA LIFE            *\n"
			<<"               *                                    *\n"
			<<"               *   WELL DONE YOU! KEEP ON ROLLIN'!  *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(1);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_5_h){
			allMilestonesProgress_inDotH++;
			milestone_5_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
// 6; If you reach 10 lifes: Message: Noooo waaaay! How did you do that!
//	You are blowned my mind! -> little 1,2,3...10 Mind explosion anime.
//	+ add extra 2 life.
void milestone_reaching10_lifesFn(int i){
	if(i == 10 && milestone_reaching10_lifes){ // as many times you reach 10 life this triggered
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"               **************************************\n"
			<<"               *  Nooo waaay! How do you DO this?!  *\n";
		cout<<"               *   ";   	
		for(int b = 1;b<=9;b++){
			cout<<b<<", ";
			fflush(stdout);
			sleep(1); }
		cout<<"10  ";
		cout<<"  *\n";sleep(1);
		cout<<"               *                                    *\n";
		cout<<"              *  *** \33[5mM I N D  E X P L O S I O N\33[0m ***  *\n";
		sleep(1);
		cout<<"               *                                    *\n"
			<<"               *  You're making LIFES! Reached: 10  *\n"
			<<"               *   So let me give you TWO more! :)  *\n"
			<<"               *          + 2 EXTRA LIFE            *\n"
			<<"               *                                    *\n"
			<<"               *   WELL DONE YOU! KEEP ON ROLLIN'!  *\n"
			<<"               **************************************\n"
			<<endl;
		sleep(3);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_6_h){
			allMilestonesProgress_inDotH++;
			milestone_6_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
//7; If you reach 1000 score in one session -> clear screen and display:
//	1000 SCORE in center in a nice colorful frame + add extra 3 lifes.
void milestone_reaching1000_ScoreInSingleSessionFn(int i){
	if(i >= 1000 && milestone_reaching1000_ScoreInSingleSession){
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // Decorate message with Colors and check spelling!
		cout<<"               ********************************************\n"
			<<"               *              \33[1mWELL DONE YOU!\33[0m              *\n"
			<<"               *                                          *\n"
			<<"               *            *** \33[5m1000 SCORE\33[0m ***            *\n"
			<<"               *                                          *\n"
			<<"               * This is REAL dedication here, my friend! *\n"
			<<"               *  I'm real proud of you now, you know! :) *\n"
			<<"               *   Let me gift you an other THREE lifes   *\n"
			<<"               *        to express my grattitude!         *\n"
			<<"               *                                          *\n"
			<<"               *             + 3 EXTRA LIFE :)            *\n"
			<<"               *                                          *\n"
			<<"               *                                          *\n"
			<<"               *"<<"           >>> "<<"\33[1;31mM\33[1;32mA\33[1;33mS\33[1;34mT\33[1;35mE\33[1;36mR\33[0m \33[1;32mL\33[1;33mE\33[1;34mV\33[1;35mE\33[1;36mL\33[0m"<<" <<<           *\n"
			<<"               *"<<"               > "<<"\33[1;37mUNLOCKED\33[0m"<<" <               *\n"
			<<"               *                                          *\n"
			<<"               ********************************************\n"
			<<endl;
		milestone_reaching1000_ScoreInSingleSession = false; // only once per session so you wont see it again
		//														if score growes from 103 to 113 for exsample.
		sleep(1);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_7_h){
			masterSwitch_h = true;
			allMilestonesProgress_inDotH++;
			milestone_7_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
//8; If you reach 5000 score in a single session. Add + 5 lifes +
//	Message in the midle letter by letter anime...
void milestone_reaching5000_ScoreInSingleSessionFn(int i){
	if(i >= 5000 && milestone_reaching5000_ScoreInSingleSession){
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // Decorate message with Colors and check spelling!
		cout<<"               ********************************************\n"
			<<"               *              \33[1mWELL DONE YOU!\33[0m              *\n"
			<<"               *                                          *\n"
			<<"               *            *** \33[5m5000 SCORE\33[0m ***            *\n"
			<<"               *                                          *\n"
			<<"               * This is REAL dedication here, my friend! *\n"
			<<"               *  I'm real proud of you now, you know! :) *\n"
			<<"               *   Let me gift you an other FIVE lifes   *\n"
			<<"               *        to express my grattitude!         *\n"
			<<"               *                                          *\n"
			<<"               *             + 5 EXTRA LIFE :)            *\n"
			<<"               *                                          *\n"
			<<"               ********************************************\n"
			<<endl;
		milestone_reaching5000_ScoreInSingleSession = false; // only once per session so you wont see it again
		//														if score growes from 103 to 113 for exsample.
		sleep(1);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_8_h){
			allMilestonesProgress_inDotH++;
			milestone_8_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
// 9; Reach round 10 in a one session -> Message: Well done mate! You got
//	some level of commitement and math skills after all! + 1 life
//	I'll give you 1 extra life as my "aprutiation"! Keep going<<Player!
void milestone_reaching_10RoundsInSessionFn(int i){
	if(i == 10 && milestone_reaching_10RoundsInSession){ // as many times you reach 5 life this triggered
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"               ******** \33[10mTHAT'S the 10th ROUND!\33[0m ******\n"
			<<"               *                                    *\n"
			<<"               *           Mate, you r good!        *\n"
			<<"               *    You're making progress here!    *\n"
			<<"               * You have some level of commitement *\n"
			<<"               *     and math skills after all!     *\n"
			<<"               *   So let me give you a gift... :)  *\n"
			<<"               *          + 1 EXTRA LIFE            *\n"
			<<"               *                                    *\n"
			<<"               *   WELL DONE YOU! KEEP ON ROLLIN'!  *\n"
			<<"               **************************************\n"
			<<endl;
		//add the extras to the Player:
		// NEEDS to complate....
		milestone_reaching_10RoundsInSession = false;
		sleep(1);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_9_h){
			allMilestonesProgress_inDotH++;
			milestone_9_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
// 10; If you'll reach 50 rounds in one session. Message + 2 extra life.
//	And say: Mate, you might wanna take a little water in and out break!
void milestone_reaching_50RoundsInSessionFn(int i){
	if(i == 50 && milestone_reaching_50RoundsInSession){ // as many times you reach reset/session
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"               ***************************************\n"
			<<"               * Mate, you might wanna take a little *\n"
			<<"               *      water (in & out) break! :)     *\n"
			<<"               *       This is the \33[1m50th ROUND\33[0m in     *\n"
			<<"               *             this session!           *\n"
			<<"               *     I admire your commitement...    *\n"
			<<"               *        So let me gift you ...       *\n"
			<<"               *           \33[1m+ 2 EXTRA LIFE\33[0m            *\n"
			<<"               *                   :)                *\n"
			<<"               *    WELL DONE and KEEP ON ROLLIN'!   *\n"
			<<"               ***************************************\n"
			<<endl;
		//add the extras to the Player:
		// NEEDS to complate....
		milestone_reaching_10RoundsInSession = false;
		sleep(1);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_10_h){
			allMilestonesProgress_inDotH++;
			milestone_10_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
	
// 11; If you'll reach 100 rounds in one session. Message + 3 extra life.
void milestone_reaching_100RoundsInSessionFn(int i){
	if(i == 100 && milestone_reaching_100RoundsInSession){ // as many times you reach 5 life this triggered
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"               ************* \33[1m100th ROUND!\33[0m ***********\n"
			<<"               *                                    *\n"
			<<"               *           Mate, you r good!        *\n"
			<<"               *    You're making progress here!    *\n"
			<<"               * You have some level of commitement *\n"
			<<"               *     and math skills after all!     *\n"
			<<"               * So let me gift you 3 exta life! :) *\n"
			<<"               *                                    *\n"
			<<"               *          \33[5m+ 3 EXTRA LIFE\33[0m            *\n"
			<<"               *                                    *\n"
			<<"               *   WELL DONE and KEEP ON ROLLIN'!   *\n"
			<<"               **************************************\n"
			<<endl;
		//add the extras to the Player:
		// NEEDS to complate....
		milestone_reaching_10RoundsInSession = false;
		sleep(1);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_11_h){
			allMilestonesProgress_inDotH++;
			milestone_11_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
//12; Chellenge Inpossible: 1000 Score in 100 rounds. (Answerstreak 100)
//	Message: Mate, you don't need, but One life only! :) Well DONE!
void milestone_reaching_1000Score_in100RoundsFn(int score, int round){
	if(score >= 1000 && round <= 100 && milestone_reaching_1000Score_in100Rounds){ // Onetime achivement reset after achiving...
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"               **************************************\n"
			<<"               * Mate, you need, but ONE life only! *\n"
			<<"               *         You are remarkable!        *\n"
			<<"               * \33[5mReaching 1000 score in 100 round!\33[0m  *\n"
			<<"               *  Now, this is what I call: SKILL!  *\n"
			<<"               *                                    *\n"
			<<"               *           \33[1;31mC\33[0m"
			<<"\33[1;33mO\33[0m"
			<<"\33[1;32mN\33[0m"
			<<"\33[1;34mG\33[0m"
			<<"\33[1;35mR\33[0m"
			<<"\33[1;36mA\33[0m"
			<<"\33[1;37mT\33[0m"
			<<"\33[1;31mU\33[0m"
			<<"\33[1;33mL\33[0m"
			<<"\33[1;32mA\33[0m"
			<<"\33[1;34mT\33[0m"
			<<"\33[1;35mI\33[0m"
			<<"\33[1;36mO\33[0m"
			<<"\33[1;38mN\33[0m"
			<<"\33[1;31m!\33[0m"
			<<"          *\n" //add rainbow letter by letter into this line -> DONE
			<<"               *                                    *\n"
			<<"               **************************************\n"
			<<endl;
		//add the extras to the Player:
		// NEEDS to complate....
		//milestone_reaching_1000Score_in100Rounds = false;
		sleep(1);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		// deactivate if you reached it once in the session already...
		milestone_reaching_1000Score_in100Rounds = false;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_12_h){
			allMilestonesProgress_inDotH++;
			milestone_12_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
//13; 50 Answerstreak -> Message: Wao! How did you do that! I'm impressed!
//	You can't miss a beat! Well done you! ...wait! You arn't CHEATING
//	are you! ......     ;) 
void milestone_extraLifeFor_50inRowFn(int i){
	if(i == 50 && milestone_extraLifeFor_50inRow){ // i reset if you give a false answer
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"               ************************************************\n"
			<<"               *   Wao! How did you do that... I'm impressed! *\n"
			<<"               *     You can't miss a beat! Well done you!    *\n"
			<<"               *  ...wait a second, you arn't cheating, R U?! *\n"
			<<"               *                                              *\n"
			<<"               *          Well, I trust you, not.             *\n"
			<<"               *                                              *\n"
			<<"               *              + 3 EXTRA LIFE :)               *\n"
			<<"               *   ...for giving \33[1m50 g\33[0mood \33[1ma\33[0mnswer in a row!     *\n"
			<<"               *           *** \33[5mWELL DONE YOU!\33[0m ***             *\n"
			<<"               ************************************************\n"
			<<endl;
		sleep(1);
		milestone_extraLifeFor_50inRow = false;
		}
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_13_h){
			allMilestonesProgress_inDotH++;
			milestone_13_h = true;} // so it doesnt triggered more then Once!
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
//14; If you made to 10 sessions... Message: Well done! I like your 
//	commitement. I'm proud of you that you keep trying.
//	You can succed only if you try! And also, if you don't use it, you
//	lose it.... Exersizing your brain is like exersizing your limps
//	and muscles! I award you with an extra life<<Player
// Insert this Fn to come out when Player logs in to play the 10th session (register/ save load sessionsCount!!!!)
void milestone_reaching10_sessionsFn(int sessions){
	if(sessions == 10 && milestone_reaching10_sessions){ // as many times you reach 10 life this triggered
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"              ******************************************\n"
			<<"              *    I'm proud of you! Keep playin'!     *\n"
			<<"              * You only can succeed when you try it!  *\n"
			<<"              * And also, if you don't use it, you'll  *\n"
			<<"              * lose it. Exersizing your brain is like *\n"
			<<"              *   exersizing your limps and muscels.   *\n";
		cout<<"              *    ";   	
		for(int b = 1;b<=9;b++){
			cout<<b<<", ";
			fflush(stdout);
			sleep(1); }
		cout<<"10  ";
		cout<<"     *\n";sleep(1);
		cout<<"              *  That's already the \33[1m10th session\33[0m 4 U!  *\n";
		cout<<"              *                                        *\n";
		cout<<"              *       \33[1m\33[5m*** \33[5;33mADDICTION AWARD \33[5;37m***\33[0m          *\n";
		sleep(3);
		cout<<"              *                                        *\n"
			<<"              *        Let me gift to you... :)        *\n"
			<<"              *            \33[1m+ 1 EXTRA LIFE\33[0m              *\n"
			<<"              *                                        *\n"
			<<"              *    WELL DONE, KEEP ON ROLLIN' BABY!    *\n"
			<<"              ******************************************\n"
			<<endl;
		sleep(1);
		milestone_reaching10_sessions = false;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_14_h){
			allMilestonesProgress_inDotH++;
			milestone_14_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
// 15; 50 session mark: Motivational speach... + extra 3 life
void milestone_reaching50_sessionsFn(int sessions){
	if(sessions == 50 && milestone_reaching50_sessions){ // as many times you reach 10 life this triggered
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<"                \33[4;1;33m*\33[1;37m*\33[1;33m* 50th S E S S I O N  A W A R D *\33[1;37m*\33[1;33m* \33[0m\n";
		cout<<"              ******************************************\n";
						
		int x, y = 0;
	for(x = 1;y<=10;++y)
		{
			if(y==0)
			{cout<<"            \33[1;37m";
			cout<<setw(2)<<" "<<y<<"\33[0m";}
			if(y==1)
			{cout<<"\33[1;37m";
			cout<<setw(4)<<" "<<y<<"\33[0m";}
			if(y>1 && y<10)
			{cout<<" \33[1;37m";
			cout<<setw(2)<<" "<<y<<"\33[0m";}
			/*if(y>9 && y<10)
			{cout<<"\33[1;37m";
				cout<<setw(2)<<""<<y;}*/
			if(y==10)
			{cout<<"\33[1;37m";
			cout<<setw(2)<<" "<<y<<"\33[0m";}
		}
	
	cout<<"\n             --------------------------------------------"
			<<endl;
			
	for(x = 1;x<=5;++x)
				{
					//if(x==10)cout<<" \33[1;37m"<<setw(3)<<x<<"  \33[0m|";
					if(x<6)cout<<"              \33[1;37m"<<x<<" \33[0m|";
					//if(x>9 && x<15)cout<<" \33[1;37m"<<setw(3)<<x<<"  \33[0m|";
					for(y = 1; y <= 10; ++y)
					{
						if(y==1)cout<<"\33[;30;43m "<<setw(2)<<x * y;
						if(y>1 && y<10)cout<<"\33[;30;43m "<<setw(3)<<x * y;
						if(y==10)cout<<"\33[;30;43m "<<setw(3)
									<<x * y;
					}
					
					cout<<endl<<"\33[0m";
					}
		sleep(1);
		cout<<"              *    \33[3mI'm proud of you! Keep playin'!     *\n"
			<<"              * You only can succeed when you try it!  *\n"
			<<"              * And also, if you don't use it, you'll  *\n"
			<<"              * lose it. Exersizing your brain is like *\n"
			<<"              *   exersizing your limps and muscels.\33[0m   *\n";
		sleep(1);
		cout<<"              *       ---------------------------      *\n"
			<<"              *  That's already the \33[1m50th session\33[0m 4 U!  *\n"
		    <<"              *              \33[1mWELL DONE!\33[0m                *\n"
			<<"              *        Let me gift to you... :)        *\n"
			<<"              *             \33[1m+ 2 EXTRA LIFE\33[0m             *\n"
			<<"              ******************************************\n"
			<<endl;
		sleep(1);
		milestone_reaching50_sessions = false;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_15_h){
			allMilestonesProgress_inDotH++;
			milestone_15_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"                   Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
// 16; 100 session mark -> Message: Mate, you are ADDICTED! I guess :)
//	But practice makes it, for sure! Keep pushing yourself! Well Done!
//	+ extra 3 lifes. + good answer streek protection.
void milestone_reaching100_sessionsFn(int sessions){
	if(sessions == 100 && milestone_reaching100_sessions){ // as many times you reach 10 life this triggered
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		string a = "              ******************************************\n";
		string b = "              *    \33[3;38mI'm proud of you! Keep playin'!     *\n"; 
		string c = "              * You only can succeed when you try it!  *\n";
		string d = "              * And also, if you don't use it, you'll  *\n";
		string e = "              * lose it. Exersizing your brain is like *\n";
		string f = "              *   exersizing your limps and muscels.\33[0m   *\n";
		string g = "              *                                        *\n";
		string allInOne = a + b + c + d + e + f + g;
		// Print text letter by letter:
		// for(char p : a){cout<<p;fflush(stdout;)} OR
		for(size_t i = 0; i<allInOne.length(); ++i){
			cout<<allInOne[i];
			fflush(stdout);
			/*sleep(1/2);*/} // only whole number works (half a second not counted)
		cout<<"              *          \33[1m100th S E S S I O N\33[0m           *\n";
		cout<<"              *       \33[1m\33[5m*** \33[5;33mADDICTION AWARD \33[5;37m***\33[0m          *\n";
		sleep(1);
		cout<<"              *                                        *\n"
			<<"              *        Let me gift to you... :)        *\n"
			<<"              *            \33[1m+ 3 EXTRA LIFE\33[0m              *\n"
			<<"              *        \33[1m+ 10 G.A.S. PROTECTION\33[0m          *\n"
			<<"              *  (\33[3mso if you make an error your \33[1mG.A.S.\33[0m  *\n"
			<<"              *   \33[3mdoesn't drop until you have it.\33[0m)     *\n"
			<<"              *                                        *\n"
			<<"              *    \33[1;32mWELL DONE, KEEP ON ROLLIN' \33[1;33mBABY\33[0m!    *\n"
			<<"              ******************************************\n"
			<<endl;
		sleep(1);
		//add to gameloop functionality, and a var to monitor it for every user...
		milestone_reaching100_sessions = false;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_16_h){
			allMilestonesProgress_inDotH++;
			milestone_16_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
/*17; Challenge impossible 2: 10000(ten tousend) Score in a single session
	That is minimum 1000 round if you do 1000 G.A. in a row....
	I guess you made it! You are determind, and skillfull. Your 
	commitement is extraordenery! I'm speachless! Well Done!
	This is a really great achivement! BRAVO! + extra 10 lifes.
*/
void milestone_reaching10000_ScoreInSingleSessionFn(int i){
	if(i >= 10000 && milestone_reaching10000_ScoreInSingleSession){
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // Decorate message with Colors and check spelling!
		cout<<"                               \33[1;33m- MILESTONE -\33[0m               \n";
		cout<<"               ********************************************\n"
			<<"               *         \33[3mWao, you are flyin' mate!\33[0m        *\n"
			<<"               *  \33[1mYou might wanna take a water break now!\33[0m *\n"
			<<"               *                                          *\n"
			<<"               *            *** \33[1m\33[5;33m10000 SCORE\33[0m ***            *\n"
			<<"               *                                          *\n"
			<<"               * This is REAL dedication here, my friend! *\n"
			<<"               *  I'm real proud of you now, you know! :) *\n"
			<<"               *   Let me gift you an other FIVE lifes   *\n"
			<<"               *        to express my grattitude!         *\n"
			<<"               *                                          *\n"
			<<"               *             \33[1m+ 5 EXTRA LIFE\33[0m :)            *\n"
			<<"               *                                          *\n"
			<<"               ********************************************\n"
			<<endl;
		milestone_reaching10000_ScoreInSingleSession = false; // only once per session so you wont see it again
		//														if score growes from 103 to 113 for exsample.
		sleep(1);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_17_h){
			allMilestonesProgress_inDotH++;
			milestone_17_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
//------------------------------------------------------------------------	
//17.5; If you reach 100 000 alltime score + 7 life	
	void milestone_reaching100000_AllTimeScoreFn(int i){
	if(i >= 100000 && milestone_reaching100000_AllTimeScore){
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // Decorate message with Colors and check spelling!
		cout<<"                               \33[1;33m- MILESTONE -\33[0m               \n";
		cout<<"               ********************************************\n"
			<<"               *         \33[1mWao, you really like this!\33[0m       *\n" 
			<<"               *        \33[1mYou already reached Alltime\33[0m       *\n" 
			<<"               *                                          *\n"
			<<"               *            *** \33[1m\33[5;33m100 000 SCORE\33[0m ***          *\n"
			<<"               *                                          *\n"
			<<"               * This is REAL dedication here, my friend! *\n"
			<<"               *  I'm real proud of you now, you know! :) *\n"
			<<"               *   Let me gift you an other Seven lifes   *\n"
			<<"               *        to express my grattitude!         *\n"
			<<"               *                                          *\n"
			<<"               *             \33[1m+ 7 EXTRA LIFE\33[0m :)            *\n"
			<<"               *                                          *\n"
			<<"               ********************************************\n"
			<<endl;
		milestone_reaching100000_AllTimeScore = false; // only once per session so you wont see it again
		//														if score growes from 103 to 113 for exsample.
		sleep(1);
		cout<<endl;
		cout<<endl;
		cout<<endl;
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_17andHalf_h){
			allMilestonesProgress_inDotH++;
			milestone_17andHalf_h = true;} // so it doesnt triggered more then Once!
		}
	//cout<<"Please press ENTER to continue...";
	//cout<<endl;
	//cin.get();
	}
//-----------------------------------------------------------------------------------------	
//18; If you reach 1 000 000 AllTimescore ->
//	unlocks the "Low of attraction" message -> gives you my blessing...
void milestone_reaching1000000_AllTimeScoreFn(int i){
	if(i >= 1000000 && milestone_reaching1000000_AllTimeScore){
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // Decorate message with Colors and check spelling!
		cout<<"            \33[1;33m- MISSION IMPOSSIBLE -> \33[1;32mUNLOCKED \33[1;33m-\33[0m               \n";
		cout<<"               ********************************************\n"
			<<"               *         \33[3mWao, you are flyin' mate!\33[0m        *\n"
			<<"               *  \33[1mYou might wanna take a water break now!\33[0m *\n"
			<<"               *                                          *\n"
			<<"               *        *** \33[1m\33[5;33mONE MILLION SCORE\33[0m ***          *\n"
			<<"               *                                          *\n"
			<<"               * This is REAL dedication here, my friend! *\n"
			<<"               *  I'm real proud of you now, you know! :) *\n"
			<<"               *                                          *\n"
			<<"               *         \33[1mSPECIAL REWARD UNLOCKED!\33[0m         *\n"
			<<"               *                                          *\n"
			<<"               ********************************************\n"
			<<endl;
		milestone_reaching1000000_AllTimeScore = false; // only once per session so you wont see it again
		//														if score growes from 103 to 113 for exsample.
		sleep(1);
		//Milestones counter triggered only onece per Player per Milestone.
		if(!milestone_18_h){
			allMilestonesProgress_inDotH++;
			milestone_18_h = true;} // so it doesnt triggered more then Once!
		}
		cout<<"Please press ENTER to continue...";
		cout<<endl;
		cin.get();
		// Here comes the low of attraction message:
		cout<<endl;
		cout<<endl;
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<"              \33[1mLow of \"Life\"\33[0m\n\n"<<endl;
	
		cout<<"                           "<<"\33[3m"<<"\33[2mBased on Neville Goddard teachings...\33[0m"<<endl;
		cout<<"                           "<<"\33[3m"<<"\33[2mand on the Hermetic teachings...\33[0m\n"<<endl; 
		cout<<"What most people don't understand is that thought has a frequency.\n"
			<<"We humans able to measure a thoughts. So when you think you emit,\n"
			<<"you radiate these frequencies. If you \33[1mthinking the same though\33[0m\n"
			<<"over and over and over again if you are \33[1mimagining in your mind\33[0m you\n"
			<<"even paint a vivid picture of that thought, you visualising it,\n"
			<<"like you seeing yourself having the money you need, having and \n"
			<<"living the life \33[1myou wish\33[0m to do so as you are already acomplished\n"
			<<"that. You are \33[1memitting\33[0m that frequrncy on a regular consistent basis.\n"
			<<"And so therefore that thought will \33[1mmaterialize\33[0m in the 3D reality, in\n"
			<<"your reality, in your future, that thought will become you. ALL YOU\n"<<endl;
			
		cout<<"Please press ENTER to continue...";
		cout<<endl;
		cin.get();
		
		cout<<"NEED TO DO is: TAKE ACTION! as you as a physical person can turn this\n"
			<<"thought into your physical reality! By listening and watching out for \n"
			<<"signs on your \"journey\". These signs called OPORTUNITY! So you'll have\n"
			<<"a (so called \33[1m\"GUT FEELING\"\33[0m when you see a oportunity like that that \n"
			<<"meant to be yours to take. So You act upon this oportunity. By doing so\n"
			<<"this will make happen what you were wishing for in the past. Things need\n"
			<<"time to arange, and from your thoughts become a physical reality, so the\n"
			<<"when is uncertain, but you MUST KEEP FATE IN YOURSELF, and stand by your\n"
			<<"goals and wishes, and rehearse them as many time as possible on the\n"
			<<"vividest way possible before going to the bed and or when waking up is\n"
			<<"the best time for it to be alone with your thoughts and \"DREAM\" about\n"
			<<"them. Thinking coutiously and carefully about what you wish for yurselfe\n"
			<<"and for others is one thing. The equally important part of the TWO piece\n"
			<<"puzzle is \33[1m\"TAKING ACTION\"\33[0m."<<endl;
			
		cout<<endl;
		cout<<"Please press ENTER to continue...";
		cout<<endl;
		cin.get();
		
		cout<<"Hance the saying: \"Careful what you \33[1mwish\33[0m for\" 'cause it might be\33[1mcome TRUE\33[0m!\n"
			<<"So basicly this is how you take control of your own life. Think well!\n"
			<<"Live well! Fare well & \"GOD\" BLESS you! Amen. Or you might say that:\n"
			<<"\"the Universum will provide\". Be grateful for what you already have and \n"
			<<"for what you don't. Cherrish the moment you live. 'Couse you live in the \n"
			<<"present (\"you live only once\"). THAT's WHAT MATTERS!"<<"\n"
			<<"Letting go your desires by knowing that \"God\" will provide,\n"
			<<"it is key too. When you not thinking about whatever it is,\n"
			<<"you letting, trusting \"God\" to do its thing. (\"God's surprise\") \n"
			<<"Therefore your wishes and desires are coming up in your life\n"
			<<"at unexpected times. And that time you must realise that is for you.\n"
			<<"That time you listen to your inner voice and take action upon it.\n"<<endl;
		
		cout<<endl;
		cout<<"Please press ENTER to continue...";
		cout<<endl;
		cin.get();
			
		cout<<"Your past is purly an image, a reflection of your past actions upon\n"
			<<"your past thoughs. You attract and you become what you think (about the most).\n"
			<<"Your future is the materialised 3D reality version of your own thoughts.\n"
			<<"Materialised by your own actions. But there is always an unknown amount of\n"
			<<"delay between the feelingful tought and your reality. \33[1mWAIT, PATIENCE, FOCUS\33[0m...\n"
			<<"So if something doesn't turn out as you might wished for, simply WISH BETTER!\n"
			<<"After all, you can blame only YOU (and negative people around you)!...\n"
			<<"How and what you think... \33[1m\"It's in your head.\"\33[0m.\n"
			<<"Be precise about your goals as much as possible... and most of the time \n"
			<<"they will turn out ecetly as you wished for or even better. If someting\n"
			<<"doesn't go to your way and you think it should that might be besause that\n"
			<<"something or someone NOT meant to YOU. Something else is waiting for you.\n"
			<<"Be OPEND for oportunities. And when you have a good gut feeling about something\n"
			<<"is time to take action. Also if you have a bad gut feeling about something\n"
			<<"you'll take an avoiding action... No second guessing or overthinking.\n"
			<<"GUT FEELING is something you should take seriously! It's there to guid you\n"
			<<"into the \"right\" action! No hesitation. Take immediate action!\n"
			<<"... and say THANK YOU!"<<endl;
			
		cout<<endl;
		cout<<"Please press ENTER to continue...";
		cout<<endl;
		cin.get();	
			
		cout<<"You attract and dispell things into your life. (Your thought, your life,\n"
			<<"your reality.) Think of yourself for a moment as a magnet. You attract \n"
			<<"and dispell things, persons, happenings simply with your thoughts.\n"
			<<"Think in thoughts of abundance and wealth if that what you desire. \n"
			<<"Think in care and love and beauty, happiness and peacefullness if \n"
			<<"that what you after. What and how you think, that what you are.\n"
			<<"Know what you want and be okay without it. Tath's how you generates positive\n"
			<<"energy and thinking patern towards that specific goal of yours.\n"
			<<"Not telling others your goals helps to focus the energy, others don't\n"
			<<"interfere with your emotions, feelings and thoughts. If others are in your\n"
			<<"jelous of what you want, and they see you closing up on it they can \n"
			<<"compromise your results, distract your focus and achieving the goal becomes\n"
			<<"harder to you, as more negative egergy rises by their thoughts and feelings.\n"
			<<"As we know all mind is connected on a superconscious level. Practice Focus!\n"
			<<endl;
			
			cout<<endl;
		cout<<"Please press ENTER to continue...";
		cout<<endl;
		cin.get();
		
			cout<<"\33[4m"<<"\33[1mFocus:\33[0m without focus it will not happen. Listen to your inner voice in\n"
			<<"crutial moment (that you will recognize when its is there) and act upon it\n"
			<<"focus means that you focus on that inner voice to act as the voice says.\n"
			<<"Don't let others lessen the strength of your wishes. Keep it for yourself...\n"
			<<"Other people interested in end results only, they don't care the process.\n"
			<<"Your wish simply slips away without materializing the energy into 3D.\n"
			<<"And that is the KEY. By acting upon your \" gut-feeling\" is what focuses\n"
			<<"the energy (your wish, \"God's planes\") into 3D reality. Materialize.\n"
			<<"Every thought of yours is shaping your reality. Express your gratitude for\n"
			<<"things that happen to you in life and for things that don't. Be gratefull!\n"
			<<"You are the creator of your on life once you learn to control your subconscious.\n"
			<<"Conscious mind feeds wishes through deep thoughts, and feelings, emotions\n"
			<<"(this is the lenguage of mind) to subconsciousness. And subconsciousness\n"
			<<"prijects that to \"God\" to the superconsciousness (universe), then it starts\n"
			<<"to geather and focus the required energy to the wishfulfillment. Then when\n"
			<<"it is time to materialize, you'll rcieve the gut-feeling, and you act upon it.\n"
			<<"Faster you do that without second guessing yourself is the better.\n"
			<<"\33[1mTrust yourself!\33[0m\n"
			<<endl;
			
		cout<<"Please press ENTER to continue...";
		cout<<endl;
		cin.get();
		
			cout<<"And \"Reality has been created. The creator within you. As within, as without.\n"
			<<"Ultimatly you might have a purpose in this lifetime to fullfill. Sometimes it\n"
			<<"is written for you by the Universe already. You just need to find a path\n"
			<<"that leads you toward your purpose. Without purpose you, and your soul is\n"
			<<"lost. Tangled in the void. Which will grind your body and soul...\n"
			<<"Sub and super conscious needs proper directions, details to create \"properly\"\n"
			<<"If no purpose (no direction) your mind will take you places where most likely\n"
			<<"you dont want to be... You'll feel lost... So train your mind! Be the person\n"
			<<"YOU WANT TO BE! Practice, train, pay attention to your feelings and focus!\n"
			<<"Well, I wish you a happily lived life, and I'm greatfull for that you already\n"
			<<"have came so far... \33[1m\"I'm a Wishing well, so I wish You WELL!\"\33[0m :) Bye!"<<endl;
		
		cout<<endl;
		cout<<"Once you read it all, please press ENTER to continue...";
		cin.get();
		cout<<endl;
		
	}
//----------------------------------------------------------------------
//19; If and when you unlocked all the achivements.... ->
//	message that you did, and GAME COMPLATED! THE POWER IS WITHIN YOU NOW! AMEN!
void allMilestonesUnlockedFn(int all, string playerName){ // all = allMilestonesProgress
	all = allMilestonesProgress_inDotH;
	if(all == 31){ // 18 is the total numbers of achivements -> if u unlock one it start counting in
					// variable (Need making) allMilestonesProgress -> can be displayed in statistics
					// Milestones unlocked: 2/18 -> sample -> show unlocked milestones -> brief discription
		allMilestonesUnlocked = true;
		system("clear");
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl;
		cout<<endl; // space = 15 on front
		
		cout<<"                     \33[1;31mC "
			<<"\33[1;33mO "
			<<"\33[1;32mN "
			<<"\33[1;34mG "
			<<"\33[1;35mR "
			<<"\33[1;36mA "
			<<"\33[1;38mT "
			<<"\33[1;31mU "
			<<"\33[1;33mL "
			<<"\33[1;32mA "
			<<"\33[1;34mT "
			<<"\33[1;35mI "
			<<"\33[1;36mO "
			<<"\33[1;37mN\33[0m\n"
			<<endl;
		cout<<"               \33[1mPLAYER: \33[1;32m"<<playerName<<"\33[0m\n" // add here the player's name!!!!
			<<"               **************************************\n"
			<<"               *     \33[1;33mG \33[5;36mA \33[0m\33[1;33mM \33[5;31mE\33[0m\33[1m  C" 
			<<" \33[5;32mO\33[0m \33[1m M P L \33[5;34mA\33[0m \33[1mT \33[5;33mE\33[0m\33[1m D\33[0m    *\n"
			<<"               *                                    *\n"
			<<"               *     \33[1;38mALL MILESTONES, ACHIVEMENTS\33[0m    *\n"
			<<"               *             \33[1;38mARE UNLOCKED!\33[0m          *\n"
			<<"               *                                    *\n"
			<<"               * \33[1;33mTHE \33[1;36mPOWER\33[1;33m IS WITHIN YOU \33[1;32mNOW\33[0m! \33[1;37mAMEN! *\n"
			<<"               **************************************\33[0m\n"
			<<endl;
		cout<<"Please press ENTER to continue...";
	cout<<endl;
	cin.get();
		cout<<"               \33[3mYou're more than wellcome to keep playing\n"
			<<"               by the way! But there is not much more I \n"
			<<"               would be able to offer you here...  \33[1;37m:\33[0m\33[1;37m)\33[0m\n"
			<<"                 \33[1mTHANK YOU for LERNING and PLAYING!\33[0m"<<endl;
		sleep(1);
		// cout here copyright and credit for you...... info and go back to continue game mode...
		
		cout<<endl;
		cout<<endl;
		cout<<endl;
		}
	cout<<"Please press ENTER to continue...";
	cout<<endl;
	cin.get();
		}
//------------------------
void final_achivement_textShortcutFn(){

		cout<<endl;
		cout<<endl;
		cout<<"              \33[1mLow of \"Life\"\33[0m\n\n"<<endl;
	
		cout<<"                           "<<"\33[3m"<<"\33[2mBased on Neville Goddard teachings...\33[0m"<<endl;
		cout<<"                           "<<"\33[3m"<<"\33[2mand on the Hermetic teachings...\33[0m\n"<<endl; 
		cout<<"What most people don't understand is that thought has a frequency.\n"
			<<"We humans able to measure a thoughts. So when you think you emit,\n"
			<<"you radiate these frequencies. If you \33[1mthinking the same though\33[0m\n"
			<<"over and over and over again if you are \33[1mimagining in your mind\33[0m you\n"
			<<"even paint a vivid picture of that thought, you visualising it,\n"
			<<"like you seeing yourself having the money you need, having and \n"
			<<"living the life \33[1myou wish\33[0m to do so as you are already acomplished\n"
			<<"that. You are \33[1memitting\33[0m that frequrncy on a regular consistent basis.\n"
			<<"And so therefore that thought will \33[1mmaterialize\33[0m in the 3D reality, in\n"
			<<"your reality, in your future, that thought will become you. ALL YOU\n"<<endl;
			
		cout<<"Please press ENTER to continue...";
		cout<<endl;
		cin.get();
		
		cout<<"NEED TO DO is: TAKE ACTION! as you as a physical person can turn this\n"
			<<"thought into your physical reality! By listening and watching out for \n"
			<<"signs on your \"journey\". These signs called OPORTUNITY! So you'll have\n"
			<<"a (so called \33[1m\"GUT FEELING\"\33[0m when you see a oportunity like that that \n"
			<<"meant to be yours to take. So You act upon this oportunity. By doing so\n"
			<<"this will make happen what you were wishing for in the past. Things need\n"
			<<"time to arange, and from your thoughts become a physical reality, so the\n"
			<<"when is uncertain, but you MUST KEEP FATE IN YOURSELF, and stand by your\n"
			<<"goals and wishes, and rehearse them as many time as possible on the\n"
			<<"vividest way possible before going to the bed and or when waking up is\n"
			<<"the best time for it to be alone with your thoughts and \"DREAM\" about\n"
			<<"them. Thinking coutiously and carefully about what you wish for yurselfe\n"
			<<"and for others is one thing. The equally important part of the TWO piece\n"
			<<"puzzle is \33[1m\"TAKING ACTION\"\33[0m."<<endl;
			
		cout<<endl;
		cout<<"Please press ENTER to continue...";
		cout<<endl;
		cin.get();
		
		cout<<"Hance the saying: \"Careful what you \33[1mwish\33[0m for\" 'cause it might be\33[1mcome TRUE\33[0m!\n"
			<<"So basicly this is how you take control of your own life. Think well!\n"
			<<"Live well! Fare well & \"GOD\" BLESS you! Amen. Or you might say that:\n"
			<<"\"the Universum will provide\". Be grateful for what you already have and \n"
			<<"for what you don't. Cherrish the moment you live. 'Couse you live in the \n"
			<<"present (\"you live only once\"). THAT's WHAT MATTERS!"<<"\n"
			<<"Letting go your desires by knowing that \"God\" will provide,\n"
			<<"it is key too. When you not thinking about whatever it is,\n"
			<<"you letting, trusting \"God\" to do its thing. (\"God's surprise\") \n"
			<<"Therefore your wishes and desires are coming up in your life\n"
			<<"at unexpected times. And that time you must realise that is for you.\n"
			<<"That time you listen to your inner voice and take action upon it.\n"<<endl;
			
		cout<<endl;
		cout<<"Please press ENTER to continue...";
		cin.get();
		system("clear");
		cout<<endl;
			
		cout<<"Your past is purly an image, a reflection of your past actions upon\n"
			<<"your past thoughs. You attract and you become what you think (about the most).\n"
			<<"Your future is the materialised 3D reality version of your own thoughts.\n"
			<<"Materialised by your own actions. But there is always an unknown amount of\n"
			<<"delay between the feelingful tought and your reality. \33[1mWAIT, PATIENCE, FOCUS\33[0m...\n"
			<<"So if something doesn't turn out as you might wished for, simply WISH BETTER!\n"
			<<"After all, you can blame only YOU (and negative people around you)!...\n"
			<<"How and what you think... \33[1m\"It's in your head.\"\33[0m.\n"
			<<"Be precise about your goals as much as possible... and most of the time \n"
			<<"they will turn out ecetly as you wished for or even better. If someting\n"
			<<"doesn't go to your way and you think it should that might be besause that\n"
			<<"something or someone NOT meant to YOU. Something else is waiting for you.\n"
			<<"Be OPEND for oportunities. And when you have a good gut feeling about something\n"
			<<"is time to take action. Also if you have a bad gut feeling about something\n"
			<<"you'll take an avoiding action... No second guessing or overthinking.\n"
			<<"GUT FEELING is something you should take seriously! It's there to guid you\n"
			<<"into the \"right\" action! No hesitation. Take immediate action!\n"
			<<"... and say THANK YOU!"<<endl;
			
		cout<<endl;
		cout<<"Please press ENTER to continue...";
		cout<<endl;
		cin.get();	
			
		cout<<"You attract and dispell things into your life. (Your thought, your life,\n"
			<<"your reality.) Think of yourself for a moment as a magnet. You attract \n"
			<<"and dispell things, persons, happenings simply with your thoughts.\n"
			<<"Think in thoughts of abundance and wealth if that what you desire. \n"
			<<"Think in care and love and beauty, happiness and peacefullness if \n"
			<<"that what you after. What and how you think, that what you are.\n"
			<<"Know what you want and be okay without it. Tath's how you generates positive\n"
			<<"energy and thinking patern towards that specific goal of yours.\n"
			<<"Not telling others your goals helps to focus the energy, others don't\n"
			<<"interfere with your emotions, feelings and thoughts. If others are in your\n"
			<<"jelous of what you want, and they see you closing up on it they can \n"
			<<"compromise your results, distract your focus and achieving the goal becomes\n"
			<<"harder to you, as more negative egergy rises by their thoughts and feelings.\n"
			<<"As we know all mind is connected on a superconscious level. Practice Focus!\n"
			<<endl;
			
			cout<<endl;
		cout<<"Please press ENTER to continue...";
		cout<<endl;
		cin.get();
		
			cout<<"\33[4m"<<"\33[1mFocus:\33[0m without focus it will not happen. Listen to your inner voice in\n"
			<<"crutial moment (that you will recognize when its is there) and act upon it\n"
			<<"focus means that you focus on that inner voice to act as the voice says.\n"
			<<"Don't let others lessen the strength of your wishes. Keep it for yourself...\n"
			<<"Other people interested in end results only, they don't care the process.\n"
			<<"Your wish simply slips away without materializing the energy into 3D.\n"
			<<"And that is the KEY. By acting upon your \" gut-feeling\" is what focuses\n"
			<<"the energy (your wish, \"God's planes\") into 3D reality. Materialize.\n"
			<<"Every thought of yours is shaping your reality. Express your gratitude for\n"
			<<"things that happen to you in life and for things that don't. Be gratefull!\n"
			<<"You are the creator of your on life once you learn to control your subconscious.\n"
			<<"Conscious mind feeds wishes through deep thoughts, and feelings, emotions\n"
			<<"(this is the lenguage of mind) to subconsciousness. And subconsciousness\n"
			<<"prijects that to \"God\" to the superconsciousness (universe), then it starts\n"
			<<"to geather and focus the required energy to the wishfulfillment. Then when\n"
			<<"it is time to materialize, you'll rcieve the gut-feeling, and you act upon it.\n"
			<<"Faster you do that without second guessing yourself is the better.\n"
			<<"\33[1mTrust yourself!\33[0m\n"
			<<endl;
			
		cout<<"Please press ENTER to continue...";
		cout<<endl;
		cin.get();
		
			cout<<"And \"Reality has been created. The creator within you. As within, as without.\n"
			<<"Ultimatly you might have a purpose in this lifetime to fullfill. Sometimes it\n"
			<<"is written for you by the Universe already. You just need to find a path\n"
			<<"that leads you toward your purpose. Without purpose you, and your soul is\n"
			<<"lost. Tangled in the void. Which will grind your body and soul...\n"
			<<"Sub and super conscious needs proper directions, details to create \"properly\"\n"
			<<"If no purpose (no direction) your mind will take you places where most likely\n"
			<<"you dont want to be... You'll feel lost... So train your mind! Be the person\n"
			<<"YOU WANT TO BE! Practice, train, pay attention to your feelings and focus!\n"
			<<"Well, I wish you a happily lived life, and I'm greatfull for that you already\n"
			<<"have came so far... \33[1m\"I'm a Wishing well, so I wish You WELL!\"\33[0m :) Bye!"<<endl;
		
		cout<<endl;
		cout<<"Once you read it all, please press ENTER to continue...";
		cin.get();
		cout<<endl;
}		

#endif



