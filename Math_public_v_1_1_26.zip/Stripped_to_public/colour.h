

#ifndef _COLORS_
#define _COLORS_

//	FOREGROUND & BACKGROUND COLOR CODES:

#define RSTA	"\33[0m" // reset format
#define RSTU 	"\33[24m" // reset underline
#define RSTB 	"\33[21m"  // reset bright or bold

#define FBLACK	"\33[;30m"
#define BBLACK	"\33[;40m"
#define FBLACKBOLD	"\33[1;30m"
#define FBLACK_DIM "\33[2;30m"
#define FBLACKBOLD_BBLACK	"\33[1;30;40m"
#define FBLACK_BBLACK	"\33[;30;40m"
#define FBLACKBOLD_BRED "\33[1;30;41m"
#define FRED	"\33[;31m"
#define BRED	"\33[;41m"
#define FREDBOLD	"\33[;1;31m"
#define FRED_DIM "\33[2;31m"
#define FGREEN	"\33[;32m"
#define BGREEN	"\33[;42m"
#define FGREENBOLD	"\33[;1;32m"
#define FGREEN_DIM "\33[2;32m"
#define BGREENBOLD	"\33[1;37;42m"
#define FGREENBOLD_BRED "\33[1;32;41m"
#define FYELLOW	"\33[;33m"
#define BYELLOW "\33[;43m"
#define FYELLOWBOLD	"\33[;1;33m"
#define FYELLOW_DIM "\33[2;33m"
#define FYELLOW_BLACKBG "\33[;33;40m"
#define FYELLOWBOLD_BBLACK "\33[1;33;40m"
#define FBLUE	"\33[;34m"
#define BBLUE	"\33[;44m"
#define FBLUEBOLD	"\33[1;34m"
#define FBLUE_DIM "\33[2;34m"
#define FBLUEBOLD_BLACKBG	"\33[1;34;40m"
#define FMAGENTA "\33[;35m"
#define BMAGENTA "\33[;45m"
#define FMAGENTABOLD	"\33[;1;35m"
#define FMAGENTA_DIM "\33[2;35m"
#define FMAGENTABOLD_BBLACK "\33[1;35;40m"
#define FCAYEN "\33[;36m"
#define BCAYEN "\33[;46m"
#define FCAYENBOLD	"\33[1;36m"
#define FCAYENBOLD_BLACKBG "\33[1;36;40m"
#define FCAYEN_DIM "\33[2;36m"
#define FWHITE "\33[;37m"
#define BWHITE "\33[;47m"
#define FWHITEBOLD	"\33[;1;37m"
#define FWHITE_DIM "\33[2;37m"
#define FWHITER "\33[;38m"
#define BWHITER "\33[;;48m"
#define FRED_BWHITE "\33[;31;47m"
#define FRED_BOLD_BWHITE "\33[1;31;47m"
#define FGREEN_BDARK "\33[1;32;40m"
#define FWHITE_BDARK "\33[1;37;40m"
#define FYELLOW_BBLUE "\33[1;33;44m"
#define BWHITE_FYELLOW_DIM "\33[2;33;47m"
#define BWHITE_FBLACK "\33[;30;47m"
#define FGREEN_DIM_BYELLOW "\33[2;33;43m"
#define BWHITE_FYELLOW "\33[;33;47m"
#define BWHITE_BOLD_BLACK "\33[1;30;47m"
#define FBLUE_BOLD_BBLACK "\33[1;34;40m"
#define FRED_BOLD_BBLUE "\33[1;31;44m"
#define FBLACK_BYELLOW "\33[1;30;43m"
#define FREDBOLD_BBLACK "\33[1;31;40m"
#define FWHITE_BOLD_BBLACK "\33[1;37;40m"
// FORMATING CODES

#define BRIGHT	"\33[1m" // (it's "BOLD")
#define DIM 	"\33[2m"
#define ITALIC 	"\33[3m" // if supported
#define ULINE	"\33[4m"
#define BLINK 	"\33[5m"
#define REVERSE "\33[7m"
#define HIDDEN 	"\33[8m"
//------------------------
#include <iostream>
#include <string>
using namespace std;
//color Themes:

class ColorThemes{
	
	public:
	//COLOR THEME VARS:
		string keret_color;				// 1
		string menu_color1;				// 2
		string menu_color2;				// 3
		string back_color;				// 4
		string equation_color1;			// 5
		string equation_color2;			// 6
		string operation_color;			// 7
		string youranswer_color;		// 8
		string yes_color;				// 9
		string smily_color;				//10
		string next_color;				//11
		string stop_color;				//12
		string tryagain_color;			//13
		string itsnotanumber_color;		//14
		string yellow_color;            //15
		string whiteBold_color;         //16
		string equattionText_color;     //17
		
//----------------------------------------------------------------------
//default Theme:
void default_colorsFn(){
	keret_color = RSTA;
	whiteBold_color = FWHITEBOLD;
	yellow_color = FYELLOWBOLD;
	menu_color1 = FYELLOW;
	menu_color2 = FWHITEBOLD;
	back_color = FYELLOW_BLACKBG;
	equattionText_color = FWHITEBOLD;
	equation_color1 = FWHITEBOLD;
	equation_color2 = FWHITEBOLD;
	operation_color = FYELLOWBOLD;
	youranswer_color = FGREENBOLD;
	yes_color = FGREENBOLD;
	smily_color = FYELLOW;
	next_color = FGREENBOLD;
	stop_color = FREDBOLD;
	tryagain_color = BWHITE_BOLD_BLACK;
	itsnotanumber_color = FRED_BOLD_BWHITE;
	}
//Spring Theme
void spring_colorsFn(){
	keret_color = FGREENBOLD;
	whiteBold_color = FWHITEBOLD;
	yellow_color = FYELLOWBOLD;
	menu_color1 = FYELLOWBOLD;
	menu_color2 = FCAYENBOLD;
	back_color = FBLUEBOLD_BLACKBG;
	equattionText_color = FYELLOWBOLD;
	equation_color1 = FGREENBOLD;
	equation_color2 = FGREENBOLD;
	operation_color = FCAYENBOLD;
	youranswer_color = BGREENBOLD;
	yes_color = FYELLOWBOLD;
	smily_color = FYELLOWBOLD;
	next_color = FGREENBOLD;
	stop_color = FREDBOLD;
	tryagain_color = FBLUEBOLD;
	itsnotanumber_color = FCAYENBOLD;
	}
//Summer Theme
void summer_colorsFn(){
	keret_color = FREDBOLD;
	whiteBold_color = FWHITEBOLD;
	yellow_color = FYELLOWBOLD;
	menu_color1 = FGREENBOLD;
	menu_color2 = FYELLOWBOLD;
	back_color = FREDBOLD_BBLACK;
	equattionText_color = FWHITEBOLD;
	equation_color1 = FCAYENBOLD;
	equation_color2 = FBLUEBOLD;
	operation_color = FWHITEBOLD;
	youranswer_color = FYELLOWBOLD_BBLACK;
	yes_color = FMAGENTABOLD;
	smily_color = FYELLOWBOLD;
	next_color = FYELLOWBOLD;
	stop_color = FREDBOLD;
	tryagain_color = BMAGENTA;
	itsnotanumber_color = FREDBOLD_BBLACK;
	}
//Autumn Theme
void autumn_colorsFn(){
	keret_color = FYELLOW;
	whiteBold_color = FWHITEBOLD;
	yellow_color = FGREENBOLD;
	menu_color1 = FYELLOWBOLD;
	menu_color2 = FYELLOW_BLACKBG;
	back_color = FYELLOWBOLD_BBLACK;
	equattionText_color = FYELLOW;
	equation_color1 = FYELLOWBOLD_BBLACK;
	equation_color2 = FYELLOWBOLD_BBLACK;
	operation_color = FWHITEBOLD;
	youranswer_color = FWHITE_BOLD_BBLACK;
	yes_color = FCAYENBOLD_BLACKBG;
	smily_color = FYELLOWBOLD;
	next_color = FGREENBOLD;
	stop_color = FREDBOLD;
	tryagain_color = FCAYENBOLD_BLACKBG;
	itsnotanumber_color = FBLACKBOLD_BRED;
	}
//Winter Theme
void winter_colorsFn(){
	keret_color = FYELLOW_BLACKBG;
	whiteBold_color = FWHITEBOLD;
	yellow_color = FYELLOWBOLD;
	menu_color1 = FWHITE;
	menu_color2 = FWHITE_BDARK;
	back_color = FYELLOW_BLACKBG;
	equattionText_color = FWHITE_BDARK;
	equation_color1 = BWHITE_FBLACK;
	equation_color2 = BWHITE_FBLACK;
	operation_color = FWHITE_BDARK;
	youranswer_color = FWHITE_BOLD_BBLACK;
	yes_color = FGREENBOLD;
	smily_color = FWHITEBOLD;
	next_color = FWHITEBOLD;
	stop_color = FREDBOLD;
	tryagain_color = FYELLOWBOLD_BBLACK;
	itsnotanumber_color = FREDBOLD_BBLACK;
	}
//------------------------------------	
//Print colors as samplesFn
void printColorsAsSamplesFn(){
	
	cout<<endl;
	cout<<"              **** COLOR SAMPLES ***\n"<<endl;
	cout<<"FBLACK: \t\t"<<FBLACK"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"BBLACK: \t\t"<<BBLACK"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FBLACKBOLD: \t\t"<<FBLACKBOLD"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FBLACK_DIM: \t\t"<<FBLACK_DIM"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FBLACK_BBLACK: \t\t"<<FBLACK_BBLACK"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FBLACKBOLD_BBLACK: \t"<<FBLACKBOLD_BBLACK"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FRED: \t\t\t"<<FRED"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"BRED: \t\t\t"<<BRED"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FREDBOLD:\t \t"<<FREDBOLD<<"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FRED_DIM: \t\t"<<FRED_DIM"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FRED_BWHITE: \t\t"<<FRED_BWHITE"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FGREEN: \t\t"<<FGREEN"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"BGREEN: \t\t"<<BGREEN"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FGREENBOLD: \t\t"<<FGREENBOLD"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FGREEN_DIM: \t\t"<<FGREEN_DIM"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FGREEN_BDARK: \t\t"<<FGREEN_BDARK"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FYELLOW: \t\t"<<FYELLOW"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"BYELLOW: \t\t"<<BYELLOW"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FYELLOWBOLD: \t\t"<<FYELLOWBOLD"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FYELLOW_DIM: \t\t"<<FYELLOW_DIM"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FYELLOW_BLACKBG: \t"<<FYELLOW_BLACKBG"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FBLUE: \t\t\t"<<FBLUE"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"BBLUE: \t\t\t"<<BBLUE"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FBLUEBOLD: \t\t"<<FBLUEBOLD"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FBLUE_DIM: \t\t"<<FBLUE_DIM"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FBLUEBOLD_BLACKBG: \t"<<FBLUEBOLD_BLACKBG"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FMAGENTA: \t\t"<<FMAGENTA"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"BMAGENTA:\t \t"<<BMAGENTA"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FMAGENTABOLD\t \t"<<FMAGENTABOLD"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FMAGENTA_DIM: \t\t"<<FMAGENTA_DIM"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FCAYEN: \t\t"<<FCAYEN"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"BCAYEN: \t\t"<<BCAYEN"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FCAYENBOLD: \t\t"<<FCAYENBOLD"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FCAYEN_DIM: \t\t"<<FCAYEN_DIM"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FWHITE: \t\t"<<FWHITE"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"BWHITE \t\t\t"<<BWHITE"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FWHITEBOLD: \t\t"<<FWHITEBOLD"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FWHITE_DIM: \t\t"<<FWHITE_DIM"ABCDEGF_abcd_12345"<<RSTA<<"\n"
		<<"FWHITE_BDARK: \t\t"<<FWHITE_BDARK"ABCDEGF_abcd_12345"<<RSTA<<"\n";
	cout<<"FWHITER: \t\t"<<FWHITER"ABCDEFG_abcd_12345"<<RSTA<<"\n"
		<<"BWHITER: \t\t"<<BWHITER"ABCDEFG_abcd_12345"<<RSTA<<"\n"
		<<endl;
		

}

	}; //End class





#endif



